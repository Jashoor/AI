"""
Streamlit web UI. Run with: `streamlit run src/app.py`

Free to run: Streamlit itself is open-source/free, and the default
LLM_BACKEND=mock needs no API key or internet at inference time.
"""
import streamlit as st

from src import config
from src.agent.orchestrator import Orchestrator

st.set_page_config(page_title="Multilingual E-commerce Support Bot", page_icon="🛒", layout="wide")

if "orchestrator" not in st.session_state:
    st.session_state.orchestrator = Orchestrator()
if "messages" not in st.session_state:
    st.session_state.messages = []  # list of (role, text, meta)

with st.sidebar:
    st.header("⚙️ Session Info")
    st.write(f"**LLM backend:** `{config.LLM_BACKEND}`")
    st.write(f"**Retrieval mode:** `{st.session_state.orchestrator.retriever.mode}`")
    st.write(f"**Session ID:** `{st.session_state.orchestrator.session_id}`")

    st.markdown("---")
    st.subheader("Change retrieval mode")
    new_mode = st.radio(
        "Compare the eval angle live:",
        options=["bilingual", "en_only"],
        index=0 if st.session_state.orchestrator.retriever.mode == "bilingual" else 1,
        help="en_only = index English docs only, relies purely on cross-lingual "
             "embedding similarity. bilingual = also indexes the parallel Tamil "
             "FAQ text. Switch mid-conversation to see retrieval quality change "
             "for Tamil / code-switched questions.",
    )
    if new_mode != st.session_state.orchestrator.retriever.mode:
        st.session_state.orchestrator = Orchestrator(retrieval_mode=new_mode)
        st.session_state.messages = []
        st.rerun()

    st.markdown("---")
    if st.button("🔄 Reset conversation"):
        st.session_state.orchestrator = Orchestrator(retrieval_mode=new_mode)
        st.session_state.messages = []
        st.rerun()

    st.markdown("---")
    st.caption(
        "Try: 'Where is my order ORD1001?' · "
        "'En order eppo varum, ORD1006' · "
        "'உங்கள் திரும்ப அளிக்கும் கொள்கை என்ன?' · "
        "'Someone made an unauthorized charge on my card' (escalates)"
    )

st.title("🛒 Multilingual E-commerce Support Bot")
st.caption("Handles English, Tamil, and code-switched Tamil-English queries about orders, returns, refunds, and payments.")

for role, text, meta in st.session_state.messages:
    with st.chat_message(role):
        st.write(text)
        if meta:
            st.caption(meta)

user_message = st.chat_input("Type your message in English, Tamil, or mixed Tamil-English...")

if user_message:
    st.session_state.messages.append(("user", user_message, None))
    with st.chat_message("user"):
        st.write(user_message)

    result = st.session_state.orchestrator.handle_message(user_message)

    meta_bits = [
        f"lang={result.detected_language['language']}",
        f"intent={result.intent}",
        f"route={result.route}",
        f"confidence={result.confidence:.2f}",
    ]
    if result.escalated:
        meta_bits.append(f"⚠️ escalated: {result.escalation_reason}")
    if result.retrieved_chunks:
        sources = ", ".join(sorted({c["source"] for c in result.retrieved_chunks}))
        meta_bits.append(f"sources: {sources}")
    if result.tool_name:
        meta_bits.append(f"tool: {result.tool_name}")

    meta_str = " | ".join(meta_bits)

    st.session_state.messages.append(("assistant", result.final_answer, meta_str))
    with st.chat_message("assistant"):
        st.write(result.final_answer)
        st.caption(meta_str)
