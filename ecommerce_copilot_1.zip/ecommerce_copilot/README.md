# E-commerce ReAct Support Copilot

A single-agent **ReAct (Reason → Act → Observe)** customer-support assistant for order/return/refund/payment/FAQ
questions, built with a retrieval pipeline (RAG) over a local policy corpus, a small allow-listed tool set (mock
order/returns/refund APIs), and a **sentiment-aware de-escalation gate** that routes technically-correct-but-badly
delivered answers to a human agent instead.

> **The twist:** most support bots answer the literal question and miss that the customer is furious. This project
> adds a lightweight, explainable frustration/urgency classifier that runs *before* the ReAct loop and gates the
> final answer — high-frustration + policy-denial combinations get escalated to a human instead of a flat "no."

Runs **fully offline by default** — no API keys, no network access required for the full pipeline (indexing,
retrieval, ReAct loop, evaluation). See [LLM backend](#llm-backend) below to plug in a real Claude call.

---

## Project Structure

```
ecommerce_copilot/
├── corpus/                        # Policy/FAQ knowledge base (markdown + PDF)
│   ├── return_policy.md
│   ├── refund_policy.md
│   ├── shipping_policy.md
│   ├── payment_policy.md
│   ├── warranty_policy.md
│   ├── faq_general.md
│   ├── escalation_policy.md       # internal: when the assistant must escalate
│   ├── account_terms.pdf          # multi-page PDF (tests [file:pN] citations)
│   └── product_care_guide.pdf
├── data/
│   ├── mock_orders.json           # 13 mock orders
│   ├── mock_customers.json        # 10 mock customers (return/contact history)
│   └── evaluation_questions.csv   # 22 labeled eval questions
├── src/
│   ├── config.py                  # thresholds, allow-lists, guardrails (all tunables in one place)
│   ├── corpus_index.py            # chunking + TF-IDF "embeddings" + vector search
│   ├── sentiment.py                # frustration/urgency/repeat-contact/legal-threat classifier
│   ├── tools.py                    # mock backend tools + RAG tools, allow-listed
│   ├── llm_client.py                # pluggable LLM backend (mock offline / real Anthropic)
│   ├── agent.py                     # the ReAct loop + escalation gate + answer synthesis
│   ├── baseline.py                  # LLM-only, no-tools baseline (for comparison eval)
│   └── logging_utils.py             # standardized run-log CSV writer
├── eval/
│   ├── run_eval.py                  # runs baseline vs ReAct+tools over evaluation_questions.csv
│   ├── eval_report.md               # generated: metrics + failure cases (see below)
│   ├── results_react.csv            # generated: per-question ReAct results
│   └── results_baseline.csv         # generated: per-question baseline results
├── notebook/
│   └── react_copilot_notebook.ipynb # indexing → retrieval → ReAct loop → evaluation, end-to-end
├── react_copilot.py                 # CLI entry point
├── app.py                           # Flask web UI entry point
├── webapp/
│   ├── templates/index.html         # chat + live agent-trace console
│   └── static/{style.css,script.js}
├── TECHNICAL_REPORT.md
└── README.md
```

---

## Setup

Requires Python 3.9+. Dependencies: `scikit-learn`, `pypdf`, `reportlab` (used only to *generate* the sample
PDF corpus), `pandas`, `matplotlib` (for the notebook chart). All are common/lightweight — no GPU, no vector DB
server, no embeddings model download.

```bash
pip install scikit-learn pypdf reportlab pandas matplotlib flask
```

No `.env` or API key is required to run anything in this repo by default.

---

## Running It

### CLI

```bash
# ReAct + tools (default)
python react_copilot.py --question "Where is my order ORD1001?" --order-id ORD1001 --customer-id CUST01

# An angry, repeat-contact refund dispute -> should escalate
python react_copilot.py \
  --question "This is the SECOND time I'm messaging about ORD1005. I never got my speaker and now no refund?! This is ridiculous." \
  --order-id ORD1005 --customer-id CUST05

# Interactive REPL
python react_copilot.py --interactive
# then type e.g.:  order=ORD1001 customer=CUST01 :: Where is my order?

# No-tools baseline, for side-by-side comparison
python react_copilot.py --question "..." --baseline
```

Every run prints:
- the detected intent + sentiment/frustration scores
- a step-by-step **Action / Observation** trace (what the agent looked up and why)
- the escalation decision + reasons
- the final answer with inline `[file:line]` / `[file:pN]` citations

Runs are also logged (unless `--no-log`) to `eval/logs/cli_runs.csv` in the standardized run-log format.

### Web UI

```bash
pip install flask   # if not already installed
python app.py
```

Then open **http://localhost:5000** in your browser. This gives you a two-panel "support console":
the conversation on the left, and a **live agent trace** on the right showing every Thought → Action →
Observation step, the sentiment/frustration reading, and the escalation decision as it happens. A toggle
in the top bar switches between ReAct+Tools and the LLM-only baseline so you can compare them side by side
on the same question.

Try the calm order-status example first, then the angry repeat-contact refund dispute, to see the
escalation gate visibly kick in.

### Notebook

```bash
jupyter notebook notebook/react_copilot_notebook.ipynb
```

Walks through indexing → retrieval → sentiment classification → the ReAct loop → the baseline comparison →
the full 22-question evaluation, with a results chart.

### Evaluation

```bash
python eval/run_eval.py
```

Runs both systems over all 22 questions in `data/evaluation_questions.csv` and (re-)writes:
`eval/results_react.csv`, `eval/results_baseline.csv`, `eval/eval_report.md`.

---

## Architecture at a Glance

```
customer message
      │
      ▼
[sentiment.classify()]  ──► frustration/urgency/repeat-contact/legal-threat scores
      │                     (runs BEFORE retrieval — tone detection isn't skewed by evidence)
      ▼
┌─────────────────────────── ReAct loop (max 6 steps) ───────────────────────────┐
│  Reason: rule-based planner decides the next tool call given current state     │
│  Act:    call ONE allow-listed tool (search / open_file / read_chunk /         │
│          get_order_status / create_return_request / get_refund_policy /       │
│          get_customer_history) — validated, retried (up to 2x), timed          │
│  Observe: structured dict result appended to agent state                       │
│  (repeat until planner says "finish" or max steps reached)                     │
└──────────────────────────────────────────────────────────────────────────────────┘
      │
      ▼
[escalation gate] ── combines sentiment + evidence (denial-shaped answer? disputed
      │              delivery? outside all policy exception windows? legal threat?
      │              explicit human request?) → escalate: yes/no + reasons
      ▼
[answer synthesis] ── cited, de-escalation-aware final answer, e.g.:
      "I understand this has been frustrating... [refund_policy.md:L20-27]
       I'm escalating this to a human agent. (reason: ...)"
```

## Guardrails

| Guardrail | Where | Behavior |
|---|---|---|
| Tool allow-list | `config.ALLOWED_TOOLS`, enforced in `agent._safe_call_tool` | Any tool not in the allow-list is rejected before execution, never silently ignored |
| Max steps | `config.MAX_STEPS` (6) | ReAct loop hard-stops; result is marked `stopped_reason="max_steps_reached"` |
| Retry policy | `config.MAX_TOOL_RETRIES` (2) | Retries transient/malformed errors; does NOT retry hard "not found"/"invalid ID" errors (no point) |
| Per-call timing | `Step.latency_ms` | Every tool call's wall-clock time is logged for later timeout-tuning |
| Input validation | each tool in `tools.py` | Order IDs, file names, and chunk IDs are validated before use; never a raw exception surfaces to the agent |
| Mutating-tool tracking | `config.MUTATING_TOOLS` | `create_return_request` is flagged as state-changing and logged distinctly |

## LLM Backend

Set via `COPILOT_LLM_BACKEND` env var:

- `mock` (default) — a fully offline, deterministic rule-based planner + template synthesizer. Chosen so the
  **entire project** (notebook, CLI, evaluation) is reproducible with zero credentials. The interesting logic
  (tool orchestration, guardrails, citation enforcement, escalation gating) lives in `agent.py`, not inside a
  black-box LLM call, so it's fully inspectable/testable.
- `anthropic` — real Claude call via the `anthropic` SDK. Set `ANTHROPIC_API_KEY` and:
  ```bash
  export COPILOT_LLM_BACKEND=anthropic
  export COPILOT_ANTHROPIC_MODEL=claude-sonnet-5   # or another available model
  ```
  Swapping backends requires no changes to `agent.py`, `tools.py`, or the CLI — only `llm_client.py`'s
  `LLMClient.complete()` implementation differs.

## Known Limitations (see TECHNICAL_REPORT.md for the full write-up)

- TF-IDF retrieval occasionally picks the wrong near-duplicate policy source when two documents cover very
  similar content (e.g. `warranty_policy.md` vs `product_care_guide.pdf` both discuss the Extended Protection
  Plan) — a real embeddings model would likely disambiguate this better via semantic similarity.
- The rule-based intent classifier and sentiment lexicon are transparent and auditable but not as flexible as
  a trained/LLM-based classifier for messages with unusual phrasing.
- Word-window chunking (for markdown) occasionally splits a bullet list mid-sentence; paragraph/heading-aware
  chunking would be a cleaner fix.
