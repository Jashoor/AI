const messagesEl = document.getElementById("messages");
const traceLogEl = document.getElementById("traceLog");
const traceMetaEl = document.getElementById("traceMeta");
const composer = document.getElementById("composer");
const questionEl = document.getElementById("question");
const orderSelect = document.getElementById("orderSelect");
const customerSelect = document.getElementById("customerSelect");
const sendBtn = document.getElementById("sendBtn");
const modeToggle = document.getElementById("modeToggle");

let mode = "react";
let firstMessageSent = false;

modeToggle.addEventListener("click", (e) => {
  const btn = e.target.closest(".mode-btn");
  if (!btn) return;
  document.querySelectorAll(".mode-btn").forEach((b) => b.classList.remove("active"));
  btn.classList.add("active");
  mode = btn.dataset.mode;
});

function clearEmptyState(container) {
  const empty = container.querySelector(".empty-state");
  if (empty) empty.remove();
}

function addUserBubble(text) {
  clearEmptyState(messagesEl);
  const div = document.createElement("div");
  div.className = "bubble user";
  div.textContent = text;
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function addAssistantBubble(data) {
  clearEmptyState(messagesEl);
  const div = document.createElement("div");
  div.className = "bubble assistant" + (data.escalated ? " escalated" : "");

  const answer = document.createElement("div");
  answer.textContent = data.answer;
  div.appendChild(answer);

  if (data.citations && data.citations.length) {
    const citeWrap = document.createElement("div");
    citeWrap.className = "citations";
    data.citations.forEach((c) => {
      const tag = document.createElement("span");
      tag.className = "citation-tag";
      tag.textContent = c;
      citeWrap.appendChild(tag);
    });
    div.appendChild(citeWrap);
  }

  if (data.escalated) {
    const banner = document.createElement("div");
    banner.className = "escalation-banner";
    banner.textContent = "\u26A0 Escalated to a human agent";
    div.appendChild(banner);
  }

  if (data.hallucinated_citation_like_text) {
    const banner = document.createElement("div");
    banner.className = "hallucination-banner";
    banner.textContent = "\u26A0 Citation-shaped text with no real source (baseline has no retrieval)";
    div.appendChild(banner);
  }

  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function renderMeta(data) {
  traceMetaEl.innerHTML = "";
  const chips = [];

  if (data.mode === "baseline") {
    chips.push(["no retrieval / no tools", "idle"]);
    chips.push(["no escalation gate", "idle"]);
  } else {
    const level = data.sentiment ? data.sentiment.frustration_level : "low";
    chips.push([`frustration: ${level}`, `frustration-${level}`]);
    chips.push([data.escalated ? "escalated" : "not escalated", data.escalated ? "escalated" : "not-escalated"]);
    chips.push([`${data.steps.length} step${data.steps.length === 1 ? "" : "s"}`, "idle"]);
  }

  chips.forEach(([label, cls]) => {
    const span = document.createElement("span");
    span.className = "meta-chip " + cls;
    span.textContent = label;
    traceMetaEl.appendChild(span);
  });
}

function renderTrace(data) {
  clearEmptyState(traceLogEl);
  traceLogEl.innerHTML = "";

  if (data.mode === "baseline") {
    const note = document.createElement("div");
    note.className = "trace-step";
    note.innerHTML = `<div class="trace-step-header">NO TOOL CALLS</div>
      <div class="trace-line trace-text">This mode answers directly from general knowledge, with no retrieval,
      no order lookup, and no sentiment gate -- for comparison against ReAct + Tools.</div>`;
    traceLogEl.appendChild(note);
    return;
  }

  if (!data.steps.length) {
    const note = document.createElement("div");
    note.className = "trace-step";
    note.innerHTML = `<div class="trace-step-header">PLANNER</div>
      <div class="trace-line trace-text">No tool calls were needed -- enough was already known to answer.</div>`;
    traceLogEl.appendChild(note);
  }

  data.steps.forEach((s) => {
    const div = document.createElement("div");
    div.className = "trace-step";
    const obsStr = JSON.stringify(s.observation, null, 2);
    div.innerHTML = `
      <div class="trace-step-header">STEP ${s.step_no} &middot; ${s.latency_ms}ms${s.retries ? " &middot; " + s.retries + " retries" : ""}</div>
      <div class="trace-line"><span class="tag thought">THOUGHT</span><span class="trace-text">${escapeHtml(s.thought)}</span></div>
      <div class="trace-line"><span class="tag action">ACTION</span><span class="trace-text">${escapeHtml(s.action)}(${escapeHtml(JSON.stringify(s.action_input))})</span></div>
      <div class="trace-line"><span class="tag observation">OBSERVATION</span></div>
      <div class="obs-json">${escapeHtml(obsStr)}</div>
    `;
    traceLogEl.appendChild(div);
  });

  if (data.escalation_reasons && data.escalation_reasons.length) {
    const div = document.createElement("div");
    div.className = "trace-step";
    div.style.borderColor = "var(--escalate)";
    div.innerHTML = `<div class="trace-step-header" style="color: var(--escalate)">ESCALATION GATE</div>` +
      data.escalation_reasons.map((r) => `<div class="trace-line trace-text">&bull; ${escapeHtml(r)}</div>`).join("");
    traceLogEl.appendChild(div);
  }

  const footer = document.createElement("div");
  footer.className = "trace-footer";
  footer.textContent = `stopped: ${data.stopped_reason}`;
  traceLogEl.appendChild(footer);

  traceLogEl.scrollTop = traceLogEl.scrollHeight;
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

composer.addEventListener("submit", async (e) => {
  e.preventDefault();
  const question = questionEl.value.trim();
  if (!question) return;

  addUserBubble(question);
  questionEl.value = "";
  sendBtn.disabled = true;
  sendBtn.textContent = "Thinking...";
  traceLogEl.innerHTML = '<div class="empty-state small">Working...</div>';

  try {
    const res = await fetch("/api/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        question,
        order_id: orderSelect.value,
        customer_id: customerSelect.value,
        mode,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      addAssistantBubble({ answer: "Error: " + (data.error || "unknown error"), citations: [], escalated: false });
      traceLogEl.innerHTML = '<div class="empty-state small">No trace -- request failed.</div>';
    } else {
      addAssistantBubble(data);
      renderMeta(data);
      renderTrace(data);
    }
  } catch (err) {
    addAssistantBubble({ answer: "Network error: " + err.message, citations: [], escalated: false });
  } finally {
    sendBtn.disabled = false;
    sendBtn.textContent = "Send";
  }
});
