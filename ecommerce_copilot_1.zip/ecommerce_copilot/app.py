#!/usr/bin/env python3
"""
Local web UI for the E-commerce ReAct Support Copilot.

Run:
    python app.py
Then open:
    http://localhost:5000

This is a thin Flask wrapper around the same ReactAgent / baseline used by
the CLI (react_copilot.py) -- no logic is duplicated. It exists purely to
visualize the ReAct trace (Thought -> Action -> Observation), the sentiment
gate, the escalation decision, and the final cited answer in a browser.
"""
import os
import sys

from flask import Flask, jsonify, render_template, request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.agent import ReactAgent
from src.baseline import run_baseline
from src import tools as tools_mod

app = Flask(__name__, template_folder="webapp/templates", static_folder="webapp/static")
agent = ReactAgent()


@app.route("/")
def index():
    orders = sorted(tools_mod._ORDERS.keys())
    customers = sorted(tools_mod._CUSTOMERS.keys())
    return render_template("index.html", orders=orders, customers=customers)


@app.route("/api/ask", methods=["POST"])
def api_ask():
    data = request.get_json(force=True) or {}
    question = (data.get("question") or "").strip()
    order_id = (data.get("order_id") or "").strip() or None
    customer_id = (data.get("customer_id") or "").strip() or None
    mode = data.get("mode", "react")

    if not question:
        return jsonify({"error": "Question is required."}), 400

    if mode == "baseline":
        b = run_baseline(question, order_id=order_id, customer_id=customer_id)
        return jsonify({
            "mode": "baseline",
            "intent": b.intent,
            "sentiment": None,
            "steps": [],
            "escalated": False,
            "escalation_reasons": [],
            "answer": b.answer,
            "citations": b.citations,
            "hallucinated_citation_like_text": b.hallucinated_citation_like_text,
            "stopped_reason": "n/a",
        })

    r = agent.run(question, order_id=order_id, customer_id=customer_id)
    steps_out = []
    for s in r.steps:
        obs = {k: v for k, v in s.observation.items() if k != "_latency_ms"}
        steps_out.append({
            "step_no": s.step_no,
            "thought": s.thought,
            "action": s.action,
            "action_input": s.action_input,
            "observation": obs,
            "latency_ms": round(s.latency_ms, 2),
            "retries": s.retries,
        })

    return jsonify({
        "mode": "react",
        "intent": r.intent,
        "sentiment": r.sentiment,
        "steps": steps_out,
        "escalated": r.escalated,
        "escalation_reasons": r.escalation_reasons,
        "answer": r.answer,
        "citations": r.citations,
        "stopped_reason": r.stopped_reason,
    })


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"\nSupport Copilot Console running at http://localhost:{port}\n")
    app.run(host="0.0.0.0", port=port, debug=True)
