"""Unit tests for the deterministic (non-LLM) calculation agents — these are
the parts of the spec where correctness matters most and is fully verifiable."""
import numpy as np
from app.agents.technical_analysis_agent import TechnicalAnalysisAgent
from app.agents.fundamental_analysis_agent import FundamentalAnalysisAgent
from app.agents.risk_agent import RiskAgent
from app.schemas import DecisionOutput, Recommendation


def _fake_market_data(n=120, trend=0.001, seed=42):
    rng = np.random.default_rng(seed)
    prices = [100.0]
    for _ in range(n - 1):
        prices.append(prices[-1] * (1 + trend + rng.normal(0, 0.01)))
    highs = [p * 1.01 for p in prices]
    lows = [p * 0.99 for p in prices]
    opens = [p * 0.999 for p in prices]
    volumes = [int(1_000_000 + rng.normal(0, 50_000)) for _ in prices]
    return {
        "ticker": "TEST",
        "ohlcv": {"close": prices, "open": opens, "high": highs, "low": lows, "volume": volumes,
                  "dates": [str(i) for i in range(n)]},
        "last_price": prices[-1],
        "pe_ratio": 18.0,
    }


def test_technical_indicators_run_and_bounded():
    agent = TechnicalAnalysisAgent()
    result = agent.run(_fake_market_data())
    assert 0 <= result["rsi_14"] <= 100
    assert "macd" in result
    assert result["support"] <= result["resistance"]
    assert isinstance(result["signal_summary"], str)


def test_technical_analysis_requires_min_history():
    agent = TechnicalAnalysisAgent()
    short_data = _fake_market_data(n=10)
    try:
        agent.run(short_data)
        assert False, "should have raised"
    except ValueError:
        pass


def test_fundamental_ratios_handle_missing_data_gracefully():
    agent = FundamentalAnalysisAgent()
    result = agent.run({"fundamentals_raw": {}, "last_price": 100, "pe_ratio": None})
    assert result["roe_pct"] is None
    assert result["current_price"] == 100


def test_fundamental_ratios_compute_correctly():
    agent = FundamentalAnalysisAgent()
    raw = {
        "net_income": 100, "total_equity": 500,       # ROE = 20%
        "ebit": 150, "capital_employed": 1000,        # ROCE = 15%
        "total_debt": 250,                             # D/E = 0.5
        "eps_current": 5.0, "eps_prior": 4.0,          # EPS growth = 25%
        "revenue_current": 1100, "revenue_prior": 1000,  # rev growth = 10%
    }
    result = agent.run({"fundamentals_raw": raw, "last_price": 100, "pe_ratio": 20})
    assert result["roe_pct"] == 20.0
    assert result["roce_pct"] == 15.0
    assert result["debt_equity"] == 0.5
    assert result["eps_growth_pct"] == 25.0
    assert result["revenue_growth_pct"] == 10.0


def test_risk_agent_blocks_on_drawdown_breach():
    agent = RiskAgent()
    decision = DecisionOutput(ticker="TEST", recommendation=Recommendation.BUY, confidence=0.8,
                               reasons=["test"], evidence=[], sources=[])
    technicals = {"atr_14": 2.0, "vwap": 100.0}
    result = agent.run(decision, technicals, portfolio={"current_drawdown_pct": 0.20})
    assert result.passed is False
    assert any("drawdown" in v.lower() for v in result.violations)


def test_risk_agent_passes_under_normal_conditions():
    agent = RiskAgent()
    decision = DecisionOutput(ticker="TEST", recommendation=Recommendation.BUY, confidence=0.7,
                               reasons=["test"], evidence=[], sources=[])
    technicals = {"atr_14": 1.0, "vwap": 100.0}
    result = agent.run(decision, technicals, portfolio={})
    assert result.passed is True
    assert 0 <= result.risk_score <= 1
