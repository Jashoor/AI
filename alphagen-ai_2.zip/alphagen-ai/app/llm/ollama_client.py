"""Thin client for local Ollama inference. This is the ONLY place LLM calls
happen in the whole system — every agent that needs 'reasoning, synthesis,
explanation, or critique' goes through here. Deterministic math NEVER does.

If Ollama isn't running, we degrade gracefully to a rule-based fallback so the
whole pipeline still runs end-to-end for demo/testing purposes.
"""
import json
import logging
from typing import Optional
import httpx
from app.config import settings

logger = logging.getLogger("alphagen.llm")


class LLMUnavailable(Exception):
    pass


class OllamaClient:
    def __init__(self, base_url: str = None):
        self.base_url = base_url or settings.OLLAMA_BASE_URL

    def is_available(self) -> bool:
        try:
            r = httpx.get(f"{self.base_url}/api/tags", timeout=2.0)
            return r.status_code == 200
        except Exception:
            return False

    def generate(self, model: str, prompt: str, system: Optional[str] = None,
                 json_mode: bool = False, timeout: float = 60.0) -> str:
        payload = {
            "model": model,
            "prompt": prompt,
            "system": system or "",
            "stream": False,
        }
        if json_mode:
            payload["format"] = "json"
        try:
            resp = httpx.post(f"{self.base_url}/api/generate", json=payload, timeout=timeout)
            resp.raise_for_status()
            data = resp.json()
            return data.get("response", "")
        except Exception as e:
            logger.warning(f"Ollama call failed ({model}): {e}")
            raise LLMUnavailable(str(e))

    def generate_json(self, model: str, prompt: str, system: Optional[str] = None,
                       timeout: float = 60.0) -> dict:
        raw = self.generate(model, prompt, system=system, json_mode=True, timeout=timeout)
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            start, end = raw.find("{"), raw.rfind("}")
            if start != -1 and end != -1:
                return json.loads(raw[start:end + 1])
            raise


llm = OllamaClient()
