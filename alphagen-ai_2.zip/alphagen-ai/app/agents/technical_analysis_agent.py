"""Technical Analysis Agent — 100% deterministic Python/pandas. No LLM anywhere
in this file, by design (per spec: 'Never use LLMs to perform deterministic
calculations'). Implements RSI, MACD, EMA, SMA, ATR, ADX, VWAP, Bollinger
Bands, SuperTrend, and simple support/resistance."""
import pandas as pd
import numpy as np


class TechnicalAnalysisAgent:
    name = "technical_analysis_agent"

    def run(self, market_data: dict) -> dict:
        ohlcv = market_data["ohlcv"]
        df = pd.DataFrame({
            "open": ohlcv["open"],
            "high": ohlcv["high"],
            "low": ohlcv["low"],
            "close": ohlcv["close"],
            "volume": ohlcv["volume"],
        })
        if len(df) < 20:
            raise ValueError("Not enough history for technical analysis (need >= 20 bars)")

        close, high, low, vol = df["close"], df["high"], df["low"], df["volume"]

        result = {
            "sma_20": self._sma(close, 20).iloc[-1],
            "sma_50": self._sma(close, 50).iloc[-1] if len(df) >= 50 else None,
            "ema_12": self._ema(close, 12).iloc[-1],
            "ema_26": self._ema(close, 26).iloc[-1],
            "rsi_14": self._rsi(close, 14).iloc[-1],
            "atr_14": self._atr(df, 14).iloc[-1],
            "adx_14": self._adx(df, 14).iloc[-1],
            "vwap": self._vwap(df).iloc[-1],
        }
        macd_line, signal_line, hist = self._macd(close)
        result["macd"] = {
            "macd_line": macd_line.iloc[-1],
            "signal_line": signal_line.iloc[-1],
            "histogram": hist.iloc[-1],
        }
        upper, mid, lower = self._bollinger_bands(close)
        result["bollinger_bands"] = {
            "upper": upper.iloc[-1], "middle": mid.iloc[-1], "lower": lower.iloc[-1]
        }
        result["supertrend"] = self._supertrend(df).iloc[-1]
        result["support"], result["resistance"] = self._support_resistance(df)

        result = {k: (round(float(v), 4) if isinstance(v, (int, float, np.floating)) and v is not None
                      else ({kk: round(float(vv), 4) if vv is not None else None for kk, vv in v.items()}
                            if isinstance(v, dict) else v))
                   for k, v in result.items()}
        result["signal_summary"] = self._summarize(result)
        return result

    # ---- indicator implementations ----
    @staticmethod
    def _sma(series: pd.Series, window: int) -> pd.Series:
        return series.rolling(window=window).mean()

    @staticmethod
    def _ema(series: pd.Series, span: int) -> pd.Series:
        return series.ewm(span=span, adjust=False).mean()

    @staticmethod
    def _rsi(series: pd.Series, window: int = 14) -> pd.Series:
        delta = series.diff()
        gain = delta.clip(lower=0)
        loss = -delta.clip(upper=0)
        avg_gain = gain.ewm(alpha=1 / window, adjust=False).mean()
        avg_loss = loss.ewm(alpha=1 / window, adjust=False).mean()
        rs = avg_gain / avg_loss.replace(0, np.nan)
        rsi = 100 - (100 / (1 + rs))
        return rsi.fillna(50)

    def _macd(self, series: pd.Series, fast=12, slow=26, signal=9):
        macd_line = self._ema(series, fast) - self._ema(series, slow)
        signal_line = macd_line.ewm(span=signal, adjust=False).mean()
        hist = macd_line - signal_line
        return macd_line, signal_line, hist

    @staticmethod
    def _atr(df: pd.DataFrame, window: int = 14) -> pd.Series:
        high, low, close = df["high"], df["low"], df["close"]
        prev_close = close.shift(1)
        tr = pd.concat([
            high - low,
            (high - prev_close).abs(),
            (low - prev_close).abs(),
        ], axis=1).max(axis=1)
        return tr.ewm(alpha=1 / window, adjust=False).mean()

    def _adx(self, df: pd.DataFrame, window: int = 14) -> pd.Series:
        high, low, close = df["high"], df["low"], df["close"]
        up_move = high.diff()
        down_move = -low.diff()
        plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)
        minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)
        atr = self._atr(df, window)
        plus_di = 100 * pd.Series(plus_dm, index=df.index).ewm(alpha=1 / window, adjust=False).mean() / atr.replace(0, np.nan)
        minus_di = 100 * pd.Series(minus_dm, index=df.index).ewm(alpha=1 / window, adjust=False).mean() / atr.replace(0, np.nan)
        dx = ((plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)) * 100
        return dx.ewm(alpha=1 / window, adjust=False).mean().fillna(0)

    @staticmethod
    def _vwap(df: pd.DataFrame) -> pd.Series:
        typical_price = (df["high"] + df["low"] + df["close"]) / 3
        return (typical_price * df["volume"]).cumsum() / df["volume"].cumsum()

    def _bollinger_bands(self, series: pd.Series, window: int = 20, num_std: float = 2.0):
        mid = self._sma(series, window)
        std = series.rolling(window=window).std()
        return mid + num_std * std, mid, mid - num_std * std

    def _supertrend(self, df: pd.DataFrame, period: int = 10, multiplier: float = 3.0) -> pd.Series:
        atr = self._atr(df, period)
        hl2 = (df["high"] + df["low"]) / 2
        upper_band = hl2 + multiplier * atr
        lower_band = hl2 - multiplier * atr
        supertrend = pd.Series(index=df.index, dtype=float)
        direction = 1
        for i in range(len(df)):
            if i == 0:
                supertrend.iloc[i] = lower_band.iloc[i]
                continue
            if df["close"].iloc[i] > upper_band.iloc[i - 1]:
                direction = 1
            elif df["close"].iloc[i] < lower_band.iloc[i - 1]:
                direction = -1
            supertrend.iloc[i] = lower_band.iloc[i] if direction == 1 else upper_band.iloc[i]
        return supertrend

    @staticmethod
    def _support_resistance(df: pd.DataFrame, window: int = 20):
        recent = df.tail(window)
        return round(float(recent["low"].min()), 4), round(float(recent["high"].max()), 4)

    @staticmethod
    def _summarize(indicators: dict) -> str:
        signals = []
        rsi = indicators.get("rsi_14")
        if rsi is not None:
            if rsi < 30:
                signals.append("RSI oversold")
            elif rsi > 70:
                signals.append("RSI overbought")
        macd = indicators.get("macd", {})
        if macd.get("histogram") is not None:
            signals.append("MACD bullish crossover" if macd["histogram"] > 0 else "MACD bearish crossover")
        return "; ".join(signals) if signals else "No strong signal"
