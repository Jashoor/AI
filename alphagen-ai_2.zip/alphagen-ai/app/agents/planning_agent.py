"""Planning Agent (LLM) — decides the execution plan for a request using a
ReAct-style reasoning step. For this reference implementation the DAG shape
is fixed (matches the spec's architecture diagram), but the LLM still decides
*parameters* of the plan (e.g. whether sentiment/RAG steps are worth running
for this ticker, how many news items to pull) — this is the 'planning is LLM,
execution is deterministic' boundary in action. Falls back to sensible
defaults if the LLM is unavailable."""
import logging
from app.config import settings
from app.llm.ollama_client import llm, LLMUnavailable

logger = logging.getLogger("alphagen.planning")

_SYSTEM_PROMPT = (
    "You are a planning agent for a financial analysis pipeline. Given a ticker "
    "and request notes, decide which optional analysis steps are worth running. "
    "Think step by step (ReAct: Thought -> Action) but output ONLY final JSON: "
    "{\"run_sentiment\": bool, \"run_rag\": bool, \"news_items\": int (1-10), "
    "\"reasoning\": string}."
)

_DEFAULT_PLAN = {"run_sentiment": True, "run_rag": True, "news_items": 6,
                  "reasoning": "Default plan (LLM planner unavailable)"}


class PlanningAgent:
    name = "planning_agent"

    def run(self, ticker: str, notes: str | None = None) -> dict:
        prompt = f"Ticker: {ticker}\nUser notes: {notes or 'none'}\nProduce the plan JSON."
        try:
            plan = llm.generate_json(settings.PLANNING_MODEL, prompt, system=_SYSTEM_PROMPT)
            plan.setdefault("run_sentiment", True)
            plan.setdefault("run_rag", True)
            plan.setdefault("news_items", 6)
            plan["news_items"] = max(1, min(10, int(plan["news_items"])))
            return plan
        except (LLMUnavailable, Exception) as e:
            logger.info(f"Planning LLM unavailable ({e}); using default plan")
            return dict(_DEFAULT_PLAN)
