"""Fundamental Analysis Agent — pure Python. Computes ROE, ROCE, EPS growth,
revenue growth, D/E, PEG, cash flow health, and a simple intrinsic value
(discounted cash flow / Graham-number style estimate). No LLM."""
import math


class FundamentalAnalysisAgent:
    name = "fundamental_analysis_agent"

    def run(self, market_data: dict) -> dict:
        """market_data['fundamentals_raw'] is expected to hold raw statement
        figures pulled by the MarketDataAgent (yfinance .info / financials).
        We compute defensively — any missing field just becomes None rather
        than crashing the whole pipeline."""
        raw = market_data.get("fundamentals_raw", {}) or {}

        net_income = raw.get("net_income")
        equity = raw.get("total_equity")
        ebit = raw.get("ebit")
        capital_employed = raw.get("capital_employed")
        total_debt = raw.get("total_debt")
        eps_current = raw.get("eps_current")
        eps_prior = raw.get("eps_prior")
        revenue_current = raw.get("revenue_current")
        revenue_prior = raw.get("revenue_prior")
        pe_ratio = market_data.get("pe_ratio")
        eps_growth_estimate = raw.get("eps_growth_estimate")
        free_cash_flow = raw.get("free_cash_flow")
        book_value_per_share = raw.get("book_value_per_share")

        roe = self._safe_pct(net_income, equity)
        roce = self._safe_pct(ebit, capital_employed)
        debt_equity = self._safe_ratio(total_debt, equity)
        eps_growth = self._growth_pct(eps_current, eps_prior)
        revenue_growth = self._growth_pct(revenue_current, revenue_prior)
        peg = self._peg(pe_ratio, eps_growth_estimate or eps_growth)
        intrinsic_value = self._graham_number(eps_current, book_value_per_share)

        return {
            "roe_pct": roe,
            "roce_pct": roce,
            "debt_equity": debt_equity,
            "eps_growth_pct": eps_growth,
            "revenue_growth_pct": revenue_growth,
            "peg_ratio": peg,
            "free_cash_flow": free_cash_flow,
            "intrinsic_value_estimate": intrinsic_value,
            "current_price": market_data.get("last_price"),
            "valuation_note": self._valuation_note(intrinsic_value, market_data.get("last_price")),
        }

    @staticmethod
    def _safe_pct(numerator, denominator):
        if numerator is None or denominator in (None, 0):
            return None
        return round((numerator / denominator) * 100, 2)

    @staticmethod
    def _safe_ratio(a, b):
        if a is None or b in (None, 0):
            return None
        return round(a / b, 2)

    @staticmethod
    def _growth_pct(current, prior):
        if current is None or prior in (None, 0):
            return None
        return round(((current - prior) / abs(prior)) * 100, 2)

    @staticmethod
    def _peg(pe_ratio, growth_pct):
        if pe_ratio is None or not growth_pct:
            return None
        return round(pe_ratio / growth_pct, 2)

    @staticmethod
    def _graham_number(eps, book_value_per_share):
        # Graham Number = sqrt(22.5 * EPS * Book Value per Share) — a rough,
        # conservative intrinsic-value heuristic, entirely deterministic.
        if not eps or not book_value_per_share or eps <= 0 or book_value_per_share <= 0:
            return None
        return round(math.sqrt(22.5 * eps * book_value_per_share), 2)

    @staticmethod
    def _valuation_note(intrinsic_value, current_price):
        if intrinsic_value is None or current_price is None:
            return "Insufficient data for valuation comparison"
        diff_pct = ((current_price - intrinsic_value) / intrinsic_value) * 100
        if diff_pct > 15:
            return f"Price ~{round(diff_pct, 1)}% above intrinsic estimate (possibly overvalued)"
        elif diff_pct < -15:
            return f"Price ~{round(abs(diff_pct), 1)}% below intrinsic estimate (possibly undervalued)"
        return "Price roughly in line with intrinsic estimate"
