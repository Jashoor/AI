"""Memory Agent — thin facade unifying short-term (workflow scratch),
long-term (SQLite trade history/preferences/reflexion), and vector (FAISS/
TF-IDF document) memory, so other agents/orchestrator code have one import."""
from app.memory.short_term import short_term_memory
from app.memory.long_term import long_term_memory
from app.memory.vector_store import vector_store


class MemoryAgent:
    name = "memory_agent"

    def persist_workflow_result(self, trace_id: str, state: dict):
        short_term_memory.set(f"workflow:{trace_id}", state, ttl=3600)

    def get_workflow_result(self, trace_id: str):
        return short_term_memory.get(f"workflow:{trace_id}")

    def add_reflexion(self, trace_id: str, ticker: str, note: str):
        long_term_memory.add_reflexion_note(trace_id, ticker, note)

    def get_reflexion_history(self, ticker: str):
        return long_term_memory.get_reflexion_notes(ticker)

    def get_trade_history(self, ticker: str | None = None):
        return long_term_memory.get_trade_history(ticker=ticker)


memory_agent = MemoryAgent()
