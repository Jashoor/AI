"""Sentiment Agent — analyzes social/forum chatter sentiment. Uses FinBERT if
transformers/torch are installed (uncomment in requirements.txt); otherwise
falls back to a finance-tuned lexicon scorer. No GPT/paid API required either
way, matching the spec."""
import re
import logging

logger = logging.getLogger("alphagen.sentiment")

try:
    from transformers import pipeline  # type: ignore
    _finbert = pipeline("sentiment-analysis", model="ProsusAI/finbert")
    _HAS_FINBERT = True
except Exception:
    _HAS_FINBERT = False

_POSITIVE_WORDS = {
    "beat", "beats", "surge", "surged", "rally", "bullish", "upgrade", "upgraded",
    "outperform", "growth", "record", "strong", "profit", "gain", "gains", "buyback",
    "expansion", "breakthrough", "momentum",
}
_NEGATIVE_WORDS = {
    "miss", "missed", "plunge", "plunged", "bearish", "downgrade", "downgraded",
    "underperform", "loss", "losses", "lawsuit", "recall", "fraud", "investigation",
    "weak", "decline", "layoffs", "bankruptcy", "default", "delisted",
}


class SentimentAgent:
    name = "sentiment_agent"

    def run(self, texts: list[str]) -> dict:
        if not texts:
            return {"overall_sentiment": "neutral", "score": 0.0, "sample_size": 0, "method": "none"}

        if _HAS_FINBERT:
            return self._finbert_score(texts)
        return self._lexicon_score(texts)

    def _finbert_score(self, texts: list[str]) -> dict:
        results = _finbert(texts[:50])
        mapping = {"positive": 1, "neutral": 0, "negative": -1}
        scores = [mapping.get(r["label"].lower(), 0) * r["score"] for r in results]
        avg = sum(scores) / len(scores)
        return {
            "overall_sentiment": self._bucket(avg),
            "score": round(avg, 3),
            "sample_size": len(texts),
            "method": "finbert",
        }

    def _lexicon_score(self, texts: list[str]) -> dict:
        total, count = 0.0, 0
        for text in texts:
            words = re.findall(r"[a-zA-Z']+", text.lower())
            pos = sum(1 for w in words if w in _POSITIVE_WORDS)
            neg = sum(1 for w in words if w in _NEGATIVE_WORDS)
            if pos or neg:
                total += (pos - neg) / max(pos + neg, 1)
                count += 1
        avg = total / count if count else 0.0
        return {
            "overall_sentiment": self._bucket(avg),
            "score": round(avg, 3),
            "sample_size": len(texts),
            "method": "lexicon_fallback",
        }

    @staticmethod
    def _bucket(score: float) -> str:
        if score > 0.15:
            return "positive"
        if score < -0.15:
            return "negative"
        return "neutral"
