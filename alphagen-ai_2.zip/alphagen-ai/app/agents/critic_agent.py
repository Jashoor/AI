"""Critic / Reflexion Agent — validates the DecisionSynthesisAgent's output
for hallucinations, contradictions, missing evidence, and schema compliance.
Can send the workflow back a step. Uses an LLM for the qualitative checks;
schema/contradiction checks that are mechanical run in plain Python first so
the LLM only judges what actually needs judgment."""
import logging
from app.config import settings
from app.llm.ollama_client import llm, LLMUnavailable
from app.schemas import DecisionOutput, CriticReview

logger = logging.getLogger("alphagen.critic")

_SYSTEM_PROMPT = (
    "You are a rigorous critic reviewing a financial recommendation for internal "
    "consistency. Check: (1) does every reason trace to evidence provided, "
    "(2) do reasons contradict each other, (3) is confidence justified given the "
    "evidence strength. Output ONLY JSON: {\"approved\": bool, \"issues\": [strings]}."
)


class CriticAgent:
    name = "critic_agent"

    def run(self, decision: DecisionOutput, technicals: dict, fundamentals: dict) -> CriticReview:
        mechanical_issues = self._mechanical_checks(decision)
        if mechanical_issues:
            return CriticReview(approved=False, issues=mechanical_issues)

        try:
            prompt = (
                f"DECISION: {decision.model_dump()}\n\n"
                f"SUPPORTING TECHNICALS: {technicals}\nSUPPORTING FUNDAMENTALS: {fundamentals}\n"
            )
            raw = llm.generate_json(settings.CRITIC_MODEL, prompt, system=_SYSTEM_PROMPT)
            return CriticReview(approved=bool(raw.get("approved", True)),
                                 issues=list(raw.get("issues", [])))
        except (LLMUnavailable, Exception) as e:
            logger.info(f"Critic LLM unavailable ({e}); mechanical checks only, auto-approving")
            return CriticReview(approved=True, issues=["LLM critic unavailable; only mechanical checks ran"])

    @staticmethod
    def _mechanical_checks(decision: DecisionOutput) -> list[str]:
        issues = []
        if not decision.reasons:
            issues.append("No reasons provided for recommendation")
        if not decision.evidence:
            issues.append("No evidence attached to recommendation")
        if decision.confidence > 0.85 and len(decision.reasons) < 2:
            issues.append("High confidence claimed with fewer than 2 supporting reasons")
        return issues
