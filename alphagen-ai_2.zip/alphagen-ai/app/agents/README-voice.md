# Voice Interface (not wired in this reference build)

The spec calls for a fully local voice loop: Whisper.cpp (speech-to-text) →
Planner → Agents → Piper (text-to-speech). Both are free/local and don't need
API keys, but they require native binaries/model downloads that don't belong
in a base install, so they're intentionally left as a documented extension
point rather than bundled.

To add it:
1. Run whisper.cpp as a small local HTTP server (or shell out to its CLI) and
   POST the resulting transcript to `POST /analyze` as `request.notes` or a
   new `voice_query` field.
2. Take the JSON response's `decision.reasons` / `evidence` and feed them to
   Piper's TTS CLI to synthesize a spoken summary.
3. Wire both into a small `app/agents/voice_agent.py` that just orchestrates
   those two subprocess calls — no changes needed anywhere else in the graph.
