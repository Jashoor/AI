"""Financial Manager Agent — receives the user request, maintains workflow
state, and kicks off the Planning Agent + graph execution. Per spec, it NEVER
performs analysis itself; it only coordinates and handles retries at the
top level. The actual DAG wiring lives in app/graph/workflow.py — this class
is the clean 'front door' the API layer talks to."""
import uuid
import logging
from app.schemas import AnalyzeRequest, WorkflowState
from app.graph.workflow import run_workflow

logger = logging.getLogger("alphagen.financial_manager")


class FinancialManagerAgent:
    name = "financial_manager_agent"

    def handle_request(self, request: AnalyzeRequest) -> WorkflowState:
        trace_id = str(uuid.uuid4())
        logger.info(f"[{trace_id}] Received request: {request}")
        state = WorkflowState(request=request, trace_id=trace_id)
        state = run_workflow(state)
        return state
