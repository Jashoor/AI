"""Data Validation Agent — cross-checks figures from multiple sources (e.g.
yfinance vs a secondary provider) and flags inconsistencies beyond tolerance.
Pure Python, no LLM."""


class DataValidationAgent:
    name = "data_validation_agent"

    def __init__(self, tolerance_pct: float = 5.0):
        self.tolerance_pct = tolerance_pct

    def run(self, primary: dict, secondary: dict | None = None) -> dict:
        if not secondary:
            return {
                "status": "single_source",
                "warnings": ["Only one data source available; cross-validation skipped."],
                "fields_checked": 0,
                "inconsistencies": [],
            }

        inconsistencies = []
        fields_checked = 0
        for field in ("last_price", "pe_ratio", "market_cap"):
            v1, v2 = primary.get(field), secondary.get(field)
            if v1 is None or v2 is None:
                continue
            fields_checked += 1
            diff_pct = abs(v1 - v2) / max(abs(v1), 1e-9) * 100
            if diff_pct > self.tolerance_pct:
                inconsistencies.append({
                    "field": field, "primary": v1, "secondary": v2,
                    "diff_pct": round(diff_pct, 2),
                })

        status = "consistent" if not inconsistencies else "inconsistent"
        return {
            "status": status,
            "fields_checked": fields_checked,
            "inconsistencies": inconsistencies,
            "warnings": [] if status == "consistent" else
                        [f"{len(inconsistencies)} field(s) exceeded {self.tolerance_pct}% tolerance"],
        }
