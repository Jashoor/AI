"""ML Prediction Service — traditional ML only, NEVER an LLM (per spec).
Trains a lightweight classifier on engineered technical features to estimate
P(up-move) over the next N days. This is intentionally a simple, honest
baseline (logistic regression on rolling features) — swap in XGBoost/LightGBM/
LSTM behind the same interface for a stronger model. Never claims exact
future prices, only a probability + confidence band."""
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler


class MLPredictionAgent:
    name = "ml_prediction_agent"

    def run(self, market_data: dict, horizon_days: int = 5) -> dict:
        ohlcv = market_data["ohlcv"]
        df = pd.DataFrame({"close": ohlcv["close"], "volume": ohlcv["volume"]})
        if len(df) < 60:
            return {
                "probability_up": None,
                "confidence": None,
                "note": "Insufficient history for ML prediction (need >= 60 bars)",
            }

        features = self._engineer_features(df)
        labels = (df["close"].shift(-horizon_days) > df["close"]).astype(int)

        data = features.join(labels.rename("label")).dropna()
        X, y = data.drop(columns=["label"]), data["label"]

        if y.nunique() < 2 or len(X) < 30:
            return {
                "probability_up": None,
                "confidence": None,
                "note": "Insufficient class variety for a reliable model on this history",
            }

        split = int(len(X) * 0.8)
        X_train, X_test = X.iloc[:split], X.iloc[split:]
        y_train, y_test = y.iloc[:split], y.iloc[split:]

        scaler = StandardScaler()
        X_train_s = scaler.fit_transform(X_train)
        model = LogisticRegression(max_iter=1000)
        model.fit(X_train_s, y_train)

        test_acc = None
        if len(X_test) > 0:
            test_acc = round(float(model.score(scaler.transform(X_test), y_test)), 3)

        latest_features = features.ffill().iloc[[-1]]
        prob_up = float(model.predict_proba(scaler.transform(latest_features))[0][1])

        return {
            "probability_up": round(prob_up, 3),
            "probability_down": round(1 - prob_up, 3),
            "horizon_days": horizon_days,
            "backtest_accuracy": test_acc,
            "model": "logistic_regression_baseline",
            "note": "Probability estimate, not a price forecast. Swap in XGBoost/LSTM for production.",
        }

    @staticmethod
    def _engineer_features(df: pd.DataFrame) -> pd.DataFrame:
        close, volume = df["close"], df["volume"]
        feats = pd.DataFrame(index=df.index)
        feats["return_1d"] = close.pct_change(1)
        feats["return_5d"] = close.pct_change(5)
        feats["return_10d"] = close.pct_change(10)
        feats["volatility_10d"] = close.pct_change().rolling(10).std()
        feats["sma_ratio"] = close / close.rolling(20).mean()
        feats["volume_change"] = volume.pct_change(5)
        rsi_delta = close.diff()
        gain = rsi_delta.clip(lower=0).ewm(alpha=1/14, adjust=False).mean()
        loss = (-rsi_delta.clip(upper=0)).ewm(alpha=1/14, adjust=False).mean()
        rs = gain / loss.replace(0, np.nan)
        feats["rsi"] = (100 - 100 / (1 + rs)).fillna(50)
        return feats
