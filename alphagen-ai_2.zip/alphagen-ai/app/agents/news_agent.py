"""News Intelligence Agent — collects from free RSS feeds (Google News, no
key required). A small LLM is used ONLY to summarize/filter relevance, per
spec ('Small LLM summarizes only relevant news'). If the LLM is unavailable,
falls back to simple keyword-relevance scoring so the pipeline never blocks."""
import logging
import feedparser
from urllib.parse import quote
from app.config import settings
from app.llm.ollama_client import llm, LLMUnavailable

logger = logging.getLogger("alphagen.news")


class NewsAgent:
    name = "news_agent"

    def run(self, ticker: str, company_name: str | None = None, max_items: int = 8) -> list[dict]:
        query = company_name or ticker
        url = settings.GOOGLE_NEWS_RSS.format(query=quote(f"{query} stock"))
        try:
            feed = feedparser.parse(url)
            entries = feed.entries[:max_items]
        except Exception as e:
            logger.warning(f"News RSS fetch failed: {e}")
            entries = []

        items = [{"title": e.get("title", ""), "link": e.get("link", ""),
                  "published": e.get("published", ""), "source": "Google News RSS"}
                 for e in entries]

        if not items:
            return []

        return self._summarize_relevant(ticker, items)

    def _summarize_relevant(self, ticker: str, items: list[dict]) -> list[dict]:
        headlines = "\n".join(f"- {it['title']}" for it in items)
        prompt = (
            f"Here are recent news headlines about {ticker}:\n{headlines}\n\n"
            "Return JSON: a list of objects with fields 'title', 'relevant' (true/false), "
            "'one_line_summary'. Mark relevant=false for unrelated/generic market noise."
        )
        try:
            parsed = llm.generate_json(settings.SUMMARY_MODEL, prompt,
                                        system="You are a financial news relevance filter. Output only JSON.")
            summaries = parsed if isinstance(parsed, list) else parsed.get("items", [])
            by_title = {s.get("title"): s for s in summaries if isinstance(s, dict)}
            enriched = []
            for it in items:
                s = by_title.get(it["title"], {})
                if s.get("relevant", True):
                    it["summary"] = s.get("one_line_summary", it["title"])
                    enriched.append(it)
            return enriched or items
        except (LLMUnavailable, Exception) as e:
            logger.info(f"News summarization LLM unavailable, using raw headlines: {e}")
            for it in items:
                it["summary"] = it["title"]
            return items
