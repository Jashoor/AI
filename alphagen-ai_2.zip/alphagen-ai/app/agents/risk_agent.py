"""Risk Management Agent — pure Python. Checks position sizing, sector
allocation, drawdown limits, and volatility, and can outright reject unsafe
recommendations regardless of what the Decision agent said."""
from app.config import settings
from app.schemas import DecisionOutput, RiskAssessment, Recommendation


class RiskAgent:
    name = "risk_agent"

    def run(self, decision: DecisionOutput, technicals: dict, portfolio: dict | None = None) -> RiskAssessment:
        portfolio = portfolio or {}
        violations = []

        atr = technicals.get("atr_14") or 0
        last_price = technicals.get("vwap") or 1
        volatility_pct = (atr / last_price * 100) if last_price else 0

        position_size_pct = settings.MAX_POSITION_PCT
        if volatility_pct > 8:
            position_size_pct = round(position_size_pct * 0.5, 4)
            violations.append(f"High volatility ({round(volatility_pct,2)}%) — position size halved")

        current_sector_alloc = portfolio.get("sector_allocation_pct", 0.0)
        if current_sector_alloc + position_size_pct > settings.MAX_SECTOR_ALLOCATION_PCT:
            violations.append(
                f"Sector allocation cap exceeded ({round(current_sector_alloc + position_size_pct,3)} > "
                f"{settings.MAX_SECTOR_ALLOCATION_PCT})"
            )

        daily_pnl_pct = portfolio.get("daily_pnl_pct", 0.0)
        if daily_pnl_pct <= -settings.DAILY_LOSS_LIMIT_PCT:
            violations.append(f"Daily loss limit breached ({daily_pnl_pct}%) — no new positions")

        current_drawdown_pct = portfolio.get("current_drawdown_pct", 0.0)
        if current_drawdown_pct >= settings.MAX_DRAWDOWN_PCT:
            violations.append(f"Max drawdown breached ({current_drawdown_pct}%) — trading halted")

        stop_loss_pct = round(max(volatility_pct * 1.5, 2.0), 2)

        risk_score = min(1.0, round(
            0.3 * min(volatility_pct / 10, 1) +
            0.3 * (1 if violations else 0) +
            0.2 * min(current_drawdown_pct / settings.MAX_DRAWDOWN_PCT, 1) +
            0.2 * (0 if decision.recommendation == Recommendation.HOLD else 0.5), 3))

        blocking_violations = [v for v in violations if "halted" in v or "breached" in v]
        passed = len(blocking_violations) == 0

        return RiskAssessment(
            passed=passed,
            risk_score=risk_score,
            position_size_pct=position_size_pct if passed else 0.0,
            stop_loss_pct=stop_loss_pct,
            violations=violations,
        )
