"""Portfolio Monitoring Agent — checks open positions against stop-loss/target
and flags conditions that should trigger re-analysis. Designed to be called on
a schedule (cron / APScheduler / Celery beat) rather than only inline in the
request path."""
from app.memory.long_term import long_term_memory


class PortfolioMonitoringAgent:
    name = "portfolio_monitoring_agent"

    def run(self, ticker: str, current_price: float, stop_loss_pct: float,
             target_pct: float = 10.0) -> dict:
        history = long_term_memory.get_trade_history(ticker=ticker, limit=1)
        if not history:
            return {"status": "no_open_position"}

        last_trade = history[0]
        entry_price = last_trade["price"]
        if last_trade["side"] == "SELL":
            return {"status": "short_position_monitoring_not_implemented"}

        change_pct = (current_price - entry_price) / entry_price * 100
        triggers = []
        if change_pct <= -stop_loss_pct:
            triggers.append("stop_loss_hit")
        if change_pct >= target_pct:
            triggers.append("target_hit")

        return {
            "status": "monitoring",
            "entry_price": entry_price,
            "current_price": current_price,
            "change_pct": round(change_pct, 2),
            "triggers": triggers,
            "requires_reanalysis": bool(triggers),
        }
