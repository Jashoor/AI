"""Market Data Agent — NO LLM. Pulls OHLCV + fundamentals via yfinance (free,
no API key). Includes retry -> cache -> proceed-with-warning failure recovery
as specified."""
import json
import time
import logging
from pathlib import Path
import yfinance as yf
from app.config import settings

logger = logging.getLogger("alphagen.market_data")


class MarketDataAgent:
    name = "market_data_agent"

    def __init__(self):
        self.cache_dir = settings.CACHE_DIR / "market"
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _cache_path(self, ticker: str) -> Path:
        return self.cache_dir / f"{ticker}.json"

    def run(self, ticker: str, retries: int = 2) -> dict:
        last_err = None
        for attempt in range(retries + 1):
            try:
                return self._fetch(ticker)
            except Exception as e:
                last_err = e
                logger.warning(f"MarketDataAgent attempt {attempt} failed for {ticker}: {e}")
                time.sleep(0.5 * (attempt + 1))

        cached = self._read_cache(ticker)
        if cached:
            cached["_warning"] = f"Live fetch failed ({last_err}); served from cache."
            return cached

        raise RuntimeError(f"MarketDataAgent: all sources failed for {ticker}: {last_err}")

    def _fetch(self, ticker: str) -> dict:
        tk = yf.Ticker(ticker)
        hist = tk.history(period="6mo", interval="1d")
        if hist.empty:
            raise ValueError("empty history from yfinance")

        info = {}
        try:
            info = tk.info or {}
        except Exception:
            info = {}

        result = {
            "ticker": ticker,
            "ohlcv": {
                "close": hist["Close"].round(4).tolist(),
                "open": hist["Open"].round(4).tolist(),
                "high": hist["High"].round(4).tolist(),
                "low": hist["Low"].round(4).tolist(),
                "volume": hist["Volume"].astype(int).tolist(),
                "dates": [d.strftime("%Y-%m-%d") for d in hist.index],
            },
            "last_price": float(hist["Close"].iloc[-1]),
            "sector": info.get("sector"),
            "market_cap": info.get("marketCap"),
            "pe_ratio": info.get("trailingPE"),
            "source": "yfinance",
        }
        self._write_cache(ticker, result)
        return result

    def _write_cache(self, ticker: str, data: dict):
        try:
            self._cache_path(ticker).write_text(json.dumps(data))
        except Exception as e:
            logger.warning(f"cache write failed: {e}")

    def _read_cache(self, ticker: str) -> dict | None:
        p = self._cache_path(ticker)
        if p.exists():
            try:
                return json.loads(p.read_text())
            except Exception:
                return None
        return None
