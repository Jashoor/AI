"""Order Execution Agent — defaults to a mock broker (paper trading, free,
no keys). Real brokers (Alpaca / Zerodha / IBKR) can be added by implementing
the same `BrokerInterface` and swapping `self.broker` — no other code changes
needed. # STUB: real broker adapters are not implemented here."""
import uuid
import time
from abc import ABC, abstractmethod
from app.schemas import DecisionOutput, RiskAssessment, OrderResult, Recommendation
from app.memory.long_term import long_term_memory


class BrokerInterface(ABC):
    @abstractmethod
    def place_order(self, ticker: str, side: str, quantity: float) -> dict:
        ...


class MockBroker(BrokerInterface):
    """Simulated fills at a synthetic price for paper trading / demos."""

    def place_order(self, ticker: str, side: str, quantity: float, last_price: float = 100.0) -> dict:
        return {
            "order_id": str(uuid.uuid4()),
            "status": "filled",
            "fill_price": round(last_price, 2),
            "filled_at": time.time(),
        }


# # STUB — real broker example (not implemented):
# class AlpacaBroker(BrokerInterface):
#     def __init__(self, api_key, api_secret): ...
#     def place_order(self, ticker, side, quantity):
#         # call Alpaca REST API here
#         ...


class OrderExecutionAgent:
    name = "order_execution_agent"

    def __init__(self, broker: BrokerInterface | None = None):
        self.broker = broker or MockBroker()

    def run(self, trace_id: str, decision: DecisionOutput, risk: RiskAssessment,
            last_price: float, mode: str, portfolio_value: float = 100000.0) -> OrderResult | None:
        if decision.recommendation == Recommendation.HOLD:
            return None

        quantity = round((portfolio_value * risk.position_size_pct) / max(last_price, 1e-6), 4)
        if quantity <= 0:
            return None

        fill = self.broker.place_order(decision.ticker, decision.recommendation.value, quantity,
                                        last_price=last_price)
        order = OrderResult(
            order_id=fill["order_id"],
            ticker=decision.ticker,
            side=decision.recommendation.value,
            quantity=quantity,
            price=fill["fill_price"],
            mode=mode,
            status=fill["status"],
        )
        long_term_memory.record_trade(trace_id, order.ticker, order.side, order.quantity,
                                       order.price, order.mode, order.status)
        return order
