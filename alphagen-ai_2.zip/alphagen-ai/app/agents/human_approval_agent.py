"""Human Approval Agent — auto-approves in paper-trading mode, requires an
explicit human approval call in live mode. No LLM; this is a workflow gate."""
from app.memory.short_term import short_term_memory


class HumanApprovalAgent:
    name = "human_approval_agent"

    def run(self, trace_id: str, mode: str, decision, risk) -> dict:
        if mode == "paper":
            return {"approved": True, "auto_approved": True, "reason": "Paper trading mode — auto-approved"}

        if not risk.passed:
            return {"approved": False, "auto_approved": False, "reason": "Blocked by risk agent before reaching human"}

        # Live mode: park the decision awaiting explicit approval via a
        # separate endpoint (POST /approve/{trace_id}) rather than blocking
        # the request thread indefinitely.
        short_term_memory.set(f"pending_approval:{trace_id}", {
            "decision": decision.model_dump(), "risk": risk.model_dump(),
        }, ttl=1800)
        return {"approved": False, "auto_approved": False,
                "reason": "Live trading requires explicit human approval",
                "pending": True, "approve_endpoint": f"/approve/{trace_id}"}

    def approve(self, trace_id: str) -> dict:
        pending = short_term_memory.get(f"pending_approval:{trace_id}")
        if not pending:
            return {"approved": False, "reason": "No pending approval found or it expired"}
        short_term_memory.delete(f"pending_approval:{trace_id}")
        return {"approved": True, **pending}
