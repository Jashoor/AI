"""Decision Synthesis Agent — the one place an LLM combines technicals,
fundamentals, sentiment, news, RAG evidence, and ML prediction into a single
structured BUY/SELL/HOLD call. Output is forced through the DecisionOutput
pydantic schema (output guardrail). Falls back to a transparent rule-based
synthesizer if the LLM is unavailable, so the pipeline never silently breaks."""
import logging
from app.config import settings
from app.llm.ollama_client import llm, LLMUnavailable
from app.schemas import DecisionOutput, EvidenceItem, Recommendation

logger = logging.getLogger("alphagen.decision")

_SYSTEM_PROMPT = (
    "You are a disciplined equity research analyst. You synthesize technical, "
    "fundamental, sentiment, news, and ML-prediction inputs into ONE recommendation. "
    "You never invent facts not present in the input. You always cite which input "
    "each reason came from. Output ONLY valid JSON matching the requested schema."
)


class DecisionSynthesisAgent:
    name = "decision_synthesis_agent"

    def run(self, ticker: str, technicals: dict, fundamentals: dict, sentiment: dict,
            news: list[dict], rag_evidence: list[dict], ml_prediction: dict) -> DecisionOutput:
        prompt = self._build_prompt(ticker, technicals, fundamentals, sentiment,
                                     news, rag_evidence, ml_prediction)
        try:
            raw = llm.generate_json(settings.SYNTHESIS_MODEL, prompt, system=_SYSTEM_PROMPT)
            return self._to_schema(ticker, raw)
        except (LLMUnavailable, Exception) as e:
            logger.info(f"Decision LLM unavailable ({e}); using rule-based fallback")
            return self._rule_based_fallback(ticker, technicals, fundamentals, sentiment, ml_prediction)

    def _build_prompt(self, ticker, technicals, fundamentals, sentiment, news, rag_evidence, ml_prediction) -> str:
        news_lines = "\n".join(f"- {n.get('summary', n.get('title'))}" for n in news[:5]) or "None"
        rag_lines = "\n".join(f"- {r['text'][:200]}" for r in rag_evidence[:3]) or "None"
        return f"""
Ticker: {ticker}

TECHNICALS: {technicals}

FUNDAMENTALS: {fundamentals}

SENTIMENT: {sentiment}

ML PREDICTION (probability of upward move, NOT a price forecast): {ml_prediction}

RECENT NEWS:
{news_lines}

DOCUMENT EVIDENCE (from annual reports / filings, if any):
{rag_lines}

Return ONLY JSON with this exact shape:
{{
  "recommendation": "BUY" | "SELL" | "HOLD",
  "confidence": <float 0-1>,
  "reasons": [<short strings>],
  "evidence": [{{"source": <string>, "detail": <string>}}],
  "sources": [<string>]
}}
Be conservative: if signals conflict, prefer HOLD with lower confidence.
"""

    def _to_schema(self, ticker: str, raw: dict) -> DecisionOutput:
        return DecisionOutput(
            ticker=ticker,
            recommendation=Recommendation(raw["recommendation"].upper()),
            confidence=float(raw.get("confidence", 0.5)),
            reasons=list(raw.get("reasons", [])),
            evidence=[EvidenceItem(**e) if isinstance(e, dict) else EvidenceItem(source="model", detail=str(e))
                       for e in raw.get("evidence", [])],
            sources=list(raw.get("sources", [])),
        )

    def _rule_based_fallback(self, ticker, technicals, fundamentals, sentiment, ml_prediction) -> DecisionOutput:
        score = 0
        reasons = []
        rsi = technicals.get("rsi_14")
        if rsi is not None:
            if rsi < 30:
                score += 1; reasons.append(f"RSI oversold at {rsi}")
            elif rsi > 70:
                score -= 1; reasons.append(f"RSI overbought at {rsi}")

        macd_hist = technicals.get("macd", {}).get("histogram")
        if macd_hist is not None:
            score += 1 if macd_hist > 0 else -1
            reasons.append(f"MACD histogram {'positive' if macd_hist > 0 else 'negative'}")

        eps_growth = fundamentals.get("eps_growth_pct")
        if eps_growth is not None:
            score += 1 if eps_growth > 0 else -1
            reasons.append(f"EPS growth {eps_growth}%")

        sent_score = sentiment.get("score", 0)
        score += 1 if sent_score > 0.15 else (-1 if sent_score < -0.15 else 0)
        if sentiment.get("sample_size", 0) > 0:
            reasons.append(f"Sentiment {sentiment.get('overall_sentiment')}")

        prob_up = ml_prediction.get("probability_up")
        if prob_up is not None:
            score += 1 if prob_up > 0.55 else (-1 if prob_up < 0.45 else 0)
            reasons.append(f"ML model P(up)={prob_up}")

        if score >= 2:
            rec, conf = Recommendation.BUY, min(0.5 + score * 0.08, 0.9)
        elif score <= -2:
            rec, conf = Recommendation.SELL, min(0.5 + abs(score) * 0.08, 0.9)
        else:
            rec, conf = Recommendation.HOLD, 0.5

        return DecisionOutput(
            ticker=ticker, recommendation=rec, confidence=round(conf, 2),
            reasons=reasons or ["Insufficient signal strength"],
            evidence=[EvidenceItem(source="rule_engine", detail="LLM unavailable; deterministic scoring used")],
            sources=["technical_analysis_agent", "fundamental_analysis_agent",
                     "sentiment_agent", "ml_prediction_agent"],
        )
