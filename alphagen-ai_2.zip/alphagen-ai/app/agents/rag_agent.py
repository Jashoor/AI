"""Document RAG Agent — builds/queries the financial knowledge base (annual
reports, filings, transcripts, research PDFs). Uses the shared vector_store
(FAISS+sentence-transformers if installed, else TF-IDF fallback). No LLM is
used for retrieval itself — only for the downstream synthesis step, which
consumes this agent's output as evidence."""
import logging
from app.memory.vector_store import vector_store, chunk_text

logger = logging.getLogger("alphagen.rag")


class RAGAgent:
    name = "rag_agent"

    def ingest_document(self, text: str, metadata: dict):
        """Call this to add an annual report / transcript / filing to the KB.
        metadata should include e.g. {'ticker': 'AAPL', 'doc_type': 'annual_report',
        'year': 2025, 'source': 'company filing'}"""
        chunks = chunk_text(text)
        for chunk in chunks:
            vector_store.add(chunk, metadata)
        return {"chunks_indexed": len(chunks)}

    def run(self, ticker: str, query: str | None = None, k: int = 5) -> list[dict]:
        search_query = query or f"{ticker} financial performance outlook risk revenue growth"
        try:
            results = vector_store.search(search_query, k=k)
        except Exception as e:
            logger.warning(f"RAG search failed: {e}")
            return []
        # keep only reasonably relevant matches
        return [r for r in results if r.get("score", 0) > 0.05]
