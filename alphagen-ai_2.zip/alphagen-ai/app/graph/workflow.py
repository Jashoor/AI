"""The execution graph. This is a deliberately simple, explicit DAG executor
(rather than pulling in the full LangGraph dependency) so the control flow is
100% readable — parallel data-gathering fan-out, then a sequential analysis
chain, with retry + critic-bounce-back + human-approval gates, exactly as
drawn in the spec's architecture diagram."""
import logging
import time
import concurrent.futures as cf
from app.schemas import WorkflowState, DecisionOutput
from app.monitoring.metrics import track_agent, AGENT_RETRIES, WORKFLOW_DURATION
from app.guardrails.prompt_injection import check_prompt_injection

from app.agents.planning_agent import PlanningAgent
from app.agents.market_data_agent import MarketDataAgent
from app.agents.news_agent import NewsAgent
from app.agents.rag_agent import RAGAgent
from app.agents.sentiment_agent import SentimentAgent
from app.agents.data_validation_agent import DataValidationAgent
from app.agents.technical_analysis_agent import TechnicalAnalysisAgent
from app.agents.fundamental_analysis_agent import FundamentalAnalysisAgent
from app.agents.ml_prediction_agent import MLPredictionAgent
from app.agents.decision_synthesis_agent import DecisionSynthesisAgent
from app.agents.risk_agent import RiskAgent
from app.agents.critic_agent import CriticAgent
from app.agents.human_approval_agent import HumanApprovalAgent
from app.agents.order_execution_agent import OrderExecutionAgent
from app.agents.portfolio_monitoring_agent import PortfolioMonitoringAgent
from app.agents.memory_agent import memory_agent

logger = logging.getLogger("alphagen.graph")

planning_agent = PlanningAgent()
market_data_agent = MarketDataAgent()
news_agent = NewsAgent()
rag_agent = RAGAgent()
sentiment_agent = SentimentAgent()
data_validation_agent = DataValidationAgent()
technical_agent = TechnicalAnalysisAgent()
fundamental_agent = FundamentalAnalysisAgent()
ml_agent = MLPredictionAgent()
decision_agent = DecisionSynthesisAgent()
risk_agent = RiskAgent()
critic_agent = CriticAgent()
approval_agent = HumanApprovalAgent()
order_agent = OrderExecutionAgent()
monitoring_agent = PortfolioMonitoringAgent()

MAX_CRITIC_RETRIES = 2


def _trace(state: WorkflowState, agent: str, note: str):
    state.agent_trace.append({"agent": agent, "note": note, "ts": time.time()})


def run_workflow(state: WorkflowState) -> WorkflowState:
    with WORKFLOW_DURATION.time():
        req = state.request

        # --- Guardrail: prompt injection on free-text notes ---
        injection = check_prompt_injection(req.notes or "")
        if not injection.safe:
            state.warnings.append(f"Blocked potential prompt injection: {injection.matched_pattern}")
            _trace(state, "guardrails", "Request notes blocked by prompt-injection filter")
            req.notes = None  # strip untrusted free text, continue with ticker-only analysis

        # --- Planning ---
        with track_agent(planning_agent.name):
            plan = planning_agent.run(req.ticker, req.notes)
        _trace(state, planning_agent.name, f"plan={plan}")

        # --- Parallel fan-out: market data, news, RAG, sentiment ---
        with cf.ThreadPoolExecutor(max_workers=4) as pool:
            futures = {
                "market_data": pool.submit(_safe_call, market_data_agent.name, state,
                                            lambda: market_data_agent.run(req.ticker)),
                "news": pool.submit(_safe_call, news_agent.name, state,
                                     lambda: news_agent.run(req.ticker, max_items=plan.get("news_items", 6))
                                     if plan.get("run_sentiment", True) or True else []),
                "rag": pool.submit(_safe_call, rag_agent.name, state,
                                    lambda: rag_agent.run(req.ticker) if plan.get("run_rag", True) else []),
            }
            results = {k: f.result() for k, f in futures.items()}

        state.market_data = results["market_data"] or {}
        state.news = results["news"] or []
        state.rag_evidence = results["rag"] or []

        if not state.market_data:
            state.warnings.append("Market data unavailable — aborting workflow (critical dependency).")
            _trace(state, "financial_manager_agent", "Aborted: no market data")
            return state

        # Sentiment runs on headline text (cheap, no external forum scraping wired in this ref impl)
        if plan.get("run_sentiment", True):
            texts = [n.get("title", "") for n in state.news]
            with track_agent(sentiment_agent.name):
                state.sentiment = sentiment_agent.run(texts)
            _trace(state, sentiment_agent.name, f"sentiment={state.sentiment.get('overall_sentiment')}")

        # --- Data validation ---
        with track_agent(data_validation_agent.name):
            state.validation = data_validation_agent.run(state.market_data)
        _trace(state, data_validation_agent.name, f"status={state.validation.get('status')}")

        # --- Technical analysis (pure python) ---
        try:
            with track_agent(technical_agent.name):
                state.technicals = technical_agent.run(state.market_data)
            _trace(state, technical_agent.name, state.technicals.get("signal_summary", ""))
        except Exception as e:
            state.warnings.append(f"Technical analysis failed: {e}")
            state.technicals = {}

        # --- Fundamental analysis (pure python) ---
        with track_agent(fundamental_agent.name):
            state.fundamentals = fundamental_agent.run(state.market_data)
        _trace(state, fundamental_agent.name, state.fundamentals.get("valuation_note", ""))

        # --- ML prediction (non-LLM ML) ---
        with track_agent(ml_agent.name):
            state.ml_prediction = ml_agent.run(state.market_data)
        _trace(state, ml_agent.name, str(state.ml_prediction.get("probability_up")))

        # --- Decision synthesis (LLM) with critic bounce-back loop ---
        attempt = 0
        while attempt <= MAX_CRITIC_RETRIES:
            with track_agent(decision_agent.name):
                state.decision = decision_agent.run(
                    req.ticker, state.technicals, state.fundamentals, state.sentiment,
                    state.news, state.rag_evidence, state.ml_prediction,
                )
            _trace(state, decision_agent.name, f"{state.decision.recommendation} conf={state.decision.confidence}")

            with track_agent(critic_agent.name):
                state.critic = critic_agent.run(state.decision, state.technicals, state.fundamentals)
            _trace(state, critic_agent.name, f"approved={state.critic.approved} issues={state.critic.issues}")

            if state.critic.approved:
                break
            attempt += 1
            state.retries[decision_agent.name] = attempt
            AGENT_RETRIES.labels(agent=decision_agent.name).inc()
            state.warnings.append(f"Critic rejected decision (attempt {attempt}): {state.critic.issues}")

        if not state.critic.approved:
            state.warnings.append("Critic did not approve after max retries — defaulting to HOLD for safety")
            state.decision = DecisionOutput(
                ticker=req.ticker, recommendation="HOLD", confidence=0.3,
                reasons=["Critic could not validate the synthesized decision after retries"],
                evidence=[], sources=[],
            )

        # --- Risk management ---
        with track_agent(risk_agent.name):
            state.risk = risk_agent.run(state.decision, state.technicals)
        _trace(state, risk_agent.name, f"passed={state.risk.passed} score={state.risk.risk_score}")

        if not state.risk.passed:
            state.warnings.append(f"Risk agent rejected trade: {state.risk.violations}")
            state.approved = False
            _trace(state, "financial_manager_agent", "Workflow halted by risk agent")
            _persist(state)
            return state

        # --- Human approval ---
        with track_agent(approval_agent.name):
            approval = approval_agent.run(state.trace_id, req.mode, state.decision, state.risk)
        state.approved = approval["approved"]
        _trace(state, approval_agent.name, approval["reason"])

        # --- Order execution (only if approved) ---
        if state.approved:
            with track_agent(order_agent.name):
                state.order = order_agent.run(
                    state.trace_id, state.decision, state.risk,
                    last_price=state.market_data.get("last_price", 0.0), mode=req.mode,
                )
            _trace(state, order_agent.name, f"order={state.order}")

            with track_agent(monitoring_agent.name):
                monitoring_agent.run(req.ticker, state.market_data.get("last_price", 0.0),
                                      state.risk.stop_loss_pct)

        # --- Memory ---
        memory_agent.add_reflexion(
            state.trace_id, req.ticker,
            f"{state.decision.recommendation} @ conf {state.decision.confidence}; warnings={state.warnings}",
        )
        _persist(state)
        return state


def _persist(state: WorkflowState):
    from app.agents.memory_agent import memory_agent
    memory_agent.persist_workflow_result(state.trace_id, state.model_dump(mode="json"))


def _safe_call(agent_name: str, state: WorkflowState, fn):
    try:
        with track_agent(agent_name):
            return fn()
    except Exception as e:
        logger.warning(f"{agent_name} failed: {e}")
        state.warnings.append(f"{agent_name} failed: {e}")
        return None
