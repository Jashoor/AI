"""Input guardrail: detect prompt-injection / instruction-override attempts in
free-text fields before they ever reach an LLM prompt."""
import re
from dataclasses import dataclass

INJECTION_PATTERNS = [
    r"ignore (all|any|the)? ?(previous|prior|above) instructions",
    r"disregard (all|any|the)? ?(previous|prior|above) (instructions|rules)",
    r"you are now",
    r"system prompt",
    r"act as (an?|the) ?(unrestricted|jailbroken|dan)",
    r"sell all (stocks|positions|holdings)",
    r"transfer (all|the) funds",
    r"reveal your (instructions|prompt|system message)",
    r"bypass (guardrails|safety|risk checks)",
]
_COMPILED = [re.compile(p, re.IGNORECASE) for p in INJECTION_PATTERNS]


@dataclass
class GuardrailResult:
    safe: bool
    matched_pattern: str | None = None


def check_prompt_injection(text: str) -> GuardrailResult:
    if not text:
        return GuardrailResult(safe=True)
    for pattern in _COMPILED:
        if pattern.search(text):
            return GuardrailResult(safe=False, matched_pattern=pattern.pattern)
    return GuardrailResult(safe=True)
