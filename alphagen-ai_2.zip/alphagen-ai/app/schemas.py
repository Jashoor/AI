"""Structured schemas shared across agents. Pydantic validation IS the output
guardrail — any agent producing a recommendation must conform to these shapes
or the CriticAgent will bounce it back."""
from __future__ import annotations
from enum import Enum
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field, field_validator


class AnalyzeRequest(BaseModel):
    ticker: str = Field(..., min_length=1, max_length=12)
    mode: str = Field(default="paper", pattern="^(paper|live)$")
    notes: Optional[str] = Field(default=None, max_length=2000)

    @field_validator("ticker")
    @classmethod
    def upper(cls, v: str) -> str:
        return v.strip().upper()


class Recommendation(str, Enum):
    BUY = "BUY"
    SELL = "SELL"
    HOLD = "HOLD"


class EvidenceItem(BaseModel):
    source: str
    detail: str


class DecisionOutput(BaseModel):
    ticker: str
    recommendation: Recommendation
    confidence: float = Field(ge=0.0, le=1.0)
    reasons: List[str]
    evidence: List[EvidenceItem]
    sources: List[str]


class RiskAssessment(BaseModel):
    passed: bool
    risk_score: float = Field(ge=0.0, le=1.0)
    position_size_pct: float
    stop_loss_pct: float
    violations: List[str] = Field(default_factory=list)


class CriticReview(BaseModel):
    approved: bool
    issues: List[str] = Field(default_factory=list)
    corrected_decision: Optional[DecisionOutput] = None


class OrderResult(BaseModel):
    order_id: str
    ticker: str
    side: str
    quantity: float
    price: float
    mode: str
    status: str


class WorkflowState(BaseModel):
    """The single object threaded through the whole graph. Every agent reads
    from and writes back into this — this IS the 'directed message passing'
    described in the spec, made concrete."""
    request: AnalyzeRequest
    trace_id: str
    market_data: Dict[str, Any] = Field(default_factory=dict)
    news: List[Dict[str, Any]] = Field(default_factory=list)
    rag_evidence: List[Dict[str, Any]] = Field(default_factory=list)
    sentiment: Dict[str, Any] = Field(default_factory=dict)
    validation: Dict[str, Any] = Field(default_factory=dict)
    technicals: Dict[str, Any] = Field(default_factory=dict)
    fundamentals: Dict[str, Any] = Field(default_factory=dict)
    ml_prediction: Dict[str, Any] = Field(default_factory=dict)
    decision: Optional[DecisionOutput] = None
    risk: Optional[RiskAssessment] = None
    critic: Optional[CriticReview] = None
    approved: bool = False
    order: Optional[OrderResult] = None
    warnings: List[str] = Field(default_factory=list)
    agent_trace: List[Dict[str, Any]] = Field(default_factory=list)
    retries: Dict[str, int] = Field(default_factory=dict)
