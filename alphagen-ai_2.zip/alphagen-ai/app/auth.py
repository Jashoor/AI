"""JWT authentication + a minimal role-based access control. Demo user is
seeded from .env; in production wire this to a real user store.

Note: uses the `bcrypt` library directly rather than passlib's CryptContext —
passlib's version-detection shim breaks against bcrypt>=4.1 (it looks for a
`__about__` attribute that newer bcrypt releases removed)."""
import bcrypt
from datetime import datetime, timedelta
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError
from app.config import settings

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/token")


def _hash_password(password: str) -> str:
    # bcrypt has a hard 72-byte input limit; truncate defensively.
    return bcrypt.hashpw(password.encode("utf-8")[:72], bcrypt.gensalt()).decode("utf-8")


def _verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode("utf-8")[:72], hashed.encode("utf-8"))


# Seeded demo users. role: "trader" can trigger live trades; "analyst" is read-only.
_USERS_DB = {
    settings.DEMO_USERNAME: {
        "username": settings.DEMO_USERNAME,
        "hashed_password": _hash_password(settings.DEMO_PASSWORD),
        "role": "trader",
    }
}


def authenticate_user(username: str, password: str):
    user = _USERS_DB.get(username)
    if not user or not _verify_password(password, user["hashed_password"]):
        return None
    return user


def create_access_token(data: dict) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)


def get_current_user(token: str = Depends(oauth2_scheme)) -> dict:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.JWT_SECRET, algorithms=[settings.JWT_ALGORITHM])
        username = payload.get("sub")
        if username is None or username not in _USERS_DB:
            raise credentials_exception
        return _USERS_DB[username]
    except JWTError:
        raise credentials_exception


def require_role(*roles: str):
    def _checker(user: dict = Depends(get_current_user)) -> dict:
        if user["role"] not in roles:
            raise HTTPException(status_code=403, detail="Insufficient role for this action")
        return user
    return _checker
