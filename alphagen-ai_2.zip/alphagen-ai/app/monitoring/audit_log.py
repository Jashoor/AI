"""Audit logging — every authenticated request gets an immutable-ish log line
(append-only file). Swap to a real audit sink (e.g. write-once storage) for
production."""
import json
import time
import logging
from pathlib import Path
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

_AUDIT_LOG_PATH = Path("./data/audit.log")
_AUDIT_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
logger = logging.getLogger("alphagen.audit")


class AuditLogMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        start = time.time()
        response = await call_next(request)
        entry = {
            "ts": time.time(),
            "method": request.method,
            "path": request.url.path,
            "client": request.client.host if request.client else None,
            "status_code": response.status_code,
            "duration_ms": round((time.time() - start) * 1000, 2),
        }
        try:
            with open(_AUDIT_LOG_PATH, "a") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception as e:
            logger.warning(f"Audit log write failed: {e}")
        return response
