"""Prometheus metrics — scrape /metrics with a local Prometheus server, then
point Grafana at it. This gives you real latency/success/retry/token counters
for free without any paid observability vendor."""
import time
from contextlib import contextmanager
from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST

AGENT_CALLS = Counter("alphagen_agent_calls_total", "Agent invocations", ["agent", "status"])
AGENT_LATENCY = Histogram("alphagen_agent_latency_seconds", "Agent latency", ["agent"])
AGENT_RETRIES = Counter("alphagen_agent_retries_total", "Agent retries", ["agent"])
WORKFLOW_DURATION = Histogram("alphagen_workflow_duration_seconds", "End-to-end workflow duration")
LLM_TOKENS = Counter("alphagen_llm_tokens_total", "Approx LLM tokens used", ["model"])
TOOL_CALLS = Counter("alphagen_tool_calls_total", "Tool calls", ["tool", "status"])
ACTIVE_WORKFLOWS = Gauge("alphagen_active_workflows", "Currently running workflows")


@contextmanager
def track_agent(agent_name: str):
    ACTIVE_WORKFLOWS.inc()
    start = time.time()
    try:
        yield
        AGENT_CALLS.labels(agent=agent_name, status="success").inc()
    except Exception:
        AGENT_CALLS.labels(agent=agent_name, status="failure").inc()
        raise
    finally:
        AGENT_LATENCY.labels(agent=agent_name).observe(time.time() - start)
        ACTIVE_WORKFLOWS.dec()


def metrics_response():
    return generate_latest(), CONTENT_TYPE_LATEST
