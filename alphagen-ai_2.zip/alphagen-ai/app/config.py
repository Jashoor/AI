"""Central configuration. All values overridable via environment / .env."""
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()


class Settings:
    # Auth
    JWT_SECRET: str = os.getenv("JWT_SECRET", "dev-secret-change-me")
    JWT_ALGORITHM: str = os.getenv("JWT_ALGORITHM", "HS256")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "60"))
    DEMO_USERNAME: str = os.getenv("DEMO_USERNAME", "demo")
    DEMO_PASSWORD: str = os.getenv("DEMO_PASSWORD", "demo")

    # LLM
    OLLAMA_BASE_URL: str = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    PLANNING_MODEL: str = os.getenv("PLANNING_MODEL", "llama3.1:8b")
    SYNTHESIS_MODEL: str = os.getenv("SYNTHESIS_MODEL", "llama3.1:8b")
    CRITIC_MODEL: str = os.getenv("CRITIC_MODEL", "qwen2.5:3b")
    SUMMARY_MODEL: str = os.getenv("SUMMARY_MODEL", "qwen2.5:3b")

    # Storage
    CACHE_DIR: Path = Path(os.getenv("CACHE_DIR", "./data/cache"))
    VECTOR_STORE_DIR: Path = Path(os.getenv("VECTOR_STORE_DIR", "./data/vector_store"))
    SQLITE_PATH: str = os.getenv("SQLITE_PATH", "./data/alphagen.db")

    # News
    GOOGLE_NEWS_RSS: str = os.getenv(
        "GOOGLE_NEWS_RSS", "https://news.google.com/rss/search?q={query}"
    )

    # Trading
    TRADING_MODE: str = os.getenv("TRADING_MODE", "paper")  # paper | live

    # Risk
    MAX_POSITION_PCT: float = float(os.getenv("MAX_POSITION_PCT", "0.10"))
    MAX_SECTOR_ALLOCATION_PCT: float = float(os.getenv("MAX_SECTOR_ALLOCATION_PCT", "0.30"))
    DAILY_LOSS_LIMIT_PCT: float = float(os.getenv("DAILY_LOSS_LIMIT_PCT", "0.03"))
    MAX_DRAWDOWN_PCT: float = float(os.getenv("MAX_DRAWDOWN_PCT", "0.15"))


settings = Settings()
settings.CACHE_DIR.mkdir(parents=True, exist_ok=True)
settings.VECTOR_STORE_DIR.mkdir(parents=True, exist_ok=True)
Path(settings.SQLITE_PATH).parent.mkdir(parents=True, exist_ok=True)
