"""Short-term memory: current workflow scratch space. Spec suggests Redis;
we default to an in-process dict-of-dicts so the project runs with zero extra
infra, and swap to Redis transparently if REDIS_URL is set."""
import os
import json
import time
from typing import Any, Optional

_REDIS_URL = os.getenv("REDIS_URL")
_redis_client = None
if _REDIS_URL:
    try:
        import redis
        _redis_client = redis.from_url(_REDIS_URL, decode_responses=True)
    except Exception:
        _redis_client = None

_local_store: dict[str, tuple[float, str]] = {}
_TTL_SECONDS = 3600


class ShortTermMemory:
    def set(self, key: str, value: Any, ttl: int = _TTL_SECONDS) -> None:
        payload = json.dumps(value, default=str)
        if _redis_client:
            _redis_client.set(key, payload, ex=ttl)
        else:
            _local_store[key] = (time.time() + ttl, payload)

    def get(self, key: str) -> Optional[Any]:
        if _redis_client:
            raw = _redis_client.get(key)
            return json.loads(raw) if raw else None
        entry = _local_store.get(key)
        if not entry:
            return None
        expires_at, payload = entry
        if time.time() > expires_at:
            del _local_store[key]
            return None
        return json.loads(payload)

    def delete(self, key: str) -> None:
        if _redis_client:
            _redis_client.delete(key)
        _local_store.pop(key, None)


short_term_memory = ShortTermMemory()
