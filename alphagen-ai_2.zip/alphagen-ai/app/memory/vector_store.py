"""Vector memory for the Document RAG Agent. Uses FAISS + sentence-transformers
when available (see requirements.txt — commented out by default to keep the
base install light). Falls back to a pure-Python TF-IDF + cosine index so the
whole pipeline still runs with zero extra downloads for a demo.
"""
import json
import math
import pickle
import re
from collections import Counter
from pathlib import Path
from typing import List, Dict, Any
from app.config import settings

_INDEX_FILE = settings.VECTOR_STORE_DIR / "index.pkl"

try:
    import faiss  # type: ignore
    import numpy as np
    from sentence_transformers import SentenceTransformer  # type: ignore
    _HAS_FAISS = True
except Exception:
    _HAS_FAISS = False


def _tokenize(text: str) -> List[str]:
    return re.findall(r"[a-zA-Z]{2,}", text.lower())


class _TfidfFallbackStore:
    """Zero-dependency vector-ish store: TF-IDF vectors + cosine similarity.
    Not as good as real embeddings, but keeps RAG functional out of the box."""

    def __init__(self):
        self.documents: List[Dict[str, Any]] = []
        self.doc_freq: Counter = Counter()
        self._load()

    def _load(self):
        if _INDEX_FILE.exists():
            with open(_INDEX_FILE, "rb") as f:
                state = pickle.load(f)
                self.documents = state["documents"]
                self.doc_freq = state["doc_freq"]

    def _save(self):
        with open(_INDEX_FILE, "wb") as f:
            pickle.dump({"documents": self.documents, "doc_freq": self.doc_freq}, f)

    def add(self, text: str, metadata: Dict[str, Any]):
        tokens = _tokenize(text)
        tf = Counter(tokens)
        for term in set(tokens):
            self.doc_freq[term] += 1
        self.documents.append({"text": text, "tf": tf, "metadata": metadata})
        self._save()

    def _vectorize(self, tf: Counter) -> Dict[str, float]:
        n_docs = max(len(self.documents), 1)
        vec = {}
        for term, freq in tf.items():
            idf = math.log((n_docs + 1) / (self.doc_freq.get(term, 0) + 1)) + 1
            vec[term] = freq * idf
        return vec

    @staticmethod
    def _cosine(v1: Dict[str, float], v2: Dict[str, float]) -> float:
        common = set(v1) & set(v2)
        dot = sum(v1[t] * v2[t] for t in common)
        n1 = math.sqrt(sum(v * v for v in v1.values())) or 1e-9
        n2 = math.sqrt(sum(v * v for v in v2.values())) or 1e-9
        return dot / (n1 * n2)

    def search(self, query: str, k: int = 5) -> List[Dict[str, Any]]:
        if not self.documents:
            return []
        q_vec = self._vectorize(Counter(_tokenize(query)))
        scored = []
        for doc in self.documents:
            d_vec = self._vectorize(doc["tf"])
            score = self._cosine(q_vec, d_vec)
            scored.append((score, doc))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [
            {"text": d["text"][:800], "metadata": d["metadata"], "score": round(s, 4)}
            for s, d in scored[:k] if s > 0
        ]


class _FaissStore:
    def __init__(self):
        self.model = SentenceTransformer("all-MiniLM-L6-v2")
        self.dim = self.model.get_sentence_embedding_dimension()
        self.meta_path = settings.VECTOR_STORE_DIR / "meta.json"
        self.index_path = settings.VECTOR_STORE_DIR / "faiss.index"
        self.metadata: List[Dict[str, Any]] = []
        if self.index_path.exists() and self.meta_path.exists():
            self.index = faiss.read_index(str(self.index_path))
            self.metadata = json.loads(self.meta_path.read_text())
        else:
            self.index = faiss.IndexFlatIP(self.dim)

    def _save(self):
        faiss.write_index(self.index, str(self.index_path))
        self.meta_path.write_text(json.dumps(self.metadata))

    def add(self, text: str, metadata: Dict[str, Any]):
        emb = self.model.encode([text], normalize_embeddings=True)
        self.index.add(np.array(emb, dtype="float32"))
        self.metadata.append({"text": text, "metadata": metadata})
        self._save()

    def search(self, query: str, k: int = 5) -> List[Dict[str, Any]]:
        if self.index.ntotal == 0:
            return []
        emb = self.model.encode([query], normalize_embeddings=True)
        scores, idxs = self.index.search(np.array(emb, dtype="float32"), k)
        out = []
        for score, idx in zip(scores[0], idxs[0]):
            if idx == -1:
                continue
            m = self.metadata[idx]
            out.append({"text": m["text"][:800], "metadata": m["metadata"], "score": float(score)})
        return out


def get_vector_store():
    if _HAS_FAISS:
        return _FaissStore()
    return _TfidfFallbackStore()


vector_store = get_vector_store()


def chunk_text(text: str, chunk_size: int = 500, overlap: int = 50) -> List[str]:
    words = text.split()
    chunks = []
    step = max(chunk_size - overlap, 1)
    for i in range(0, len(words), step):
        chunk = " ".join(words[i:i + chunk_size])
        if chunk:
            chunks.append(chunk)
    return chunks
