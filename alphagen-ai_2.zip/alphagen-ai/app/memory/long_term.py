"""Long-term memory: trade history, user preferences, reflexion notes.
SQLite by default (zero-config, free); point SQLITE_PATH at a Postgres-backed
path via SQLAlchemy later without changing the call sites if you outgrow it."""
import sqlite3
import json
import time
from contextlib import contextmanager
from app.config import settings

_SCHEMA = """
CREATE TABLE IF NOT EXISTS trade_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trace_id TEXT,
    ticker TEXT,
    side TEXT,
    quantity REAL,
    price REAL,
    mode TEXT,
    status TEXT,
    created_at REAL
);

CREATE TABLE IF NOT EXISTS user_preferences (
    user_id TEXT PRIMARY KEY,
    preferences_json TEXT,
    updated_at REAL
);

CREATE TABLE IF NOT EXISTS reflexion_notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trace_id TEXT,
    ticker TEXT,
    note TEXT,
    created_at REAL
);
"""


@contextmanager
def _conn():
    conn = sqlite3.connect(settings.SQLITE_PATH)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with _conn() as conn:
        conn.executescript(_SCHEMA)


class LongTermMemory:
    def __init__(self):
        init_db()

    def record_trade(self, trace_id: str, ticker: str, side: str, quantity: float,
                      price: float, mode: str, status: str):
        with _conn() as conn:
            conn.execute(
                "INSERT INTO trade_history (trace_id, ticker, side, quantity, price, "
                "mode, status, created_at) VALUES (?,?,?,?,?,?,?,?)",
                (trace_id, ticker, side, quantity, price, mode, status, time.time()),
            )

    def get_trade_history(self, ticker: str | None = None, limit: int = 50):
        with _conn() as conn:
            if ticker:
                cur = conn.execute(
                    "SELECT * FROM trade_history WHERE ticker=? ORDER BY id DESC LIMIT ?",
                    (ticker, limit),
                )
            else:
                cur = conn.execute("SELECT * FROM trade_history ORDER BY id DESC LIMIT ?", (limit,))
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, row)) for row in cur.fetchall()]

    def save_preferences(self, user_id: str, preferences: dict):
        with _conn() as conn:
            conn.execute(
                "INSERT INTO user_preferences (user_id, preferences_json, updated_at) "
                "VALUES (?,?,?) ON CONFLICT(user_id) DO UPDATE SET "
                "preferences_json=excluded.preferences_json, updated_at=excluded.updated_at",
                (user_id, json.dumps(preferences), time.time()),
            )

    def get_preferences(self, user_id: str) -> dict:
        with _conn() as conn:
            cur = conn.execute("SELECT preferences_json FROM user_preferences WHERE user_id=?", (user_id,))
            row = cur.fetchone()
            return json.loads(row[0]) if row else {}

    def add_reflexion_note(self, trace_id: str, ticker: str, note: str):
        with _conn() as conn:
            conn.execute(
                "INSERT INTO reflexion_notes (trace_id, ticker, note, created_at) VALUES (?,?,?,?)",
                (trace_id, ticker, note, time.time()),
            )

    def get_reflexion_notes(self, ticker: str, limit: int = 10):
        with _conn() as conn:
            cur = conn.execute(
                "SELECT note, created_at FROM reflexion_notes WHERE ticker=? ORDER BY id DESC LIMIT ?",
                (ticker, limit),
            )
            return [{"note": r[0], "created_at": r[1]} for r in cur.fetchall()]


long_term_memory = LongTermMemory()
