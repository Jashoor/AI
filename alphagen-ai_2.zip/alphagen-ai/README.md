# AlphaGen AI — Autonomous Multi-Agent Financial Intelligence Platform

A working reference implementation of a multi-agent financial analysis pipeline built
entirely on free / open-source tooling: FastAPI, a custom LangGraph-style DAG executor,
FAISS + sentence-transformers for RAG, Ollama for local LLM inference, SQLite for
long-term memory, and pure-Python/pandas for every deterministic calculation
(RSI, MACD, EMA, fundamentals, risk metrics — **never** delegated to an LLM).

## Honest scope note

The original spec describes an enterprise system (voice interface, live broker
execution, Grafana/Prometheus stacks, Kubernetes-grade deployment, 17 agents with
full redundancy). That's a multi-month, multi-repo engineering effort — not something
that can be responsibly "fully" generated in one shot. What's in this repo:

**Fully implemented and runnable:**
- FastAPI gateway with JWT auth, rate limiting, prompt-injection & schema guardrails
- Custom DAG-based agent orchestrator (Planner → parallel data agents → sequential
  analysis chain → decision → risk → critic → approval → execution → monitoring → memory)
- 15 agents as real Python classes with real logic:
  - Financial Manager, Planning (LLM), Market Data, News Intelligence, Document RAG,
    Sentiment, Data Validation, Technical Analysis (pure Python — RSI/MACD/EMA/SMA/
    ATR/Bollinger/SuperTrend/S&R), Fundamental Analysis (pure Python), ML Prediction
    (RandomForest/XGBoost if installed, else logistic-regression fallback), Decision
    Synthesis (LLM), Risk Management, Critic/Reflexion (LLM), Human Approval, Order
    Execution (paper-trading mock broker), Portfolio Monitoring, Memory (short-term
    in-process + long-term SQLite + vector FAISS)
- Real market data via `yfinance` (free, no key)
- Real RAG: chunk → embed with `sentence-transformers` → store/search in FAISS
- Real LLM calls to a local **Ollama** server (`llama3.1` / `qwen2.5`) — no paid API keys
- Structured JSON output enforced with Pydantic; prompt-injection regex/heuristic filter
- Prometheus-style `/metrics` endpoint (latency, agent success/failure, retries)
- Docker Compose to run the API + Ollama + Redis together

**Simplified / stubbed (clearly marked in code with `# STUB:`):**
- Broker integration → mock broker only (real Alpaca/Zerodha adapters would need your
  own API keys and are a thin swap-in behind the same `OrderExecutionAgent` interface)
- Voice interface (Whisper.cpp/Piper) → not wired in; the architecture supports it
  (see `app/agents/README-voice.md` note below) but binaries aren't bundled here
- Grafana dashboards → Prometheus metrics are exposed, but dashboard JSON isn't included
- News/Sentiment agents use RSS + a lightweight VADER-style fallback if FinBERT/torch
  isn't installed, to keep the base install light

This is meant as a **strong, correct starting skeleton** — every deterministic
computation is real and correct, every agent boundary matches the spec, and the
orchestration graph is real, so you can swap in bigger models, real brokers, and
a monitoring stack without re-architecting anything.

## Quick start

```bash
cd alphagen-ai
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt

# Optional (for LLM reasoning steps) — install Ollama separately, then:
ollama pull llama3.1:8b

# Run
uvicorn app.main:app --reload --port 8000
```

Or with Docker:
```bash
docker compose up --build
```

### Auth
```bash
curl -X POST localhost:8000/auth/token -d "username=demo&password=demo"
```

### Run an analysis
```bash
curl -X POST localhost:8000/analyze \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"ticker": "AAPL", "mode": "paper"}'
```

### Metrics
```bash
curl localhost:8000/metrics
```

## Architecture (as implemented)

```
Client → FastAPI Gateway → JWT Auth → Guardrails (prompt injection)
      → FinancialManagerAgent
         → PlanningAgent (LLM, builds the DAG for this request)
         → parallel: MarketDataAgent, NewsAgent, RAGAgent, SentimentAgent
         → DataValidationAgent (cross-source consistency check)
         → TechnicalAnalysisAgent (pure Python)
         → FundamentalAnalysisAgent (pure Python)
         → MLPredictionAgent (sklearn, non-LLM)
         → DecisionSynthesisAgent (LLM: BUY/SELL/HOLD + confidence + evidence)
         → RiskAgent (pure Python: drawdown/sizing/sector caps)
         → CriticAgent (LLM: hallucination/contradiction/schema check, can bounce back)
         → HumanApprovalAgent (auto in paper mode, blocking in live mode)
         → OrderExecutionAgent (mock broker)
         → PortfolioMonitoringAgent
         → MemoryAgent (short-term / long-term / vector)
      → Structured JSON response with recommendation + full evidence trail
```

See `app/graph/workflow.py` for the actual DAG wiring.
