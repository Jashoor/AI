import axios from "axios";
import { useAuthStore } from "@/store/authStore";
import type { ChatResponse, ConversationSummary, OrderData } from "@/types";

const api = axios.create({ baseURL: "/api/v1" });

api.interceptors.request.use((config) => {
  const token = useAuthStore.getState().token;
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export async function guestLogin() {
  const { data } = await api.post("/auth/guest");
  return data;
}

export async function login(email: string, password: string) {
  const { data } = await api.post("/auth/login", { email, password });
  return data;
}

export async function signup(name: string, email: string, password: string) {
  const { data } = await api.post("/auth/signup", { name, email, password });
  return data;
}

export async function sendChatMessage(message: string, conversationId: string | null): Promise<ChatResponse> {
  const { data } = await api.post("/chat", { message, conversation_id: conversationId });
  return data;
}

export async function getHistory(): Promise<ConversationSummary[]> {
  const { data } = await api.get("/history");
  return data;
}

export async function getOrder(orderId: string): Promise<OrderData> {
  const { data } = await api.get(`/orders/${orderId}`);
  return data;
}

export async function submitFeedback(conversationId: string, rating: number, comment?: string) {
  const { data } = await api.post("/feedback", { conversation_id: conversationId, rating, comment });
  return data;
}

export default api;
