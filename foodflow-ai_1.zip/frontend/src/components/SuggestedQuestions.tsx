import { Bike, Percent, ReceiptText, Truck } from "lucide-react";

const SUGGESTIONS = [
  { icon: Truck, label: "Track my order", prompt: "Where is my order FF-10234?" },
  { icon: ReceiptText, label: "Request a refund", prompt: "My food arrived cold, I'd like a refund for order FF-10234" },
  { icon: Percent, label: "Check a coupon", prompt: "Is coupon FOOD25A still valid?" },
  { icon: Bike, label: "Delivery running late", prompt: "My order is taking longer than expected, what's happening?" },
];

export default function SuggestedQuestions({ onPick }: { onPick: (prompt: string) => void }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-w-lg mx-auto">
      {SUGGESTIONS.map(({ icon: Icon, label, prompt }) => (
        <button
          key={label}
          onClick={() => onPick(prompt)}
          className="flex items-center gap-2.5 text-left px-3.5 py-3 rounded-ticket border border-ink-border bg-ink-raised hover:border-chili/60 hover:bg-ink-raised/80 transition-colors text-sm"
        >
          <span className="w-8 h-8 rounded-full bg-ink flex items-center justify-center shrink-0">
            <Icon size={15} className="text-chili" />
          </span>
          {label}
        </button>
      ))}
    </div>
  );
}
