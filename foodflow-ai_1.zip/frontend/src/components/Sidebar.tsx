import { LogOut, MessageSquarePlus, UtensilsCrossed } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { getHistory } from "@/lib/api";
import { useAuthStore } from "@/store/authStore";
import { useChatStore } from "@/store/chatStore";

export default function Sidebar() {
  const { name, isGuest, logout } = useAuthStore();
  const { reset, conversationId, setConversationId } = useChatStore();

  const { data: history } = useQuery({
    queryKey: ["history"],
    queryFn: getHistory,
    staleTime: 30_000,
  });

  return (
    <aside className="w-64 shrink-0 border-r border-ink-border bg-ink flex flex-col h-full">
      <div className="flex items-center gap-2 px-4 py-4 border-b border-ink-border">
        <div className="w-8 h-8 rounded-lg bg-chili flex items-center justify-center">
          <UtensilsCrossed size={16} className="text-white" />
        </div>
        <span className="font-display font-semibold tracking-tight">FoodFlow AI</span>
      </div>

      <button
        onClick={reset}
        className="mx-3 mt-3 flex items-center gap-2 text-sm px-3 py-2 rounded-lg border border-ink-border hover:border-chili/50 hover:bg-ink-raised transition-colors"
      >
        <MessageSquarePlus size={15} /> New conversation
      </button>

      <div className="flex-1 overflow-y-auto scrollbar-thin px-3 mt-4 space-y-1">
        <p className="text-[11px] uppercase tracking-wider text-slate/70 px-1 mb-1.5">Recent</p>
        {history?.length ? (
          history.map((h) => (
            <button
              key={h.conversation_id}
              onClick={() => setConversationId(h.conversation_id)}
              className={`w-full text-left text-sm px-3 py-2 rounded-lg truncate transition-colors ${
                conversationId === h.conversation_id ? "bg-ink-raised text-white" : "text-[#B7BCC6] hover:bg-ink-raised/60"
              }`}
            >
              {h.title}
            </button>
          ))
        ) : (
          <p className="text-xs text-slate/60 px-1">No conversations yet</p>
        )}
      </div>

      <div className="border-t border-ink-border px-4 py-3 flex items-center justify-between">
        <div className="text-sm">
          <p className="font-medium">{name}</p>
          <p className="text-xs text-slate">{isGuest ? "Guest session" : "Signed in"}</p>
        </div>
        <button onClick={logout} className="text-slate hover:text-chili transition-colors" title="Log out">
          <LogOut size={16} />
        </button>
      </div>
    </aside>
  );
}
