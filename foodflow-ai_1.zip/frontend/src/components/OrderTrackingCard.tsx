import { Bike, CheckCircle2, ChefHat, PackageCheck, Store } from "lucide-react";
import type { OrderData } from "@/types";

const STEPS = [
  { key: "placed", label: "Order placed", icon: PackageCheck },
  { key: "confirmed", label: "Confirmed", icon: Store },
  { key: "preparing", label: "Preparing", icon: ChefHat },
  { key: "out_for_delivery", label: "Out for delivery", icon: Bike },
  { key: "delivered", label: "Delivered", icon: CheckCircle2 },
];

function stepIndex(status: string): number {
  if (status === "cancelled") return -1;
  const idx = STEPS.findIndex((s) => s.key === status);
  return idx === -1 ? 0 : idx;
}

export default function OrderTrackingCard({ order }: { order: OrderData }) {
  const currentIndex = stepIndex(order.status);
  const isCancelled = order.status === "cancelled";

  return (
    <div className="order-chit p-4 pt-5 max-w-md animate-fade-up">
      <div className="flex items-center justify-between mb-1">
        <span className="font-mono text-xs text-slate tracking-wide">{order.order_id}</span>
        <span
          className={`text-xs font-medium px-2 py-0.5 rounded-full ${
            isCancelled
              ? "bg-red-500/15 text-red-400"
              : order.is_delayed
                ? "bg-turmeric/15 text-turmeric"
                : "bg-basil/15 text-basil"
          }`}
        >
          {isCancelled ? "Cancelled" : order.is_delayed ? "Delayed" : order.status.replace(/_/g, " ")}
        </span>
      </div>
      {order.restaurant_name && <p className="text-sm text-[#C9CDD6] mb-3">{order.restaurant_name}</p>}

      {!isCancelled && (
        <div className="flex flex-col gap-0">
          {STEPS.map((step, i) => {
            const Icon = step.icon;
            const done = i <= currentIndex;
            const active = i === currentIndex;
            return (
              <div key={step.key} className="flex items-start gap-3">
                <div className="flex flex-col items-center">
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 ${
                      done ? "bg-chili text-white" : "bg-ink-border text-slate"
                    } ${active ? "animate-route-pulse" : ""}`}
                  >
                    <Icon size={14} />
                  </div>
                  {i < STEPS.length - 1 && (
                    <div className={`route-line h-6 ${i < currentIndex ? "opacity-100" : "opacity-30"}`} />
                  )}
                </div>
                <span className={`text-sm pt-1 pb-4 ${done ? "text-[#E7E9EE]" : "text-slate"}`}>{step.label}</span>
              </div>
            );
          })}
        </div>
      )}

      <div className="border-t border-ink-border pt-3 mt-1 text-sm space-y-1">
        <div className="flex justify-between">
          <span className="text-slate">Total</span>
          <span className="font-mono">₹{order.total_amount.toFixed(2)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-slate">ETA</span>
          <span>{new Date(order.estimated_delivery_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
        </div>
        {order.driver_name && (
          <div className="flex justify-between">
            <span className="text-slate">Driver</span>
            <span>{order.driver_name}</span>
          </div>
        )}
      </div>
    </div>
  );
}
