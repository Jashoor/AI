import { useEffect, useRef, useState } from "react";
import { Send, ThumbsDown, ThumbsUp } from "lucide-react";
import { sendChatMessage, submitFeedback } from "@/lib/api";
import { useChatStore } from "@/store/chatStore";
import MessageBubble from "@/components/MessageBubble";
import SuggestedQuestions from "@/components/SuggestedQuestions";
import type { ChatMessage } from "@/types";

export default function ChatWindow() {
  const { conversationId, messages, isTyping, setConversationId, addMessage, setTyping } = useChatStore();
  const [input, setInput] = useState("");
  const [feedbackGiven, setFeedbackGiven] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  async function handleSend(text?: string) {
    const content = (text ?? input).trim();
    if (!content) return;

    const userMsg: ChatMessage = {
      id: crypto.randomUUID(),
      role: "user",
      content,
      createdAt: new Date().toISOString(),
    };
    addMessage(userMsg);
    setInput("");
    setTyping(true);

    try {
      const res = await sendChatMessage(content, conversationId);
      setConversationId(res.conversation_id);
      addMessage({
        id: crypto.randomUUID(),
        role: "assistant",
        content: res.reply,
        intent: res.intent,
        confidence: res.confidence,
        escalated: res.escalated,
        toolCalls: res.tool_calls,
        sourcesUsed: res.sources_used,
        createdAt: new Date().toISOString(),
      });
    } catch (err) {
      addMessage({
        id: crypto.randomUUID(),
        role: "assistant",
        content: "Something went wrong reaching the support assistant. Please try again in a moment.",
        escalated: true,
        createdAt: new Date().toISOString(),
      });
    } finally {
      setTyping(false);
    }
  }

  async function handleFeedback(rating: number) {
    if (!conversationId || feedbackGiven) return;
    await submitFeedback(conversationId, rating);
    setFeedbackGiven(true);
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto scrollbar-thin px-6 py-6">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center gap-6 -mt-10">
            <div className="text-center">
              <h1 className="font-display text-2xl font-semibold mb-1.5">How can I help with your order?</h1>
              <p className="text-slate text-sm">Ask about tracking, refunds, coupons, or anything else.</p>
            </div>
            <SuggestedQuestions onPick={(p) => handleSend(p)} />
          </div>
        ) : (
          <div className="max-w-2xl mx-auto space-y-4">
            {messages.map((m) => (
              <MessageBubble key={m.id} message={m} />
            ))}
            {isTyping && (
              <div className="flex items-center gap-2 pl-9 text-slate text-sm">
                <span className="flex gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate animate-bounce [animation-delay:-0.3s]" />
                  <span className="w-1.5 h-1.5 rounded-full bg-slate animate-bounce [animation-delay:-0.15s]" />
                  <span className="w-1.5 h-1.5 rounded-full bg-slate animate-bounce" />
                </span>
              </div>
            )}
            {!isTyping && messages.length > 0 && messages[messages.length - 1].role === "assistant" && (
              <div className="flex items-center gap-2 pl-9 pt-1">
                <span className="text-xs text-slate">Was this helpful?</span>
                <button onClick={() => handleFeedback(5)} disabled={feedbackGiven} className="text-slate hover:text-basil disabled:opacity-40">
                  <ThumbsUp size={14} />
                </button>
                <button onClick={() => handleFeedback(1)} disabled={feedbackGiven} className="text-slate hover:text-chili disabled:opacity-40">
                  <ThumbsDown size={14} />
                </button>
              </div>
            )}
            <div ref={bottomRef} />
          </div>
        )}
      </div>

      <div className="border-t border-ink-border px-6 py-4">
        <div className="max-w-2xl mx-auto flex items-center gap-2 bg-ink-raised border border-ink-border rounded-full pl-4 pr-1.5 py-1.5 focus-within:border-chili/60 transition-colors">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            placeholder="Message FoodFlow support..."
            className="flex-1 bg-transparent text-sm outline-none placeholder:text-slate/60"
          />
          <button
            onClick={() => handleSend()}
            disabled={!input.trim() || isTyping}
            className="w-8 h-8 rounded-full bg-chili flex items-center justify-center disabled:opacity-40 hover:bg-chili-dim transition-colors"
          >
            <Send size={14} className="text-white" />
          </button>
        </div>
      </div>
    </div>
  );
}
