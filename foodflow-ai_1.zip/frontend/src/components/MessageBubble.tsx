import { AlertTriangle, Bot, Sparkles, User } from "lucide-react";
import type { ChatMessage } from "@/types";

function IntentBadge({ intent, confidence }: { intent?: string; confidence?: number }) {
  if (!intent || intent === "greeting" || intent === "goodbye") return null;
  return (
    <span className="inline-flex items-center gap-1 text-[11px] font-mono text-slate/80 mt-2">
      <Sparkles size={11} className="text-turmeric" />
      {intent.replace(/_/g, " ")}
      {typeof confidence === "number" && <span className="text-slate/60">· {(confidence * 100).toFixed(0)}%</span>}
    </span>
  );
}

export default function MessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === "user";

  if (isUser) {
    return (
      <div className="flex justify-end animate-fade-up">
        <div className="max-w-[75%] bg-chili text-white rounded-2xl rounded-tr-sm px-4 py-2.5 text-sm leading-relaxed">
          {message.content}
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-start gap-2.5 animate-fade-up">
      <div className="w-7 h-7 rounded-full bg-ink-raised border border-ink-border flex items-center justify-center shrink-0 mt-0.5">
        <Bot size={14} className="text-turmeric" />
      </div>
      <div className="order-chit px-4 py-3 pt-4 max-w-[75%] text-sm leading-relaxed text-[#E7E9EE]">
        {message.escalated && (
          <div className="flex items-center gap-1.5 text-xs text-turmeric mb-2 font-medium">
            <AlertTriangle size={12} /> Escalated to human support
          </div>
        )}
        <p className="whitespace-pre-wrap">{message.content}</p>
        <IntentBadge intent={message.intent} confidence={message.confidence} />
      </div>
    </div>
  );
}
