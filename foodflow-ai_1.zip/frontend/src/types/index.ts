export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  intent?: string;
  confidence?: number;
  escalated?: boolean;
  toolCalls?: string[];
  sourcesUsed?: boolean;
  createdAt: string;
}

export interface ChatResponse {
  conversation_id: string;
  reply: string;
  intent: string;
  confidence: number;
  escalated: boolean;
  tool_calls: string[];
  sources_used: boolean;
}

export interface ConversationSummary {
  conversation_id: string;
  title: string;
  created_at: string;
  message_count: number;
}

export interface OrderData {
  order_id: string;
  status: string;
  items: { name: string; qty: number; price: number }[];
  total_amount: number;
  placed_at: string;
  estimated_delivery_at: string;
  delivered_at: string | null;
  delivery_address: string;
  is_delayed: boolean;
  delay_reason: string | null;
  restaurant_name: string | null;
  driver_name: string | null;
}

export interface AuthState {
  token: string | null;
  userId: string | null;
  name: string | null;
  isGuest: boolean;
}
