import Sidebar from "@/components/Sidebar";
import ChatWindow from "@/components/ChatWindow";

export default function ChatPage() {
  return (
    <div className="flex h-screen bg-ink">
      <Sidebar />
      <main className="flex-1 min-w-0">
        <ChatWindow />
      </main>
    </div>
  );
}
