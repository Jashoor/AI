import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { UtensilsCrossed } from "lucide-react";
import { guestLogin, login, signup } from "@/lib/api";
import { useAuthStore } from "@/store/authStore";

type Mode = "guest" | "login" | "signup";

export default function LoginPage() {
  const [mode, setMode] = useState<Mode>("guest");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const setAuth = useAuthStore((s) => s.setAuth);
  const navigate = useNavigate();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      let res;
      if (mode === "guest") res = await guestLogin();
      else if (mode === "login") res = await login(email, password);
      else res = await signup(name, email, password);

      setAuth(res.access_token, res.user_id, res.name, res.is_guest);
      navigate("/chat");
    } catch (err: any) {
      setError(err?.response?.data?.detail ?? "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-ink px-4">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center mb-8">
          <div className="w-12 h-12 rounded-xl bg-chili flex items-center justify-center mb-3">
            <UtensilsCrossed size={22} className="text-white" />
          </div>
          <h1 className="font-display text-xl font-semibold">FoodFlow AI</h1>
          <p className="text-slate text-sm mt-1">Multi-agent order support, on demand.</p>
        </div>

        <div className="flex rounded-full bg-ink-raised border border-ink-border p-1 mb-6 text-sm">
          {(["guest", "login", "signup"] as Mode[]).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`flex-1 py-1.5 rounded-full capitalize transition-colors ${
                mode === m ? "bg-chili text-white" : "text-slate hover:text-white"
              }`}
            >
              {m === "guest" ? "Guest" : m === "login" ? "Sign in" : "Sign up"}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          {mode === "signup" && (
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Full name"
              required
              className="w-full bg-ink-raised border border-ink-border rounded-lg px-3.5 py-2.5 text-sm outline-none focus:border-chili/60"
            />
          )}
          {mode !== "guest" && (
            <>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
                required
                className="w-full bg-ink-raised border border-ink-border rounded-lg px-3.5 py-2.5 text-sm outline-none focus:border-chili/60"
              />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                required
                minLength={6}
                className="w-full bg-ink-raised border border-ink-border rounded-lg px-3.5 py-2.5 text-sm outline-none focus:border-chili/60"
              />
            </>
          )}

          {error && <p className="text-sm text-chili">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-chili hover:bg-chili-dim transition-colors text-white rounded-lg py-2.5 text-sm font-medium disabled:opacity-50"
          >
            {loading ? "Please wait..." : mode === "guest" ? "Continue as guest" : mode === "login" ? "Sign in" : "Create account"}
          </button>
        </form>
      </div>
    </div>
  );
}
