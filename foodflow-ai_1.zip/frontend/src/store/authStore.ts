import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { AuthState } from "@/types";

interface AuthStore extends AuthState {
  setAuth: (token: string, userId: string, name: string, isGuest: boolean) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthStore>()(
  persist(
    (set) => ({
      token: null,
      userId: null,
      name: null,
      isGuest: false,
      setAuth: (token, userId, name, isGuest) => set({ token, userId, name, isGuest }),
      logout: () => set({ token: null, userId: null, name: null, isGuest: false }),
    }),
    { name: "foodflow-auth" }
  )
);
