import { create } from "zustand";
import type { ChatMessage } from "@/types";

interface ChatStore {
  conversationId: string | null;
  messages: ChatMessage[];
  isTyping: boolean;
  setConversationId: (id: string) => void;
  addMessage: (msg: ChatMessage) => void;
  setTyping: (typing: boolean) => void;
  reset: () => void;
}

export const useChatStore = create<ChatStore>((set) => ({
  conversationId: null,
  messages: [],
  isTyping: false,
  setConversationId: (id) => set({ conversationId: id }),
  addMessage: (msg) => set((state) => ({ messages: [...state.messages, msg] })),
  setTyping: (typing) => set({ isTyping: typing }),
  reset: () => set({ conversationId: null, messages: [] }),
}));
