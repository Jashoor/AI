# FoodFlow AI — System Architecture
### Multi-Agent Food Delivery Customer Support Platform
**Module 1 of 16 — System Architecture**

---

## 1. Problem Statement

Food delivery platforms (Swiggy, Zomato, Uber Eats, DoorDash, Deliveroo) receive millions of repetitive
support queries daily — "where is my order", "I want a refund", "my food arrived cold". Human-only support
doesn't scale, and naive single-prompt chatbots hallucinate order data, invent refund policies, and can't
call real backend systems.

**FoodFlow AI** solves this with a grounded, multi-agent architecture: intent is classified, real tools are
invoked against a real database, real policy documents are retrieved via RAG, and a response agent composes
an answer strictly from that grounded evidence — never from imagination. A safety layer guards every step,
and an escalation agent hands off to a human when the system isn't confident.

---

## 2. Design Goals

| Goal | Approach |
|---|---|
| Zero hallucination on facts (orders, refunds, policies) | Tool Calling + RAG — LLM only *phrases*, never *invents* facts |
| $0 running cost | Groq free tier (primary) → Ollama local (fallback) → HF Inference (optional); FAISS (no vector DB hosting fee); SQLite (no DB hosting fee) |
| Real multi-agent behavior, not a single mega-prompt | LangGraph explicit state graph with 7 specialized agents/nodes |
| Production-credible code | FastAPI + SQLAlchemy + Pydantic, typed, async, modular, tested, dockerized |
| Portfolio/demo quality UI | React + TS + Tailwind + shadcn/ui, streaming responses, rich cards |
| Auditable & safe | Structured logging, guardrails, PII detection, prompt-injection detection |

---

## 3. High-Level Architecture

```mermaid
flowchart TB
    subgraph Client["Frontend — React + TypeScript"]
        UI[Chat UI / Dashboard]
    end

    subgraph API["Backend — FastAPI"]
        GATE[API Gateway / Auth / Rate Limiter]
        ORCH[LangGraph Orchestrator]
    end

    subgraph Agents["Multi-Agent Layer (LangGraph)"]
        SUP[Supervisor Agent]
        INTENT[Intent Detection Agent]
        TOOL[Tool Agent]
        RAG[RAG Agent]
        RESP[Response Agent]
        SAFE[Safety Guardrail Agent]
        ESC[Escalation Agent]
    end

    subgraph Data["Data Layer"]
        SQL[(SQLite via SQLAlchemy)]
        VEC[(FAISS Vector Store)]
        DOCS[(Policy / FAQ Documents)]
    end

    subgraph LLM["LLM Providers (Free)"]
        GROQ[Groq API — Llama 3.x / Qwen / Gemma / DeepSeek / Mistral]
        OLLAMA[Ollama Local]
        HF[HuggingFace Inference - optional]
    end

    UI <--> GATE
    GATE --> ORCH
    ORCH --> SUP
    SUP --> INTENT
    INTENT --> SUP
    SUP -->|order/refund/payment intents| TOOL
    SUP -->|policy/FAQ intents| RAG
    TOOL --> SQL
    RAG --> VEC
    VEC --> DOCS
    TOOL --> RESP
    RAG --> RESP
    RESP --> SAFE
    SAFE -->|low confidence / unsafe| ESC
    SAFE -->|ok| ORCH
    ESC --> ORCH
    ORCH --> GATE
    RESP -.LLM call.-> GROQ
    RESP -.fallback.-> OLLAMA
    RESP -.optional.-> HF
    INTENT -.LLM call.-> GROQ
```

---

## 4. Agent Responsibilities

### 4.1 Supervisor Agent
- Entry point of the graph; owns session + conversation state
- Decides routing after intent detection (tool path vs RAG path vs both)
- Implements retry logic (max 2 retries per tool/LLM call) and timeout handling
- Tracks turn count, escalation triggers (repeated failures, frustration signals)

### 4.2 Intent Detection Agent
- Classifies user message into one of 16 intents (Track Order, Cancel Order, Refund Status,
  Refund Request, Payment Issue, Missing Item, Late Delivery, Coupon Query, Restaurant Information,
  Order Modification, Food Quality Complaint, FAQ, Greeting, Goodbye, Unknown Intent, Human Support)
- Uses LLM with a structured-output (JSON) prompt + confidence score
- Low confidence (< 0.55) routes to Escalation Agent directly

### 4.3 Tool Agent
- Executes real Python functions against SQLite (order status, cancellation, refunds, driver
  tracking, coupons, payments, delivery ETA, food quality reports, order history)
- Validates arguments (e.g., order ID format/ownership) before execution
- Returns structured `ToolResult` objects (success flag, data, error) — never fabricated text

### 4.4 RAG Agent
- Retrieves from FAISS index built over policy/FAQ/restaurant documents
- Pipeline: query rewrite → dense retrieval (top-k=8) → re-rank (cross-encoder-lite scoring) →
  context compression (top 3–4 chunks) → citation-tagged context
- Returns `RAGResult` (chunks + source doc ids + scores), no chunks = explicit "no grounding found" signal

### 4.5 Response Agent
- Single place that talks to the LLM for final phrasing
- Prompt strictly instructs: "only use the TOOL_RESULT and RAG_CONTEXT provided; if neither
  contains the answer, say you don't know and offer escalation"
- Injects conversation memory (name, active order id, restaurant, prior issues)

### 4.6 Safety Guardrail Agent
- Pre-check (before LLM): prompt-injection patterns, jailbreak patterns, PII in user input
- Post-check (after LLM): does response contain unverified claims not present in tool/RAG context
  (groundedness check), does it leak PII, does it match banned patterns
- Fails closed: any post-check failure → regenerate once → else escalate

### 4.7 Escalation Agent
- Triggered by: low intent confidence, repeated tool failure (≥2), safety fail, sensitive
  payment/fraud keywords, unknown intent, explicit "human support" request
- Creates a support ticket record and returns a consistent handoff message

---

## 5. LangGraph State Machine

```mermaid
stateDiagram-v2
    [*] --> Supervisor
    Supervisor --> IntentDetection
    IntentDetection --> RouteDecision
    RouteDecision --> ToolAgent: order/refund/payment/driver
    RouteDecision --> RAGAgent: policy/FAQ/restaurant-info
    RouteDecision --> ToolAgent: needs both (tool first)
    ToolAgent --> RAGAgent: if hybrid intent
    ToolAgent --> ResponseAgent
    RAGAgent --> ResponseAgent
    ResponseAgent --> SafetyAgent
    SafetyAgent --> EscalationAgent: unsafe / ungrounded / low confidence
    SafetyAgent --> [*]: safe, return response
    EscalationAgent --> [*]: return handoff message
```

## 6. Sequence Diagram — "Where is my order?"

```mermaid
sequenceDiagram
    actor U as User
    participant FE as React Frontend
    participant API as FastAPI Gateway
    participant SUP as Supervisor
    participant INT as Intent Agent
    participant TOOL as Tool Agent
    participant DB as SQLite
    participant RESP as Response Agent
    participant LLM as Groq LLM
    participant SAFE as Safety Agent

    U->>FE: "Where is my order #10234?"
    FE->>API: POST /chat
    API->>SUP: invoke(session, message)
    SUP->>INT: classify_intent(message)
    INT->>LLM: intent classification prompt
    LLM-->>INT: {intent: track_order, confidence: 0.93}
    INT-->>SUP: intent + confidence
    SUP->>TOOL: get_order_status(order_id=10234)
    TOOL->>DB: SELECT * FROM orders WHERE id=10234
    DB-->>TOOL: order row + driver + eta
    TOOL-->>SUP: ToolResult(success, data)
    SUP->>RESP: compose(tool_result, memory)
    RESP->>LLM: phrasing prompt (grounded)
    LLM-->>RESP: natural language answer
    RESP-->>SUP: draft response
    SUP->>SAFE: validate(draft, tool_result)
    SAFE-->>SUP: passed
    SUP-->>API: final response
    API-->>FE: streamed tokens
    FE-->>U: rendered answer + order tracking card
```

---

## 7. LLM Provider Strategy (Free-Tier Only)

Configurable via `.env` / `config.yaml`, resolved in this priority order:

1. **Groq API (free tier)** — `llama-3.3-70b-versatile`, `llama-3.1-8b-instant`, `qwen-2.5-32b`,
   `gemma2-9b-it`, `deepseek-r1-distill-llama-70b`, `mistral-saba-24b` (subject to Groq's current
   free catalog — model name is a config value, not hardcoded)
2. **Ollama (local)** — same model family names pulled locally (`llama3.1`, `qwen2.5`, `gemma2`,
   `deepseek-r1`, `mistral`) — zero API cost, runs on the developer's machine
3. **HuggingFace Inference API (optional, free tier)** — fallback for embeddings or small models

A `LLMProvider` interface (Strategy pattern) abstracts this so swapping providers is a one-line
config change — no code changes in agents.

**Embeddings:** `BAAI/bge-small-en-v1.5` (default, runs locally via `sentence-transformers`, no API
cost) with `nomic-embed-text` (via Ollama) as an alternative.

**Vector store:** FAISS, local, file-persisted — no hosting cost.

---

## 8. Non-Functional Requirements

- **Latency budget:** intent classification < 1.5s, tool call < 300ms, RAG retrieval < 500ms,
  final LLM phrasing < 3s (streamed)
- **Reliability:** retry with exponential backoff (max 2 retries) on LLM/tool transient failures
- **Observability:** structured JSON logs per node (agent name, latency, input hash, decision)
- **Security:** JWT auth, input sanitization, parameterized SQL (SQLAlchemy ORM — no raw SQL
  string concatenation), rate limiting per session
- **Cost:** $0 to run at demo/portfolio scale (free-tier APIs + local/open-source components)

---

## 9. Technology Decisions & Rationale

| Layer | Choice | Why |
|---|---|---|
| Orchestration | LangGraph | Explicit graph/state machine gives real multi-agent control flow, not implicit chaining |
| API | FastAPI | Async native, Pydantic validation, auto OpenAPI docs (Swagger) |
| DB | SQLite + SQLAlchemy | Zero-ops, file-based, perfectly adequate for demo-scale mock data, portable |
| Vector store | FAISS | Free, local, fast enough for a few thousand chunks, no hosting needed |
| LLM | Groq free tier first | Fastest free inference available today; Ollama as true $0 fallback with no rate limits |
| Frontend | React + TS + Tailwind + shadcn/ui | Modern, accessible components, fast to theme, matches ChatGPT/Perplexity-grade UX expectations |
| Deployment | Docker + Render/Railway/Vercel free tiers | Full containerized parity between local and "production" demo deployment at $0 |

---

## 10. What's Next

**Module 2: Folder Structure** — the full enterprise-grade repository layout (backend, frontend,
data, docs, infra) before any code is written.

Let me know if you'd like changes to this architecture, or say **"continue"** / **"next module"** to proceed to Module 2.
