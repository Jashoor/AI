"""
Tool Agent.

Given a detected intent and extracted entities, resolves which tool(s) to
call (via INTENT_TOOL_MAP) and executes them against the real database.
Applies retry logic for transient failures and returns structured
ToolResult objects - never synthesized text.
"""
from __future__ import annotations

import logging

from sqlalchemy.orm import Session

from app.core.config import settings
from app.schemas.tool_result import ToolResult
from app.tools.registry import INTENT_TOOL_MAP, call_tool

logger = logging.getLogger("foodflow.tool_agent")


def _build_kwargs(tool_name: str, entities: dict, user_id: str | None) -> dict:
    """Maps extracted entities to the keyword arguments each tool expects."""
    order_id = entities.get("order_id")
    coupon_code = entities.get("coupon_code")
    restaurant_name = entities.get("restaurant_name")

    kwargs_by_tool = {
        "get_order_status": {"order_id": order_id, "user_id": user_id},
        "cancel_order": {"order_id": order_id, "user_id": user_id},
        "track_driver": {"order_id": order_id},
        "delivery_delay": {"order_id": order_id},
        "estimate_delivery": {"order_id": order_id},
        "order_history": {"user_id": user_id},
        "report_missing_item": {"order_id": order_id, "item_name": entities.get("item_name", "")},
        "food_quality_report": {"order_id": order_id, "description": entities.get("description", "")},
        "create_refund_request": {"order_id": order_id, "reason": entities.get("reason", "Customer requested refund")},
        "refund_status": {"order_id": order_id},
        "track_refund": {"refund_id": entities.get("refund_id")},
        "payment_status": {"order_id": order_id},
        "restaurant_lookup": {"name": restaurant_name},
        "coupon_lookup": {"code": coupon_code},
        "validate_coupon": {"code": coupon_code, "order_value": entities.get("order_value", 0.0)},
        "driver_lookup": {"driver_id": entities.get("driver_id")},
    }
    return kwargs_by_tool.get(tool_name, {})


def run_tools_for_intent(db: Session, intent: str, entities: dict, user_id: str | None = None) -> list[ToolResult]:
    """Executes every tool mapped to the given intent, with bounded retries."""
    tool_names = INTENT_TOOL_MAP.get(intent, [])
    results: list[ToolResult] = []

    for tool_name in tool_names:
        kwargs = _build_kwargs(tool_name, entities, user_id)
        if not kwargs.get("order_id") and "order_id" in kwargs:
            results.append(ToolResult.fail(tool_name, "No order ID was found in the message. Please provide your order ID (e.g. FF-10234)."))
            continue

        last_result: ToolResult | None = None
        for attempt in range(settings.MAX_TOOL_RETRIES + 1):
            last_result = call_tool(tool_name, db, **kwargs)
            if last_result.success:
                break
            logger.warning(f"Tool '{tool_name}' failed on attempt {attempt + 1}: {last_result.error}")
        results.append(last_result)  # type: ignore[arg-type]

    return results
