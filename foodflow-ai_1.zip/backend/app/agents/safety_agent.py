"""
Safety Guardrail Agent.

Runs two passes:
  1. PRE-CHECK (on the raw user message)  - prompt injection, jailbreak, PII
  2. POST-CHECK (on the generated draft)  - groundedness, PII leakage, banned patterns

Fails closed: any post-check failure asks the Response Agent to regenerate
once; a second failure routes to the Escalation Agent.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

INJECTION_PATTERNS = [
    r"ignore (all |any )?(previous|prior|above) instructions",
    r"you are now",
    r"system prompt",
    r"reveal your (instructions|prompt)",
    r"disregard (the )?(rules|guidelines|policy)",
    r"act as (an? )?(unfiltered|unrestricted|jailbroken)",
    r"pretend (you|to) (have no|are not) (restrictions|filters)",
    r"DAN mode",
]

PII_PATTERNS = {
    "credit_card": r"\b(?:\d[ -]*?){13,16}\b",
    "email": r"\b[\w.+-]+@[\w-]+\.[a-zA-Z]{2,}\b",
    "phone": r"\b(?:\+?\d{1,3})?[\s-]?\d{10}\b",
    "aadhaar_like": r"\b\d{4}\s?\d{4}\s?\d{4}\b",
}

UNSAFE_KEYWORDS = ["hack", "exploit database", "bypass payment", "steal", "fraudulent refund"]


@dataclass
class SafetyCheckResult:
    passed: bool
    reasons: list[str] = field(default_factory=list)
    pii_found: list[str] = field(default_factory=list)
    escalate: bool = False


def precheck_user_message(message: str) -> SafetyCheckResult:
    reasons = []
    lowered = message.lower()

    for pattern in INJECTION_PATTERNS:
        if re.search(pattern, lowered):
            reasons.append(f"possible prompt injection/jailbreak pattern matched: '{pattern}'")

    for keyword in UNSAFE_KEYWORDS:
        if keyword in lowered:
            reasons.append(f"unsafe request keyword detected: '{keyword}'")

    pii_found = [name for name, pattern in PII_PATTERNS.items() if re.search(pattern, message)]

    passed = len(reasons) == 0
    escalate = len(reasons) > 0
    return SafetyCheckResult(passed=passed, reasons=reasons, pii_found=pii_found, escalate=escalate)


def _extract_facts(text: str) -> set[str]:
    """Extract numeric/order-id-like tokens as a crude groundedness signal."""
    return set(re.findall(r"\b(?:FF-\d+|\d+\.?\d*%?|₹?\d+[.,]?\d*)\b", text))


def postcheck_response(draft: str, grounding_texts: list[str]) -> SafetyCheckResult:
    """
    Groundedness check: every numeric/order-id fact asserted in the draft
    must also appear somewhere in the tool output / RAG context that grounded it.
    Prevents the LLM from inventing amounts, dates, or IDs.
    """
    reasons = []
    draft_facts = _extract_facts(draft)
    grounding_blob = " ".join(grounding_texts)
    grounding_facts = _extract_facts(grounding_blob)

    ungrounded = draft_facts - grounding_facts
    if ungrounded:
        reasons.append(f"draft contains facts not present in tool/RAG context: {sorted(ungrounded)[:5]}")

    pii_found = [name for name, pattern in PII_PATTERNS.items() if re.search(pattern, draft) and name != "phone"]
    # phone numbers are expected/legitimate in driver-contact responses, so only flag
    # card-number-like and aadhaar-like patterns as leakage here.

    passed = len(reasons) == 0 and len(pii_found) == 0
    return SafetyCheckResult(passed=passed, reasons=reasons, pii_found=pii_found, escalate=not passed)
