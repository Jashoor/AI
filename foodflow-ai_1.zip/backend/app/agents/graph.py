"""
LangGraph Multi-Agent Workflow.

    START
      |
      v
  Supervisor (session/memory setup)
      |
      v
  Intent Detection
      |
      v
  Route Decision --------------------------
      |                                    |
      v                                    v
  Tool Agent (order/refund/payment/...)  RAG Agent (policy/FAQ/restaurant)
      |____________________________________|
                      |
                      v
              Response Agent
                      |
                      v
              Safety Agent
               /            \\
       passed /              \\ failed
             v                 v
            END          Escalation Agent
                                |
                                v
                               END

This module builds that graph with `langgraph.graph.StateGraph`. Each node
is a thin adapter calling into the corresponding app/agents/*.py module, so
business logic stays testable outside of LangGraph itself.
"""
from __future__ import annotations

import json
import logging
from typing import Any, Optional, TypedDict

from langgraph.graph import END, StateGraph
from sqlalchemy.orm import Session

from app.agents import escalation_agent, intent_agent, rag_agent, response_agent, safety_agent, tool_agent
from app.core.config import settings
from app.schemas.tool_result import ToolResult
from app.tools.registry import INTENT_TOOL_MAP

logger = logging.getLogger("foodflow.graph")

TOOL_INTENTS = set(INTENT_TOOL_MAP.keys())
RAG_ONLY_INTENTS = {"faq", "restaurant_information"}
NO_OP_INTENTS = {"greeting", "goodbye"}
ESCALATION_TRIGGER_INTENTS = {"human_support", "unknown_intent"}
SENSITIVE_KEYWORDS = {"fraud", "unauthorized charge", "hacked", "stolen card"}


class GraphState(TypedDict, total=False):
    session_id: str
    conversation_id: str
    user_id: Optional[str]
    user_message: str
    conversation_history: list[dict[str, str]]
    memory: dict[str, Any]

    intent: str
    confidence: float
    entities: dict[str, Any]

    tool_results: list[ToolResult]
    rag_context: str
    rag_chunks_present: bool

    draft_response: str
    final_response: str
    escalated: bool
    escalation_reason: str
    consecutive_failures: int


async def supervisor_node(state: GraphState) -> GraphState:
    """Entry point: ensures memory dict exists, logs the incoming turn."""
    state.setdefault("memory", {})
    state.setdefault("conversation_history", [])
    state.setdefault("consecutive_failures", 0)
    logger.info("Supervisor received message", extra={"session_id": state.get("session_id", "-")})
    return state


async def intent_node(state: GraphState) -> GraphState:
    result = await intent_agent.detect_intent(state["user_message"], state.get("conversation_history"))
    state["intent"] = result["intent"]
    state["confidence"] = result["confidence"]
    state["entities"] = {
        "order_id": result.get("order_id"),
        "coupon_code": result.get("coupon_code"),
        "restaurant_name": result.get("restaurant_name"),
    }
    # carry active order id forward in memory if a new one wasn't mentioned
    if not state["entities"]["order_id"] and state["memory"].get("active_order_id"):
        state["entities"]["order_id"] = state["memory"]["active_order_id"]
    if result.get("order_id"):
        state["memory"]["active_order_id"] = result["order_id"]
    return state


def route_after_intent(state: GraphState) -> str:
    intent = state["intent"]
    confidence = state["confidence"]
    message_lower = state["user_message"].lower()

    if any(k in message_lower for k in SENSITIVE_KEYWORDS):
        state["escalation_reason"] = "sensitive fraud/security keyword detected"
        return "escalate"

    if confidence < settings.INTENT_CONFIDENCE_ESCALATION_THRESHOLD:
        state["escalation_reason"] = f"low intent confidence ({confidence:.2f})"
        return "escalate"

    if intent in ESCALATION_TRIGGER_INTENTS:
        state["escalation_reason"] = f"intent '{intent}' requires escalation"
        return "escalate"

    if intent in NO_OP_INTENTS:
        return "respond_direct"

    if intent in TOOL_INTENTS:
        return "tools"

    return "rag"


async def tool_node(state: GraphState) -> GraphState:
    from app.db.session import SessionLocal

    db: Session = SessionLocal()
    try:
        results = tool_agent.run_tools_for_intent(db, state["intent"], state["entities"], state.get("user_id"))
    finally:
        db.close()

    state["tool_results"] = results
    failures = sum(1 for r in results if not r.success)
    if failures and failures == len(results):
        state["consecutive_failures"] = state.get("consecutive_failures", 0) + 1
    else:
        state["consecutive_failures"] = 0

    # hybrid intents (e.g. late_delivery, refund_status) also benefit from policy context
    if state["intent"] in RAG_ONLY_INTENTS | {"late_delivery", "refund_status", "coupon_query", "cancel_order"}:
        chunks, context = rag_agent.retrieve_context(state["user_message"], state["intent"])
        state["rag_context"] = context
        state["rag_chunks_present"] = len(chunks) > 0
    else:
        state["rag_context"] = "NO_RELEVANT_CONTEXT_FOUND"
        state["rag_chunks_present"] = False
    return state


async def rag_node(state: GraphState) -> GraphState:
    chunks, context = rag_agent.retrieve_context(state["user_message"], state["intent"])
    state["rag_context"] = context
    state["rag_chunks_present"] = len(chunks) > 0
    state["tool_results"] = []
    return state


async def response_node(state: GraphState) -> GraphState:
    if state["intent"] == "greeting":
        state["draft_response"] = "Hi there! I'm the FoodFlow AI assistant. How can I help with your order today?"
        return state
    if state["intent"] == "goodbye":
        state["draft_response"] = "Thanks for reaching out to FoodFlow! Have a great day."
        return state

    draft = await response_agent.generate_response(
        user_message=state["user_message"],
        tool_results=state.get("tool_results", []),
        rag_context=state.get("rag_context", "NO_RELEVANT_CONTEXT_FOUND"),
        memory=state.get("memory", {}),
        conversation_history=state.get("conversation_history"),
    )
    state["draft_response"] = draft
    return state


async def safety_node(state: GraphState) -> GraphState:
    pre = safety_agent.precheck_user_message(state["user_message"])
    if not pre.passed:
        state["escalation_reason"] = "; ".join(pre.reasons)
        state["escalated"] = True
        return state

    grounding_texts = [json.dumps(r.data) for r in state.get("tool_results", []) if r.success]
    if state.get("rag_context"):
        grounding_texts.append(state["rag_context"])

    post = safety_agent.postcheck_response(state.get("draft_response", ""), grounding_texts)
    if not post.passed:
        state["escalation_reason"] = "; ".join(post.reasons) or "response failed groundedness check"
        state["escalated"] = True
    else:
        state["escalated"] = False
        state["final_response"] = state["draft_response"]

    if state.get("consecutive_failures", 0) >= settings.MAX_CONSECUTIVE_FAILURES_BEFORE_ESCALATION:
        state["escalated"] = True
        state["escalation_reason"] = "repeated tool failures"

    return state


def route_after_safety(state: GraphState) -> str:
    return "escalate" if state.get("escalated") else "end"


async def escalation_node(state: GraphState) -> GraphState:
    from app.db.session import SessionLocal

    db: Session = SessionLocal()
    try:
        message = escalation_agent.escalate(
            db, state.get("conversation_id", "-"), state.get("escalation_reason", "unspecified")
        )
    finally:
        db.close()
    state["final_response"] = message
    state["escalated"] = True
    return state


def build_graph():
    graph = StateGraph(GraphState)

    graph.add_node("supervisor", supervisor_node)
    graph.add_node("intent_detection", intent_node)
    graph.add_node("tool_agent", tool_node)
    graph.add_node("rag_agent", rag_node)
    graph.add_node("response_agent", response_node)
    graph.add_node("safety_agent", safety_node)
    graph.add_node("escalation_agent", escalation_node)

    graph.set_entry_point("supervisor")
    graph.add_edge("supervisor", "intent_detection")

    graph.add_conditional_edges(
        "intent_detection",
        route_after_intent,
        {
            "tools": "tool_agent",
            "rag": "rag_agent",
            "respond_direct": "response_agent",
            "escalate": "escalation_agent",
        },
    )

    graph.add_edge("tool_agent", "response_agent")
    graph.add_edge("rag_agent", "response_agent")
    graph.add_edge("response_agent", "safety_agent")

    graph.add_conditional_edges(
        "safety_agent",
        route_after_safety,
        {"escalate": "escalation_agent", "end": END},
    )
    graph.add_edge("escalation_agent", END)

    return graph.compile()


_compiled_graph = None


def get_graph():
    global _compiled_graph
    if _compiled_graph is None:
        _compiled_graph = build_graph()
    return _compiled_graph
