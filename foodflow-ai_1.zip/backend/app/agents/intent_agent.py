"""
Intent Detection Agent.

Classifies the user's message into one of the 16 supported intents using
a structured-output (JSON) LLM call, together with a confidence score.
Low confidence routes straight to the Escalation Agent (handled by the
Supervisor's routing logic, not here).
"""
from __future__ import annotations

from app.llm.provider import llm_router

INTENTS = [
    "track_order",
    "cancel_order",
    "refund_status",
    "refund_request",
    "payment_issue",
    "missing_item",
    "late_delivery",
    "coupon_query",
    "restaurant_information",
    "order_modification",
    "food_quality_complaint",
    "faq",
    "greeting",
    "goodbye",
    "unknown_intent",
    "human_support",
]

SYSTEM_PROMPT = f"""You are an intent classifier for a food delivery support chatbot.
Classify the user's message into exactly one of these intents:
{", ".join(INTENTS)}

Also extract any order ID mentioned (format like "FF-12345" or a bare number that looks
like an order id), any coupon code mentioned, and any restaurant name mentioned.

Respond ONLY with a JSON object in this exact shape, no extra text:
{{
  "intent": "<one of the intents above>",
  "confidence": <float between 0 and 1>,
  "order_id": "<string or null>",
  "coupon_code": "<string or null>",
  "restaurant_name": "<string or null>",
  "reasoning": "<one short sentence>"
}}
"""


async def detect_intent(message: str, conversation_history: list[dict[str, str]] | None = None) -> dict:
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    if conversation_history:
        # last few turns for context, so "what about my refund" after "track FF-1002" resolves correctly
        messages.extend(conversation_history[-4:])
    messages.append({"role": "user", "content": message})

    try:
        result = await llm_router.chat_json(messages, temperature=0.0, max_tokens=200)
    except Exception:
        return {
            "intent": "unknown_intent",
            "confidence": 0.0,
            "order_id": None,
            "coupon_code": None,
            "restaurant_name": None,
            "reasoning": "intent classification call failed",
        }

    if result.get("intent") not in INTENTS:
        result["intent"] = "unknown_intent"
        result["confidence"] = min(result.get("confidence", 0.0), 0.4)

    result.setdefault("order_id", None)
    result.setdefault("coupon_code", None)
    result.setdefault("restaurant_name", None)
    result.setdefault("confidence", 0.5)
    return result
