"""
Response Agent.

The single point in the entire system where natural language is generated
for the user. It receives ONLY:
  - tool outputs (structured facts)
  - RAG context (retrieved policy/FAQ text)
  - conversation memory (name, active order, prior issues)

and is instructed to never state a fact that isn't present in that
material. If neither tools nor RAG produced anything usable, it must say
so plainly and offer escalation, rather than guessing.
"""
from __future__ import annotations

import json

from app.llm.provider import llm_router
from app.schemas.tool_result import ToolResult

SYSTEM_PROMPT = """You are FoodFlow AI's customer support assistant for a food delivery app.
Your tone is warm, concise, and professional - like a great human support agent, not a robot.

STRICT GROUNDING RULES (never break these):
1. Only state facts that appear in TOOL_RESULTS or RAG_CONTEXT below. Never invent order
   statuses, amounts, dates, policy terms, or restaurant details.
2. If TOOL_RESULTS shows an error, explain the issue in plain language and suggest a next
   step - do not pretend the tool succeeded.
3. If RAG_CONTEXT is "NO_RELEVANT_CONTEXT_FOUND" and there are no TOOL_RESULTS either, say
   you don't have enough information to answer confidently and offer to connect them with
   a human support executive. Do not guess.
4. Use conversation MEMORY (name, active order, restaurant, prior issues) to personalize
   your reply, but never invent memory details that weren't provided.
5. Keep responses to 2-4 sentences unless listing structured data (like an order timeline).
"""


def _tool_results_to_text(results: list[ToolResult]) -> str:
    if not results:
        return "NO_TOOL_CALLS_MADE"
    lines = []
    for r in results:
        if r.success:
            lines.append(f"[{r.tool_name}] SUCCESS: {json.dumps(r.data)}")
        else:
            lines.append(f"[{r.tool_name}] FAILED: {r.error}")
    return "\n".join(lines)


async def generate_response(
    user_message: str,
    tool_results: list[ToolResult],
    rag_context: str,
    memory: dict,
    conversation_history: list[dict[str, str]] | None = None,
) -> str:
    tool_text = _tool_results_to_text(tool_results)

    user_prompt = f"""USER MESSAGE: {user_message}

TOOL_RESULTS:
{tool_text}

RAG_CONTEXT:
{rag_context}

MEMORY:
{json.dumps(memory)}

Write the assistant's reply now, following the strict grounding rules."""

    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    if conversation_history:
        messages.extend(conversation_history[-6:])
    messages.append({"role": "user", "content": user_prompt})

    response = await llm_router.chat(messages, temperature=0.4, max_tokens=350)
    return response.content.strip()
