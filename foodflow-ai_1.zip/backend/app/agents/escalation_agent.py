"""
Escalation Agent.

Creates a support ticket and returns the standard handoff message whenever
the graph decides a human is needed: low intent confidence, repeated tool
failures, safety-check failure, sensitive payment/fraud terms, unknown
intent, or an explicit request for a human.
"""
from __future__ import annotations

from sqlalchemy.orm import Session

from app.db.models import SupportTicket

HANDOFF_MESSAGE = (
    "I've connected you with a human support executive who can take a closer look at this. "
    "They'll follow up shortly with more details."
)


def escalate(db: Session, conversation_id: str, reason: str) -> str:
    ticket = SupportTicket(conversation_id=conversation_id, reason=reason)
    db.add(ticket)
    db.commit()
    return HANDOFF_MESSAGE
