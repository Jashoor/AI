"""
Application configuration.

All settings are environment-driven (12-factor style) so the same code runs
locally, in Docker, or on a free-tier host (Render/Railway) without changes.
"""
from functools import lru_cache
from typing import Literal, Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # --- App ---
    APP_NAME: str = "FoodFlow AI"
    ENV: Literal["development", "production", "test"] = "development"
    DEBUG: bool = True
    API_V1_PREFIX: str = "/api/v1"

    # --- Security ---
    JWT_SECRET_KEY: str = "change-me-in-production-please"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRE_MINUTES: int = 60 * 24
    ALLOW_GUEST_LOGIN: bool = True

    # --- CORS ---
    CORS_ORIGINS: str = "http://localhost:5173,http://localhost:3000"

    # --- Database ---
    DATABASE_URL: str = "sqlite:///./data/foodflow.db"

    # --- LLM Provider strategy: groq -> ollama -> huggingface ---
    LLM_PROVIDER: Literal["groq", "ollama", "huggingface"] = "groq"
    LLM_FALLBACK_PROVIDER: Literal["groq", "ollama", "huggingface", "none"] = "ollama"

    # Groq (free tier) - https://console.groq.com
    GROQ_API_KEY: Optional[str] = None
    GROQ_MODEL: str = "llama-3.3-70b-versatile"

    # Ollama (local, $0 cost, no API key needed)
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_MODEL: str = "llama3.1"

    # HuggingFace Inference API (optional free tier)
    HF_API_KEY: Optional[str] = None
    HF_MODEL: str = "Qwen/Qwen2.5-7B-Instruct"

    LLM_TEMPERATURE: float = 0.3
    LLM_MAX_TOKENS: int = 700
    LLM_TIMEOUT_SECONDS: int = 20
    LLM_MAX_RETRIES: int = 2

    # --- Embeddings / RAG ---
    EMBEDDING_MODEL: str = "BAAI/bge-small-en-v1.5"  # local, sentence-transformers, free
    EMBEDDING_PROVIDER: Literal["local", "ollama"] = "local"
    OLLAMA_EMBEDDING_MODEL: str = "nomic-embed-text"
    FAISS_INDEX_DIR: str = "./data/faiss_index"
    RAG_TOP_K: int = 8
    RAG_RERANK_TOP_N: int = 4
    RAG_CHUNK_SIZE: int = 500
    RAG_CHUNK_OVERLAP: int = 80

    # --- Agent behavior ---
    INTENT_CONFIDENCE_ESCALATION_THRESHOLD: float = 0.55
    MAX_TOOL_RETRIES: int = 2
    MAX_CONSECUTIVE_FAILURES_BEFORE_ESCALATION: int = 2

    # --- Rate limiting ---
    RATE_LIMIT_PER_MINUTE: int = 30

    @property
    def cors_origins_list(self) -> list[str]:
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
