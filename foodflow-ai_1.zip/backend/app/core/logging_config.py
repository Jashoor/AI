"""
Structured JSON logging so agent/tool/LLM traces can be searched and
correlated by session_id, agent name, and latency in any log viewer.
"""
import json
import logging
import sys
import time
from typing import Any


class JSONFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp": self.formatTime(record, "%Y-%m-%dT%H:%M:%S%z"),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        for key in ("session_id", "agent", "intent", "latency_ms", "tool_name", "order_id"):
            if hasattr(record, key):
                payload[key] = getattr(record, key)
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False)


def configure_logging(level: str = "INFO") -> None:
    root = logging.getLogger()
    root.setLevel(level)
    root.handlers.clear()

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JSONFormatter())
    root.addHandler(handler)


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


class Timer:
    """Context manager for measuring and logging node/tool latency."""

    def __init__(self, logger: logging.Logger, agent: str, session_id: str = "-"):
        self.logger = logger
        self.agent = agent
        self.session_id = session_id
        self.start = 0.0
        self.elapsed_ms = 0.0

    def __enter__(self) -> "Timer":
        self.start = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.elapsed_ms = round((time.perf_counter() - self.start) * 1000, 2)
        self.logger.info(
            f"{self.agent} completed",
            extra={"agent": self.agent, "session_id": self.session_id, "latency_ms": self.elapsed_ms},
        )
