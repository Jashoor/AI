"""
FoodFlow AI - FastAPI application entrypoint.

Run locally:
    uvicorn app.main:app --reload --port 8000

Swagger docs available at /docs, ReDoc at /redoc once running.
"""
from __future__ import annotations

import time
from collections import defaultdict

from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.routes import auth, chat, resources
from app.core.config import settings
from app.core.logging_config import configure_logging
from app.db.session import init_db

configure_logging("DEBUG" if settings.DEBUG else "INFO")

app = FastAPI(
    title=settings.APP_NAME,
    description="Multi-Agent Food Delivery Customer Support Platform - LangGraph + RAG + Tool Calling, 100% free-tier LLMs.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Simple in-memory rate limiter (per IP, sliding window) ---
_request_log: dict[str, list[float]] = defaultdict(list)


@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    client_ip = request.client.host if request.client else "unknown"
    now = time.time()
    window_start = now - 60
    _request_log[client_ip] = [t for t in _request_log[client_ip] if t > window_start]

    if len(_request_log[client_ip]) >= settings.RATE_LIMIT_PER_MINUTE:
        return JSONResponse(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            content={"detail": "Rate limit exceeded. Please slow down."},
        )

    _request_log[client_ip].append(now)
    response = await call_next(request)
    return response


@app.on_event("startup")
def on_startup() -> None:
    init_db()


@app.get("/health", tags=["system"])
def health_check() -> dict:
    return {"status": "ok", "app": settings.APP_NAME, "env": settings.ENV}


app.include_router(auth.router, prefix=settings.API_V1_PREFIX)
app.include_router(chat.router, prefix=settings.API_V1_PREFIX)
app.include_router(resources.router, prefix=settings.API_V1_PREFIX)
