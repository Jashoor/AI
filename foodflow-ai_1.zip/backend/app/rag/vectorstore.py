"""
FAISS-backed vector store. Free, local, file-persisted - no hosted vector
DB fees. Stores chunk metadata alongside the index so retrieval results
can be traced back to source documents (for citations and audits).
"""
from __future__ import annotations

import json
import pickle
from pathlib import Path

import numpy as np

from app.core.config import settings
from app.rag.chunker import Chunk


class FaissVectorStore:
    def __init__(self, index_dir: str = settings.FAISS_INDEX_DIR):
        self.index_dir = Path(index_dir)
        self.index_dir.mkdir(parents=True, exist_ok=True)
        self.index_path = self.index_dir / "index.faiss"
        self.meta_path = self.index_dir / "chunks.pkl"
        self.index = None
        self.chunks: list[Chunk] = []

    def build(self, chunks: list[Chunk], embeddings: np.ndarray) -> None:
        import faiss  # imported lazily so the module can be imported without faiss installed

        dim = embeddings.shape[1]
        index = faiss.IndexFlatIP(dim)  # cosine similarity via normalized inner product
        index.add(embeddings)
        self.index = index
        self.chunks = chunks
        self._persist()

    def _persist(self) -> None:
        import faiss

        faiss.write_index(self.index, str(self.index_path))
        with self.meta_path.open("wb") as f:
            pickle.dump(self.chunks, f)

    def load(self) -> bool:
        import faiss

        if not self.index_path.exists() or not self.meta_path.exists():
            return False
        self.index = faiss.read_index(str(self.index_path))
        with self.meta_path.open("rb") as f:
            self.chunks = pickle.load(f)
        return True

    def search(self, query_embedding: np.ndarray, top_k: int = settings.RAG_TOP_K) -> list[tuple[Chunk, float]]:
        if self.index is None:
            raise RuntimeError("Vector store not built/loaded. Call build() or load() first.")
        scores, indices = self.index.search(query_embedding.reshape(1, -1), top_k)
        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx == -1:
                continue
            results.append((self.chunks[idx], float(score)))
        return results
