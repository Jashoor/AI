"""Document loader supporting Markdown, TXT, JSON, and CSV knowledge sources."""
from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path


@dataclass
class RawDocument:
    doc_id: str
    source: str
    category: str
    text: str


def load_markdown_or_text(path: Path, category: str) -> RawDocument:
    text = path.read_text(encoding="utf-8")
    return RawDocument(doc_id=path.stem, source=str(path), category=category, text=text)


def load_json_faqs(path: Path) -> list[RawDocument]:
    """Expects a list of {category, question, answer} objects."""
    items = json.loads(path.read_text(encoding="utf-8"))
    docs = []
    for i, item in enumerate(items):
        text = f"Q: {item['question']}\nA: {item['answer']}"
        docs.append(RawDocument(doc_id=f"{path.stem}_{i}", source=str(path), category=item.get("category", "faq"), text=text))
    return docs


def load_csv(path: Path, category: str, text_columns: list[str]) -> list[RawDocument]:
    docs = []
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader):
            text = "\n".join(f"{col}: {row.get(col, '')}" for col in text_columns)
            docs.append(RawDocument(doc_id=f"{path.stem}_{i}", source=str(path), category=category, text=text))
    return docs


def load_documents_dir(directory: Path) -> list[RawDocument]:
    """Load every supported file under a documents directory."""
    docs: list[RawDocument] = []
    for path in sorted(directory.glob("**/*")):
        if path.is_dir():
            continue
        category = path.parent.name if path.parent != directory else "general"
        if path.suffix in (".md", ".txt"):
            docs.append(load_markdown_or_text(path, category))
        elif path.suffix == ".json":
            docs.extend(load_json_faqs(path))
        elif path.suffix == ".csv":
            # Best-effort: use all columns as text.
            with path.open(newline="", encoding="utf-8") as f:
                header = next(csv.reader(f))
            docs.extend(load_csv(path, category, header))
    return docs
