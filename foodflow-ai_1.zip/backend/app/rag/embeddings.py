"""
Embedding provider abstraction.

Default: BAAI/bge-small-en-v1.5 via `sentence-transformers`, running fully
locally (no API key, no per-call cost, ~130MB model downloaded once).

Alternative: `nomic-embed-text` served locally through Ollama, useful when
the whole stack (LLM + embeddings) should share a single local runtime.
"""
from __future__ import annotations

import httpx
import numpy as np

from app.core.config import settings


class LocalSentenceTransformerEmbedder:
    """Runs entirely on-machine via sentence-transformers. $0 cost."""

    def __init__(self, model_name: str = settings.EMBEDDING_MODEL):
        from sentence_transformers import SentenceTransformer  # imported lazily

        self.model = SentenceTransformer(model_name)

    def embed(self, texts: list[str]) -> np.ndarray:
        embeddings = self.model.encode(texts, normalize_embeddings=True, show_progress_bar=False)
        return np.asarray(embeddings, dtype="float32")


class OllamaEmbedder:
    """Uses a local Ollama server for embeddings (e.g. nomic-embed-text)."""

    def __init__(self, model_name: str = settings.OLLAMA_EMBEDDING_MODEL):
        self.model_name = model_name
        self.base_url = settings.OLLAMA_BASE_URL

    def embed(self, texts: list[str]) -> np.ndarray:
        vectors = []
        with httpx.Client(timeout=30) as client:
            for text in texts:
                resp = client.post(f"{self.base_url}/api/embeddings", json={"model": self.model_name, "prompt": text})
                resp.raise_for_status()
                vectors.append(resp.json()["embedding"])
        arr = np.asarray(vectors, dtype="float32")
        norms = np.linalg.norm(arr, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        return arr / norms


def get_embedder():
    if settings.EMBEDDING_PROVIDER == "ollama":
        return OllamaEmbedder()
    return LocalSentenceTransformerEmbedder()
