"""
Builds the FAISS index from:
  1. Markdown/TXT policy & FAQ documents in backend/data/documents/
  2. Policy + FAQ rows already generated in the SQLite database

Run after `generate_mock_data.py` and whenever documents/ changes:
    python -m app.rag.build_index
"""
from __future__ import annotations

from pathlib import Path

from app.core.config import settings
from app.db.models import FAQ, Policy
from app.db.session import SessionLocal
from app.rag.chunker import chunk_documents
from app.rag.embeddings import get_embedder
from app.rag.loader import RawDocument, load_documents_dir
from app.rag.vectorstore import FaissVectorStore

DOCUMENTS_DIR = Path(__file__).resolve().parent.parent.parent / "data" / "documents"


def load_db_documents() -> list[RawDocument]:
    db = SessionLocal()
    docs: list[RawDocument] = []
    for p in db.query(Policy).all():
        docs.append(RawDocument(doc_id=f"policy_{p.id}", source=f"policy:{p.title}", category=f"policy:{p.category}", text=f"{p.title}. {p.content}"))
    for f in db.query(FAQ).all():
        docs.append(RawDocument(doc_id=f"faq_{f.id}", source=f"faq:{f.question[:40]}", category=f"faq:{f.category}", text=f"Q: {f.question}\nA: {f.answer}"))
    db.close()
    return docs


def run() -> None:
    print("Loading file-based documents from data/documents/ ...")
    file_docs = load_documents_dir(DOCUMENTS_DIR) if DOCUMENTS_DIR.exists() else []
    print(f"  loaded {len(file_docs)} file documents")

    print("Loading policy/FAQ rows from database ...")
    db_docs = load_db_documents()
    print(f"  loaded {len(db_docs)} database documents")

    all_docs = file_docs + db_docs
    if not all_docs:
        print("No documents found. Run generate_mock_data.py first, or add files to data/documents/.")
        return

    print("Chunking documents ...")
    chunks = chunk_documents(all_docs)
    print(f"  produced {len(chunks)} chunks")

    print(f"Embedding chunks with provider='{settings.EMBEDDING_PROVIDER}', model='{settings.EMBEDDING_MODEL}' ...")
    embedder = get_embedder()
    texts = [c.text for c in chunks]
    embeddings = embedder.embed(texts)

    print("Building FAISS index ...")
    store = FaissVectorStore()
    store.build(chunks, embeddings)
    print(f"Index saved to {settings.FAISS_INDEX_DIR}")


if __name__ == "__main__":
    run()
