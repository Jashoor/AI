"""Text chunker: sentence-boundary-aware fixed-size chunks with overlap."""
from __future__ import annotations

import re
from dataclasses import dataclass

from app.core.config import settings
from app.rag.loader import RawDocument

_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")


@dataclass
class Chunk:
    chunk_id: str
    doc_id: str
    source: str
    category: str
    text: str


def split_sentences(text: str) -> list[str]:
    return [s.strip() for s in _SENTENCE_SPLIT.split(text.strip()) if s.strip()]


def chunk_document(
    doc: RawDocument,
    chunk_size: int = settings.RAG_CHUNK_SIZE,
    overlap: int = settings.RAG_CHUNK_OVERLAP,
) -> list[Chunk]:
    """
    Greedily packs sentences into chunks up to `chunk_size` characters,
    carrying `overlap` characters of trailing context into the next chunk
    so that facts split across a chunk boundary are not lost.
    """
    sentences = split_sentences(doc.text)
    chunks: list[Chunk] = []
    current = ""
    idx = 0

    for sentence in sentences:
        candidate = f"{current} {sentence}".strip()
        if len(candidate) <= chunk_size or not current:
            current = candidate
        else:
            chunks.append(Chunk(chunk_id=f"{doc.doc_id}_{idx}", doc_id=doc.doc_id, source=doc.source, category=doc.category, text=current))
            idx += 1
            tail = current[-overlap:] if overlap > 0 else ""
            current = f"{tail} {sentence}".strip()

    if current:
        chunks.append(Chunk(chunk_id=f"{doc.doc_id}_{idx}", doc_id=doc.doc_id, source=doc.source, category=doc.category, text=current))

    return chunks


def chunk_documents(docs: list[RawDocument]) -> list[Chunk]:
    all_chunks: list[Chunk] = []
    for doc in docs:
        all_chunks.extend(chunk_document(doc))
    return all_chunks
