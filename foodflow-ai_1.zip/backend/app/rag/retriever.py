"""
Retriever chain: query -> dense retrieval (FAISS top-K) -> lexical-overlap
re-ranking -> context compression (top-N chunks, deduplicated by source).

The re-ranker here is intentionally dependency-free (token-overlap scoring
combined with the dense score) so the whole RAG pipeline runs with zero
paid APIs. It can be swapped for a cross-encoder model without changing
the Agent-facing interface (`retrieve`).
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from app.core.config import settings
from app.rag.chunker import Chunk
from app.rag.embeddings import get_embedder
from app.rag.vectorstore import FaissVectorStore

_TOKEN_RE = re.compile(r"[a-z0-9]+")


def _tokenize(text: str) -> set[str]:
    return set(_TOKEN_RE.findall(text.lower()))


@dataclass
class RetrievedChunk:
    text: str
    source: str
    category: str
    dense_score: float
    rerank_score: float


class Retriever:
    def __init__(self) -> None:
        self.embedder = get_embedder()
        self.store = FaissVectorStore()
        if not self.store.load():
            raise RuntimeError(
                "FAISS index not found. Run `python -m app.rag.build_index` to build it first."
            )

    def _rerank(self, query: str, candidates: list[tuple[Chunk, float]]) -> list[RetrievedChunk]:
        query_tokens = _tokenize(query)
        reranked = []
        for chunk, dense_score in candidates:
            chunk_tokens = _tokenize(chunk.text)
            overlap = len(query_tokens & chunk_tokens) / max(len(query_tokens), 1)
            # Weighted blend: dense similarity dominates, lexical overlap breaks ties
            combined = 0.75 * dense_score + 0.25 * overlap
            reranked.append(
                RetrievedChunk(text=chunk.text, source=chunk.source, category=chunk.category, dense_score=dense_score, rerank_score=combined)
            )
        reranked.sort(key=lambda c: c.rerank_score, reverse=True)
        return reranked

    def retrieve(self, query: str, top_k: int = settings.RAG_TOP_K, top_n: int = settings.RAG_RERANK_TOP_N) -> list[RetrievedChunk]:
        query_embedding = self.embedder.embed([query])[0]
        candidates = self.store.search(query_embedding, top_k=top_k)
        reranked = self._rerank(query, candidates)

        # Context compression: cap to top_n and drop near-duplicate sources
        compressed: list[RetrievedChunk] = []
        seen_sources: set[str] = set()
        for c in reranked:
            key = f"{c.source}:{c.text[:40]}"
            if key in seen_sources:
                continue
            seen_sources.add(key)
            compressed.append(c)
            if len(compressed) >= top_n:
                break
        return compressed

    @staticmethod
    def format_context(chunks: list[RetrievedChunk]) -> str:
        """Renders retrieved chunks into a citation-tagged context block for the LLM prompt."""
        if not chunks:
            return "NO_RELEVANT_CONTEXT_FOUND"
        lines = []
        for i, c in enumerate(chunks, start=1):
            lines.append(f"[Source {i} | {c.category}] {c.text}")
        return "\n\n".join(lines)


_retriever_singleton: Retriever | None = None


def get_retriever() -> Retriever:
    global _retriever_singleton
    if _retriever_singleton is None:
        _retriever_singleton = Retriever()
    return _retriever_singleton
