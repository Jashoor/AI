from __future__ import annotations

import json
import logging
import uuid

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.agents.graph import get_graph
from app.core.security import get_current_user
from app.db.models import Conversation, Message, User
from app.db.session import get_db
from app.schemas.api_schemas import ChatRequest, ChatResponse

router = APIRouter(tags=["chat"])
logger = logging.getLogger("foodflow.chat_route")


def _get_or_create_conversation(db: Session, user: User, conversation_id: str | None) -> Conversation:
    if conversation_id:
        convo = db.query(Conversation).filter(Conversation.id == conversation_id, Conversation.user_id == user.id).first()
        if convo:
            return convo
    convo = Conversation(user_id=user.id, title="New conversation")
    db.add(convo)
    db.commit()
    db.refresh(convo)
    return convo


@router.post("/chat", response_model=ChatResponse)
async def chat(payload: ChatRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)) -> ChatResponse:
    convo = _get_or_create_conversation(db, user, payload.conversation_id)

    history_rows = (
        db.query(Message).filter(Message.conversation_id == convo.id).order_by(Message.created_at.asc()).all()
    )
    conversation_history = [{"role": m.role, "content": m.content} for m in history_rows]
    memory = json.loads(convo.memory_json or "{}")

    graph = get_graph()
    initial_state = {
        "session_id": str(uuid.uuid4()),
        "conversation_id": convo.id,
        "user_id": user.id,
        "user_message": payload.message,
        "conversation_history": conversation_history,
        "memory": memory,
    }

    try:
        final_state = await graph.ainvoke(initial_state)
    except Exception as exc:  # noqa: BLE001
        # A bug or transient failure anywhere in the agent graph (LLM outage,
        # a malformed tool response, etc.) must never surface as a raw 500 to
        # the user - fail safe into an escalation-style reply instead, and log
        # the real exception for debugging.
        logger.exception(f"Graph execution failed for conversation {convo.id}: {exc}")
        final_state = {
            "final_response": (
                "Something went wrong on our end while processing that. "
                "I've noted the issue - please try rephrasing, or ask again in a moment."
            ),
            "intent": "unknown_intent",
            "confidence": 0.0,
            "escalated": True,
            "tool_results": [],
            "rag_chunks_present": False,
            "memory": memory,
        }

    # Persist turn + updated memory
    db.add(Message(conversation_id=convo.id, role="user", content=payload.message))
    db.add(
        Message(
            conversation_id=convo.id,
            role="assistant",
            content=final_state.get("final_response", ""),
            intent=final_state.get("intent"),
            confidence=final_state.get("confidence"),
            escalated=final_state.get("escalated", False),
        )
    )
    if convo.title == "New conversation":
        convo.title = payload.message[:60]
    convo.memory_json = json.dumps(final_state.get("memory", {}))
    db.commit()

    tool_calls = [r.tool_name for r in final_state.get("tool_results", [])]
    sources_used = final_state.get("rag_chunks_present", False)

    return ChatResponse(
        conversation_id=convo.id,
        reply=final_state.get("final_response", "I'm sorry, something went wrong. Please try again."),
        intent=final_state.get("intent", "unknown_intent"),
        confidence=final_state.get("confidence", 0.0),
        escalated=final_state.get("escalated", False),
        tool_calls=tool_calls,
        sources_used=sources_used,
    )
