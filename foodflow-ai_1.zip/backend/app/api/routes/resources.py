"""
Direct REST endpoints mirroring the tool layer, for non-chat programmatic
access (e.g. the frontend's order tracking page hitting GET /orders/{id}
directly instead of going through the chat agent).
"""
from __future__ import annotations

import json

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session

from app.core.security import get_current_user
from app.db.models import Conversation, Feedback, Order, User
from app.db.session import get_db
from app.schemas.api_schemas import (
    CancelOrderRequest,
    ConversationSummary,
    FeedbackRequest,
    MissingItemRequest,
    RefundRequestBody,
)
from app.tools import catalog_tools, order_tools, refund_payment_tools

router = APIRouter(tags=["resources"])


@router.get("/orders/{order_id}")
def get_order(order_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    result = order_tools.get_order_status(db, order_id, user.id)
    if not result.success:
        raise HTTPException(status_code=404, detail=result.error)
    return result.data


@router.post("/cancel")
def cancel_order(payload: CancelOrderRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    result = order_tools.cancel_order(db, payload.order_id, user.id)
    if not result.success:
        raise HTTPException(status_code=400, detail=result.error)
    return result.data


@router.post("/refund")
def request_refund(payload: RefundRequestBody, db: Session = Depends(get_db)):
    result = refund_payment_tools.create_refund_request(db, payload.order_id, payload.reason)
    if not result.success:
        raise HTTPException(status_code=400, detail=result.error)
    return result.data


@router.post("/missing-item")
def missing_item(payload: MissingItemRequest, db: Session = Depends(get_db)):
    result = order_tools.report_missing_item(db, payload.order_id, payload.item_name)
    if not result.success:
        raise HTTPException(status_code=400, detail=result.error)
    return result.data


@router.get("/restaurant/{restaurant_id}")
def get_restaurant(restaurant_id: str, db: Session = Depends(get_db)):
    result = catalog_tools.restaurant_lookup(db, restaurant_id=restaurant_id)
    if not result.success:
        raise HTTPException(status_code=404, detail=result.error)
    return result.data


@router.get("/coupon/{code}")
def get_coupon(code: str, db: Session = Depends(get_db)):
    result = catalog_tools.coupon_lookup(db, code)
    if not result.success:
        raise HTTPException(status_code=404, detail=result.error)
    return result.data


@router.get("/driver/{driver_id}")
def get_driver(driver_id: str, db: Session = Depends(get_db)):
    result = catalog_tools.driver_lookup(db, driver_id)
    if not result.success:
        raise HTTPException(status_code=404, detail=result.error)
    return result.data


@router.get("/history", response_model=list[ConversationSummary])
def get_history(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    convos = db.query(Conversation).filter(Conversation.user_id == user.id).order_by(Conversation.created_at.desc()).all()
    return [
        ConversationSummary(
            conversation_id=c.id,
            title=c.title,
            created_at=c.created_at,
            message_count=len(c.messages),
        )
        for c in convos
    ]


@router.post("/feedback")
def submit_feedback(payload: FeedbackRequest, db: Session = Depends(get_db)):
    feedback = Feedback(conversation_id=payload.conversation_id, rating=payload.rating, comment=payload.comment)
    db.add(feedback)
    db.commit()
    return {"status": "recorded", "feedback_id": feedback.id}


@router.post("/upload-documents")
async def upload_documents(file: UploadFile = File(...)):
    from pathlib import Path

    dest_dir = Path(__file__).resolve().parents[3] / "data" / "documents" / "uploaded"
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest_path = dest_dir / file.filename
    content = await file.read()
    dest_path.write_bytes(content)
    return {"status": "uploaded", "path": str(dest_path), "note": "Call POST /reindex to add this to the RAG index."}


@router.post("/reindex")
def reindex():
    from app.rag.build_index import run as build_index_run

    build_index_run()
    return {"status": "reindexed"}
