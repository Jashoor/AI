"""
Order-related tools. Every function executes a real query/mutation against
the SQLite database via SQLAlchemy - no fabricated data is ever returned.
"""
from __future__ import annotations

import json
from datetime import datetime

from sqlalchemy.orm import Session

from app.db.models import Order, OrderStatus
from app.schemas.tool_result import ToolResult


def _order_to_dict(order: Order) -> dict:
    return {
        "order_id": order.display_id,
        "status": order.status.value,
        "items": json.loads(order.items_json),
        "total_amount": order.total_amount,
        "placed_at": order.placed_at.isoformat(),
        "estimated_delivery_at": order.estimated_delivery_at.isoformat(),
        "delivered_at": order.delivered_at.isoformat() if order.delivered_at else None,
        "delivery_address": order.delivery_address,
        "is_delayed": order.is_delayed,
        "delay_reason": order.delay_reason,
        "restaurant_name": order.restaurant.name if order.restaurant else None,
        "driver_name": order.driver.name if order.driver else None,
        "driver_phone": order.driver.phone if order.driver else None,
    }


def get_order_status(db: Session, order_id: str, user_id: str | None = None) -> ToolResult:
    """Fetch the live status of an order by its display id (e.g. 'FF-10234')."""
    order = db.query(Order).filter(Order.display_id == order_id).first()
    if order is None:
        return ToolResult.fail("get_order_status", f"No order found with id '{order_id}'.")
    if user_id and order.user_id != user_id:
        return ToolResult.fail("get_order_status", "This order does not belong to the requesting user.")
    return ToolResult.ok("get_order_status", _order_to_dict(order))


def cancel_order(db: Session, order_id: str, user_id: str | None = None) -> ToolResult:
    """Cancel an order if it is still cancellable (not out_for_delivery/delivered)."""
    order = db.query(Order).filter(Order.display_id == order_id).first()
    if order is None:
        return ToolResult.fail("cancel_order", f"No order found with id '{order_id}'.")
    if user_id and order.user_id != user_id:
        return ToolResult.fail("cancel_order", "This order does not belong to the requesting user.")
    if order.status in (OrderStatus.OUT_FOR_DELIVERY, OrderStatus.DELIVERED, OrderStatus.CANCELLED):
        return ToolResult.fail(
            "cancel_order",
            f"Order '{order_id}' cannot be cancelled - current status is '{order.status.value}'.",
        )
    order.status = OrderStatus.CANCELLED
    db.commit()
    return ToolResult.ok("cancel_order", {"order_id": order_id, "status": order.status.value})


def track_driver(db: Session, order_id: str) -> ToolResult:
    """Return the assigned driver's live location/contact for an order."""
    order = db.query(Order).filter(Order.display_id == order_id).first()
    if order is None:
        return ToolResult.fail("track_driver", f"No order found with id '{order_id}'.")
    if order.driver is None:
        return ToolResult.fail("track_driver", f"No driver has been assigned to order '{order_id}' yet.")
    driver = order.driver
    return ToolResult.ok(
        "track_driver",
        {
            "order_id": order_id,
            "driver_name": driver.name,
            "driver_phone": driver.phone,
            "vehicle": driver.vehicle,
            "rating": driver.rating,
            "current_lat": driver.current_lat,
            "current_lng": driver.current_lng,
        },
    )


def delivery_delay(db: Session, order_id: str) -> ToolResult:
    """Check whether an order is delayed and why."""
    order = db.query(Order).filter(Order.display_id == order_id).first()
    if order is None:
        return ToolResult.fail("delivery_delay", f"No order found with id '{order_id}'.")
    return ToolResult.ok(
        "delivery_delay",
        {
            "order_id": order_id,
            "is_delayed": order.is_delayed,
            "delay_reason": order.delay_reason,
            "estimated_delivery_at": order.estimated_delivery_at.isoformat(),
        },
    )


def estimate_delivery(db: Session, order_id: str) -> ToolResult:
    """Return the current delivery ETA for an order."""
    order = db.query(Order).filter(Order.display_id == order_id).first()
    if order is None:
        return ToolResult.fail("estimate_delivery", f"No order found with id '{order_id}'.")
    minutes_remaining = None
    if order.status not in (OrderStatus.DELIVERED, OrderStatus.CANCELLED):
        delta = order.estimated_delivery_at - datetime.utcnow()
        minutes_remaining = max(0, int(delta.total_seconds() // 60))
    return ToolResult.ok(
        "estimate_delivery",
        {
            "order_id": order_id,
            "status": order.status.value,
            "estimated_delivery_at": order.estimated_delivery_at.isoformat(),
            "minutes_remaining": minutes_remaining,
        },
    )


def order_history(db: Session, user_id: str, limit: int = 10) -> ToolResult:
    """Return a user's recent order history."""
    orders = (
        db.query(Order)
        .filter(Order.user_id == user_id)
        .order_by(Order.placed_at.desc())
        .limit(limit)
        .all()
    )
    return ToolResult.ok(
        "order_history",
        {"count": len(orders), "orders": [_order_to_dict(o) for o in orders]},
    )


def report_missing_item(db: Session, order_id: str, item_name: str) -> ToolResult:
    """Log a missing-item report against an order (creates a refund-eligible flag)."""
    order = db.query(Order).filter(Order.display_id == order_id).first()
    if order is None:
        return ToolResult.fail("report_missing_item", f"No order found with id '{order_id}'.")
    items = json.loads(order.items_json)
    item_names = [i["name"].lower() for i in items]
    if item_name.lower() not in item_names:
        return ToolResult.fail(
            "report_missing_item",
            f"'{item_name}' was not found in the items list for order '{order_id}'. Items were: {', '.join(i['name'] for i in items)}.",
        )
    return ToolResult.ok(
        "report_missing_item",
        {"order_id": order_id, "item_name": item_name, "report_status": "logged", "refund_eligible": True},
    )


def food_quality_report(db: Session, order_id: str, description: str) -> ToolResult:
    """Log a food-quality complaint against an order."""
    order = db.query(Order).filter(Order.display_id == order_id).first()
    if order is None:
        return ToolResult.fail("food_quality_report", f"No order found with id '{order_id}'.")
    return ToolResult.ok(
        "food_quality_report",
        {"order_id": order_id, "description": description, "report_status": "logged", "refund_eligible": True},
    )
