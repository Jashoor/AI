"""Restaurant, coupon, and driver lookup tools."""
from __future__ import annotations

from datetime import datetime

from sqlalchemy.orm import Session

from app.db.models import Coupon, Driver, Restaurant
from app.schemas.tool_result import ToolResult


def restaurant_lookup(db: Session, name: str | None = None, restaurant_id: str | None = None) -> ToolResult:
    """Look up a restaurant by id or fuzzy name match."""
    query = db.query(Restaurant)
    if restaurant_id:
        restaurant = query.filter(Restaurant.id == restaurant_id).first()
    elif name:
        restaurant = query.filter(Restaurant.name.ilike(f"%{name}%")).first()
    else:
        return ToolResult.fail("restaurant_lookup", "Either 'name' or 'restaurant_id' must be provided.")

    if restaurant is None:
        return ToolResult.fail("restaurant_lookup", f"No restaurant found matching '{name or restaurant_id}'.")

    return ToolResult.ok(
        "restaurant_lookup",
        {
            "restaurant_id": restaurant.id,
            "name": restaurant.name,
            "cuisine": restaurant.cuisine,
            "city": restaurant.city,
            "address": restaurant.address,
            "rating": restaurant.rating,
            "opens_at": restaurant.opens_at,
            "closes_at": restaurant.closes_at,
            "is_open_now": restaurant.is_open_now,
            "avg_prep_time_minutes": restaurant.avg_prep_time_minutes,
            "phone": restaurant.phone,
        },
    )


def coupon_lookup(db: Session, code: str) -> ToolResult:
    """Look up details of a coupon code."""
    coupon = db.query(Coupon).filter(Coupon.code.ilike(code)).first()
    if coupon is None:
        return ToolResult.fail("coupon_lookup", f"No coupon found with code '{code}'.")
    return ToolResult.ok(
        "coupon_lookup",
        {
            "code": coupon.code,
            "description": coupon.description,
            "discount_percent": coupon.discount_percent,
            "flat_discount": coupon.flat_discount,
            "min_order_value": coupon.min_order_value,
            "valid_from": coupon.valid_from.isoformat(),
            "valid_until": coupon.valid_until.isoformat(),
            "is_active": coupon.is_active,
        },
    )


def validate_coupon(db: Session, code: str, order_value: float) -> ToolResult:
    """Validate whether a coupon can be applied to an order of a given value."""
    coupon = db.query(Coupon).filter(Coupon.code.ilike(code)).first()
    if coupon is None:
        return ToolResult.fail("validate_coupon", f"No coupon found with code '{code}'.")

    now = datetime.utcnow()
    reasons = []
    if not coupon.is_active:
        reasons.append("coupon is currently inactive")
    if now < coupon.valid_from or now > coupon.valid_until:
        reasons.append("coupon is outside its validity window")
    if order_value < coupon.min_order_value:
        reasons.append(f"order value must be at least {coupon.min_order_value}")

    valid = len(reasons) == 0
    return ToolResult.ok(
        "validate_coupon",
        {"code": code, "valid": valid, "reasons": reasons, "min_order_value": coupon.min_order_value},
    )


def driver_lookup(db: Session, driver_id: str) -> ToolResult:
    """Look up a driver's profile by id."""
    driver = db.query(Driver).filter(Driver.id == driver_id).first()
    if driver is None:
        return ToolResult.fail("driver_lookup", f"No driver found with id '{driver_id}'.")
    return ToolResult.ok(
        "driver_lookup",
        {
            "driver_id": driver.id,
            "name": driver.name,
            "phone": driver.phone,
            "vehicle": driver.vehicle,
            "rating": driver.rating,
        },
    )


# Alias matching the spec's requested function name `driver_contact`
driver_contact = driver_lookup
