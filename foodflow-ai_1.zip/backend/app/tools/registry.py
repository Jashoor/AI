"""
Central tool registry.

The Tool Agent never hardcodes which function to call - it looks up the
tool by name here. This keeps the agent layer decoupled from the tool
implementations (Open/Closed Principle: add a new tool without touching
the agent).
"""
from __future__ import annotations

from typing import Any, Callable

from sqlalchemy.orm import Session

from app.schemas.tool_result import ToolResult
from app.tools import catalog_tools, order_tools, refund_payment_tools

ToolFn = Callable[..., ToolResult]

TOOL_REGISTRY: dict[str, ToolFn] = {
    "get_order_status": order_tools.get_order_status,
    "cancel_order": order_tools.cancel_order,
    "track_driver": order_tools.track_driver,
    "delivery_delay": order_tools.delivery_delay,
    "estimate_delivery": order_tools.estimate_delivery,
    "order_history": order_tools.order_history,
    "report_missing_item": order_tools.report_missing_item,
    "food_quality_report": order_tools.food_quality_report,
    "create_refund_request": refund_payment_tools.create_refund_request,
    "refund_status": refund_payment_tools.refund_status,
    "track_refund": refund_payment_tools.track_refund,
    "payment_status": refund_payment_tools.payment_status,
    "payment_lookup": refund_payment_tools.payment_lookup,
    "restaurant_lookup": catalog_tools.restaurant_lookup,
    "coupon_lookup": catalog_tools.coupon_lookup,
    "validate_coupon": catalog_tools.validate_coupon,
    "driver_lookup": catalog_tools.driver_lookup,
    "driver_contact": catalog_tools.driver_contact,
}

# Maps each detected intent to the tool(s) that should be invoked.
INTENT_TOOL_MAP: dict[str, list[str]] = {
    "track_order": ["get_order_status"],
    "cancel_order": ["cancel_order"],
    "refund_status": ["refund_status"],
    "refund_request": ["create_refund_request"],
    "payment_issue": ["payment_status"],
    "missing_item": ["report_missing_item"],
    "late_delivery": ["delivery_delay", "estimate_delivery"],
    "coupon_query": ["coupon_lookup", "validate_coupon"],
    "restaurant_information": ["restaurant_lookup"],
    "order_modification": ["get_order_status"],
    "food_quality_complaint": ["food_quality_report"],
}


def call_tool(tool_name: str, db: Session, **kwargs: Any) -> ToolResult:
    """Dispatch to the named tool with error isolation."""
    fn = TOOL_REGISTRY.get(tool_name)
    if fn is None:
        return ToolResult.fail(tool_name, f"Unknown tool '{tool_name}'.")
    try:
        return fn(db=db, **kwargs)
    except Exception as exc:  # noqa: BLE001 - tool failures must never crash the graph
        return ToolResult.fail(tool_name, f"Tool execution error: {exc}")
