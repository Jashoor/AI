"""Refund and payment tools - all backed by real DB rows."""
from __future__ import annotations

from datetime import datetime

from sqlalchemy.orm import Session

from app.db.models import Order, Payment, Refund, RefundStatus
from app.schemas.tool_result import ToolResult


def create_refund_request(db: Session, order_id: str, reason: str) -> ToolResult:
    """File a new refund request for an order."""
    order = db.query(Order).filter(Order.display_id == order_id).first()
    if order is None:
        return ToolResult.fail("create_refund_request", f"No order found with id '{order_id}'.")

    existing = db.query(Refund).filter(Refund.order_id == order.id).first()
    if existing is not None:
        return ToolResult.fail(
            "create_refund_request",
            f"A refund request already exists for order '{order_id}' with status '{existing.status.value}'.",
        )

    refund = Refund(order_id=order.id, reason=reason, amount=order.total_amount, status=RefundStatus.REQUESTED)
    db.add(refund)
    db.commit()
    db.refresh(refund)
    return ToolResult.ok(
        "create_refund_request",
        {"refund_id": refund.id, "order_id": order_id, "amount": refund.amount, "status": refund.status.value},
    )


def refund_status(db: Session, order_id: str) -> ToolResult:
    """Check the status of an existing refund for an order."""
    order = db.query(Order).filter(Order.display_id == order_id).first()
    if order is None:
        return ToolResult.fail("refund_status", f"No order found with id '{order_id}'.")
    refund = db.query(Refund).filter(Refund.order_id == order.id).first()
    if refund is None:
        return ToolResult.fail("refund_status", f"No refund request exists for order '{order_id}'.")
    return ToolResult.ok(
        "refund_status",
        {
            "order_id": order_id,
            "refund_id": refund.id,
            "status": refund.status.value,
            "amount": refund.amount,
            "reason": refund.reason,
            "requested_at": refund.requested_at.isoformat(),
            "resolved_at": refund.resolved_at.isoformat() if refund.resolved_at else None,
        },
    )


def track_refund(db: Session, refund_id: str) -> ToolResult:
    """Track a refund by its internal refund id."""
    refund = db.query(Refund).filter(Refund.id == refund_id).first()
    if refund is None:
        return ToolResult.fail("track_refund", f"No refund found with id '{refund_id}'.")
    return ToolResult.ok(
        "track_refund",
        {
            "refund_id": refund.id,
            "status": refund.status.value,
            "amount": refund.amount,
            "requested_at": refund.requested_at.isoformat(),
            "resolved_at": refund.resolved_at.isoformat() if refund.resolved_at else None,
        },
    )


def payment_status(db: Session, order_id: str) -> ToolResult:
    """Look up payment status/method for an order."""
    order = db.query(Order).filter(Order.display_id == order_id).first()
    if order is None:
        return ToolResult.fail("payment_status", f"No order found with id '{order_id}'.")
    payment = db.query(Payment).filter(Payment.order_id == order.id).order_by(Payment.created_at.desc()).first()
    if payment is None:
        return ToolResult.fail("payment_status", f"No payment record found for order '{order_id}'.")
    return ToolResult.ok(
        "payment_status",
        {
            "order_id": order_id,
            "method": payment.method,
            "amount": payment.amount,
            "status": payment.status.value,
            "transaction_ref": payment.transaction_ref,
        },
    )


# Alias matching the spec's requested function name `payment_lookup`
payment_lookup = payment_status
