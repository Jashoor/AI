"""
LLM Provider Strategy.

Implements a Strategy pattern so agents never talk to a specific vendor SDK
directly. Provider precedence (all free-tier / $0 cost):

    1. Groq API (free tier)      - fast hosted inference
    2. Ollama (local)             - $0, runs on developer machine, no rate limit
    3. HuggingFace Inference API  - optional free-tier fallback

If the primary provider fails (timeout, rate limit, auth error), the client
automatically falls back to the next provider in the chain. This is fully
config-driven (see app/core/config.py) - swapping providers/models never
requires touching agent code.
"""
from __future__ import annotations

import abc
import asyncio
import json
import logging
import re
from dataclasses import dataclass
from typing import Any, Optional

import httpx

from app.core.config import settings

logger = logging.getLogger("foodflow.llm")


@dataclass
class LLMResponse:
    content: str
    provider: str
    model: str
    raw: Optional[dict[str, Any]] = None


class LLMProviderError(Exception):
    """Raised when a provider fails after retries; triggers fallback."""


class BaseLLMClient(abc.ABC):
    name: str = "base"

    def is_configured(self) -> bool:
        """Cheap pre-check so the router can skip pointless retry/backoff cycles."""
        return True

    @abc.abstractmethod
    async def chat(
        self,
        messages: list[dict[str, str]],
        temperature: float = 0.3,
        max_tokens: int = 700,
        json_mode: bool = False,
    ) -> LLMResponse:
        ...


class GroqClient(BaseLLMClient):
    """Groq free-tier hosted inference. Supports Llama 3.x, Qwen, Gemma, DeepSeek, Mistral."""

    name = "groq"
    BASE_URL = "https://api.groq.com/openai/v1/chat/completions"

    def __init__(self) -> None:
        self.api_key = settings.GROQ_API_KEY
        self.model = settings.GROQ_MODEL

    def is_configured(self) -> bool:
        return bool(self.api_key)

    async def chat(self, messages, temperature=0.3, max_tokens=700, json_mode=False) -> LLMResponse:
        if not self.api_key:
            raise LLMProviderError("GROQ_API_KEY not configured")

        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if json_mode:
            payload["response_format"] = {"type": "json_object"}

        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}

        async with httpx.AsyncClient(timeout=settings.LLM_TIMEOUT_SECONDS) as client:
            resp = await client.post(self.BASE_URL, json=payload, headers=headers)
            if resp.status_code != 200:
                raise LLMProviderError(f"Groq error {resp.status_code}: {resp.text[:300]}")
            data = resp.json()
            content = data["choices"][0]["message"]["content"]
            return LLMResponse(content=content, provider=self.name, model=self.model, raw=data)


class OllamaClient(BaseLLMClient):
    """Local Ollama inference - zero API cost, requires `ollama serve` running locally."""

    name = "ollama"

    def __init__(self) -> None:
        self.base_url = settings.OLLAMA_BASE_URL
        self.model = settings.OLLAMA_MODEL

    async def chat(self, messages, temperature=0.3, max_tokens=700, json_mode=False) -> LLMResponse:
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "options": {"temperature": temperature, "num_predict": max_tokens},
        }
        if json_mode:
            payload["format"] = "json"

        try:
            async with httpx.AsyncClient(timeout=settings.LLM_TIMEOUT_SECONDS) as client:
                resp = await client.post(f"{self.base_url}/api/chat", json=payload)
                if resp.status_code != 200:
                    raise LLMProviderError(f"Ollama error {resp.status_code}: {resp.text[:300]}")
                data = resp.json()
                content = data.get("message", {}).get("content", "")
                return LLMResponse(content=content, provider=self.name, model=self.model, raw=data)
        except httpx.ConnectError as exc:
            raise LLMProviderError(f"Ollama not reachable at {self.base_url} (is `ollama serve` running?)") from exc


class HuggingFaceClient(BaseLLMClient):
    """Optional HuggingFace Inference API fallback (free tier, rate-limited)."""

    name = "huggingface"
    BASE_URL = "https://api-inference.huggingface.co/models"

    def __init__(self) -> None:
        self.api_key = settings.HF_API_KEY
        self.model = settings.HF_MODEL

    def is_configured(self) -> bool:
        return bool(self.api_key)

    async def chat(self, messages, temperature=0.3, max_tokens=700, json_mode=False) -> LLMResponse:
        if not self.api_key:
            raise LLMProviderError("HF_API_KEY not configured")

        prompt = "\n".join(f"{m['role']}: {m['content']}" for m in messages)
        headers = {"Authorization": f"Bearer {self.api_key}"}
        payload = {
            "inputs": prompt,
            "parameters": {"temperature": temperature, "max_new_tokens": max_tokens, "return_full_text": False},
        }

        async with httpx.AsyncClient(timeout=settings.LLM_TIMEOUT_SECONDS) as client:
            resp = await client.post(f"{self.BASE_URL}/{self.model}", json=payload, headers=headers)
            if resp.status_code != 200:
                raise LLMProviderError(f"HF error {resp.status_code}: {resp.text[:300]}")
            data = resp.json()
            content = data[0]["generated_text"] if isinstance(data, list) else str(data)
            return LLMResponse(content=content, provider=self.name, model=self.model, raw=None)


class MockClient(BaseLLMClient):
    """
    Zero-dependency, always-available offline provider. Never raises.

    This exists so the app is fully usable the moment it's unzipped, before
    any API key is configured: it does keyword-based intent classification
    and templated, data-grounded response phrasing (it reads the real
    TOOL_RESULTS / RAG_CONTEXT the agents already retrieved - it never
    invents facts, it just formats them without calling a hosted LLM).

    It is always tried last in the chain, after the user's configured
    primary/fallback providers, so once a real GROQ_API_KEY (or a running
    Ollama) is configured, real LLM-generated phrasing takes over
    automatically and this is never invoked.
    """

    name = "mock"

    _INTENT_KEYWORDS: list[tuple[str, list[str]]] = [
        ("cancel_order", ["cancel"]),
        ("refund_status", ["refund status", "where is my refund", "status of my refund", "when will i get my refund", "when will my refund"]),
        ("refund_request", ["refund", "money back", "reimburse", "want my money"]),
        ("payment_issue", ["charged twice", "double charged", "payment", "deduct", "debited", "charge"]),
        ("missing_item", ["missing", "didn't get", "did not get", "forgot", "left out", "wasn't in my order"]),
        ("food_quality_complaint", ["cold", "bad taste", "quality", "spoiled", "stale", "awful", "tasted"]),
        ("late_delivery", ["late", "delay", "taking long", "taking forever", "not arrived", "hasn't arrived"]),
        ("coupon_query", ["coupon", "promo", "discount code", "offer code", "valid"]),
        ("restaurant_information", ["restaurant", "opening hours", "timings", "open now", "is it open"]),
        ("order_modification", ["change my order", "modify order", "update address", "change address"]),
        ("track_order", ["track", "where is my order", "order status", "status of my order", "where's my order"]),
        ("human_support", ["human", "real person", "representative", "talk to someone", "human support"]),
        ("goodbye", ["bye", "goodbye", "see you", "that's all"]),
        ("greeting", ["hi", "hello", "hey", "good morning", "good afternoon"]),
        ("faq", ["policy", "terms", "how do refunds work", "how does", "what is your"]),
    ]

    _ORDER_ID_RE = re.compile(r"\bFF-?(\d{4,6})\b", re.IGNORECASE)
    _COUPON_RE = re.compile(r"\b((?:FOOD|SAVE|MEAL|TASTY|CRAVE|YUM|BITE|FEAST)\d{2,4}[A-Z]?)\b", re.IGNORECASE)

    def _classify(self, text: str) -> dict[str, Any]:
        lowered = text.lower()
        order_match = self._ORDER_ID_RE.search(text)
        coupon_match = self._COUPON_RE.search(text)

        for intent, keywords in self._INTENT_KEYWORDS:
            if any(kw in lowered for kw in keywords):
                return {
                    "intent": intent,
                    "confidence": 0.75,
                    "order_id": f"FF-{order_match.group(1)}" if order_match else None,
                    "coupon_code": coupon_match.group(1).upper() if coupon_match else None,
                    "restaurant_name": None,
                    "reasoning": "offline keyword-based classification (no LLM provider configured)",
                }

        return {
            "intent": "faq" if "?" in text else "unknown_intent",
            "confidence": 0.6 if "?" in text else 0.3,
            "order_id": f"FF-{order_match.group(1)}" if order_match else None,
            "coupon_code": coupon_match.group(1).upper() if coupon_match else None,
            "restaurant_name": None,
            "reasoning": "offline keyword-based classification (no LLM provider configured)",
        }

    @staticmethod
    def _extract_section(prompt: str, label: str, next_labels: list[str]) -> str:
        start = prompt.find(f"{label}:")
        if start == -1:
            return ""
        start += len(label) + 1
        end = len(prompt)
        for nl in next_labels:
            idx = prompt.find(f"{nl}:", start)
            if idx != -1:
                end = min(end, idx)
        return prompt[start:end].strip()

    def _generate_reply(self, prompt: str) -> str:
        tool_text = self._extract_section(prompt, "TOOL_RESULTS", ["RAG_CONTEXT", "MEMORY"])
        rag_text = self._extract_section(prompt, "RAG_CONTEXT", ["MEMORY"])

        # Parse each `[tool_name] SUCCESS: {...json...}` / `FAILED: message` line.
        for line in tool_text.splitlines():
            line = line.strip()
            if not line.startswith("["):
                continue
            name_end = line.find("]")
            tool_name = line[1:name_end]
            rest = line[name_end + 1 :].strip()

            if rest.startswith("FAILED:"):
                return f"I wasn't able to complete that: {rest.removeprefix('FAILED:').strip()}"

            if rest.startswith("SUCCESS:"):
                try:
                    data = json.loads(rest.removeprefix("SUCCESS:").strip())
                except json.JSONDecodeError:
                    data = {}

                if tool_name == "get_order_status":
                    parts = [f"Order {data.get('order_id')} is currently **{str(data.get('status')).replace('_', ' ')}**."]
                    if data.get("restaurant_name"):
                        parts.append(f"It's from {data['restaurant_name']}.")
                    if data.get("is_delayed") and data.get("delay_reason"):
                        parts.append(f"It's running late due to: {data['delay_reason']}.")
                    if data.get("driver_name"):
                        parts.append(f"Your delivery partner is {data['driver_name']}.")
                    return " ".join(parts)

                if tool_name == "cancel_order":
                    return f"Order {data.get('order_id')} has been cancelled successfully."

                if tool_name in ("refund_status", "track_refund"):
                    return (
                        f"Your refund of ₹{data.get('amount')} for order {data.get('order_id', '')} "
                        f"is currently **{str(data.get('status')).replace('_', ' ')}**."
                    )

                if tool_name == "create_refund_request":
                    return f"I've filed a refund request for order {data.get('order_id')} (amount ₹{data.get('amount')}). You'll see the status update once it's reviewed."

                if tool_name in ("payment_status", "payment_lookup"):
                    return f"The payment for order {data.get('order_id')} via {data.get('method')} shows status **{data.get('status')}**."

                if tool_name in ("coupon_lookup", "validate_coupon"):
                    if "valid" in data:
                        if data["valid"]:
                            return f"Coupon {data.get('code')} is valid and can be applied."
                        return f"Coupon {data.get('code')} can't be applied right now: {', '.join(data.get('reasons', []))}."
                    return f"Coupon {data.get('code')}: {data.get('description')}."

                if tool_name == "restaurant_lookup":
                    open_state = "open now" if data.get("is_open_now") else "closed right now"
                    return f"{data.get('name')} ({data.get('cuisine')}) is {open_state}, hours {data.get('opens_at')}-{data.get('closes_at')}."

                if tool_name in ("delivery_delay", "estimate_delivery"):
                    if data.get("minutes_remaining") is not None:
                        return f"Your order should arrive in about {data['minutes_remaining']} minutes."
                    return f"Order status: {data.get('status', 'unknown')}."

                if tool_name in ("report_missing_item", "food_quality_report"):
                    return "Thanks for letting us know — I've logged this and it's eligible for a refund review."

        # No tool results - fall back to RAG context if present.
        if rag_text and rag_text != "NO_RELEVANT_CONTEXT_FOUND" and "[Source" in rag_text:
            first_source = rag_text.split("\n\n")[0]
            text_only = first_source.split("]", 1)[-1].strip()
            return text_only[:400]

        return (
            "I don't have enough grounded information to answer that confidently yet. "
            "I've connected you with a human support executive who can help further."
        )

    async def chat(self, messages, temperature=0.3, max_tokens=700, json_mode=False) -> LLMResponse:
        last_user_message = next((m["content"] for m in reversed(messages) if m["role"] == "user"), "")

        if json_mode:
            content = json.dumps(self._classify(last_user_message))
        else:
            content = self._generate_reply(last_user_message)

        return LLMResponse(content=content, provider=self.name, model="offline-rules-v1", raw=None)


_PROVIDER_REGISTRY: dict[str, type[BaseLLMClient]] = {
    "groq": GroqClient,
    "ollama": OllamaClient,
    "huggingface": HuggingFaceClient,
}


class LLMRouter:
    """
    Resolves the configured primary provider, falls back automatically on
    failure, and retries transient errors with exponential backoff.

    A `MockClient` is always attached as the final safety net beyond the
    user-configured fallback, so `chat()`/`chat_json()` never raises and the
    app always produces a sensible, data-grounded answer - even with zero
    API keys configured.
    """

    def __init__(self) -> None:
        self.primary = _PROVIDER_REGISTRY[settings.LLM_PROVIDER]()
        self.fallback: Optional[BaseLLMClient] = (
            _PROVIDER_REGISTRY[settings.LLM_FALLBACK_PROVIDER]()
            if settings.LLM_FALLBACK_PROVIDER != "none"
            else None
        )
        self.offline = MockClient()
        self._warned_offline = False

    async def chat(
        self,
        messages: list[dict[str, str]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        json_mode: bool = False,
    ) -> LLMResponse:
        temperature = settings.LLM_TEMPERATURE if temperature is None else temperature
        max_tokens = settings.LLM_MAX_TOKENS if max_tokens is None else max_tokens

        last_error: Optional[Exception] = None
        if self.primary.is_configured():
            for attempt in range(settings.LLM_MAX_RETRIES + 1):
                try:
                    return await self.primary.chat(messages, temperature, max_tokens, json_mode)
                except LLMProviderError as exc:
                    last_error = exc
                    logger.warning(f"Primary provider {self.primary.name} failed (attempt {attempt + 1}): {exc}")
                    await asyncio.sleep(0.5 * (attempt + 1))
        else:
            last_error = LLMProviderError(f"{self.primary.name} is not configured")
            logger.info(f"Skipping primary provider {self.primary.name} - not configured")

        if self.fallback is not None:
            if self.fallback.is_configured():
                try:
                    logger.warning(f"Falling back to {self.fallback.name}")
                    return await self.fallback.chat(messages, temperature, max_tokens, json_mode)
                except LLMProviderError as exc:
                    last_error = exc
                    logger.warning(f"Fallback provider {self.fallback.name} also failed: {exc}")
            else:
                logger.info(f"Skipping fallback provider {self.fallback.name} - not configured")

        if not self._warned_offline:
            logger.warning(
                "No configured LLM provider is reachable "
                f"(last error: {last_error}). Falling back to the offline rule-based "
                "provider - responses will be templated rather than LLM-generated until "
                "a valid GROQ_API_KEY or a running Ollama server is configured."
            )
            self._warned_offline = True

        return await self.offline.chat(messages, temperature, max_tokens, json_mode)

    async def chat_json(self, messages: list[dict[str, str]], **kwargs) -> dict[str, Any]:
        """Convenience wrapper for structured-output prompts (intent detection etc)."""
        response = await self.chat(messages, json_mode=True, **kwargs)
        try:
            return json.loads(response.content)
        except json.JSONDecodeError:
            # Some free-tier models ignore json_mode; extract the first {...} block.
            start, end = response.content.find("{"), response.content.rfind("}")
            if start != -1 and end != -1:
                return json.loads(response.content[start : end + 1])
            # Last resort: never crash the graph over a malformed JSON reply.
            return {"intent": "unknown_intent", "confidence": 0.0, "order_id": None, "coupon_code": None, "restaurant_name": None}


llm_router = LLMRouter()
