"""Structured result envelope every tool function returns.

Agents never format free text from tools - they only ever forward this
structured data to the Response Agent, which is the sole place natural
language is generated. This is what prevents hallucinated tool outputs.
"""
from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel


class ToolResult(BaseModel):
    success: bool
    tool_name: str
    data: Optional[dict[str, Any]] = None
    error: Optional[str] = None

    @classmethod
    def ok(cls, tool_name: str, data: dict[str, Any]) -> "ToolResult":
        return cls(success=True, tool_name=tool_name, data=data, error=None)

    @classmethod
    def fail(cls, tool_name: str, error: str) -> "ToolResult":
        return cls(success=False, tool_name=tool_name, data=None, error=error)
