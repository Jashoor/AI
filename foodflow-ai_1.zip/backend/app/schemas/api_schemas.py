"""Pydantic request/response models for all REST endpoints."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, EmailStr, Field


# --- Auth ---
class SignupRequest(BaseModel):
    name: str
    email: EmailStr
    password: str


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: str
    name: str
    is_guest: bool = False


# --- Chat ---
class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=2000)
    conversation_id: Optional[str] = None


class ChatResponse(BaseModel):
    conversation_id: str
    reply: str
    intent: str
    confidence: float
    escalated: bool
    tool_calls: list[str] = []
    sources_used: bool = False


# --- Orders ---
class OrderResponse(BaseModel):
    order_id: str
    status: str
    items: list[dict[str, Any]]
    total_amount: float
    placed_at: str
    estimated_delivery_at: str
    delivered_at: Optional[str] = None
    delivery_address: str
    is_delayed: bool
    delay_reason: Optional[str] = None
    restaurant_name: Optional[str] = None
    driver_name: Optional[str] = None


class CancelOrderRequest(BaseModel):
    order_id: str


class RefundRequestBody(BaseModel):
    order_id: str
    reason: str


class MissingItemRequest(BaseModel):
    order_id: str
    item_name: str


# --- Feedback ---
class FeedbackRequest(BaseModel):
    conversation_id: str
    rating: int = Field(..., ge=1, le=5)
    comment: Optional[str] = None


# --- History ---
class ConversationSummary(BaseModel):
    conversation_id: str
    title: str
    created_at: datetime
    message_count: int
