from app.rag.chunker import chunk_document, split_sentences
from app.rag.loader import RawDocument


def test_split_sentences_basic():
    text = "This is one. This is two! Is this three?"
    sentences = split_sentences(text)
    assert len(sentences) == 3


def test_chunk_document_respects_size_roughly():
    long_text = " ".join([f"Sentence number {i} about food delivery policy." for i in range(50)])
    doc = RawDocument(doc_id="doc1", source="test", category="policy", text=long_text)
    chunks = chunk_document(doc, chunk_size=200, overlap=20)
    assert len(chunks) > 1
    for c in chunks:
        assert len(c.text) <= 260  # allow slack for overlap + last sentence


def test_chunk_document_single_short_doc():
    doc = RawDocument(doc_id="doc2", source="test", category="faq", text="Short answer here.")
    chunks = chunk_document(doc)
    assert len(chunks) == 1
    assert chunks[0].text == "Short answer here."
