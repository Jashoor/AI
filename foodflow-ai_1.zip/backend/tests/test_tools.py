"""Unit tests for the tool layer, run against a temporary in-memory SQLite DB."""
from __future__ import annotations

import json
from datetime import datetime, timedelta

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.db.models import Base, Order, OrderStatus, Restaurant, User
from app.tools import order_tools, refund_payment_tools


@pytest.fixture()
def db_session():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    session = Session()

    user = User(name="Test User", email="test@example.com", is_guest=False)
    restaurant = Restaurant(
        name="Test Kitchen", cuisine="Test", city="Chennai", address="1 Test St",
        rating=4.5, opens_at="09:00", closes_at="23:00", is_open_now=True,
        avg_prep_time_minutes=25, phone="+911234567890",
    )
    session.add_all([user, restaurant])
    session.commit()

    order = Order(
        display_id="FF-99999",
        user_id=user.id,
        restaurant_id=restaurant.id,
        items_json=json.dumps([{"name": "Veg Burger", "qty": 1, "price": 149.0}]),
        total_amount=149.0,
        status=OrderStatus.PREPARING,
        placed_at=datetime.utcnow(),
        estimated_delivery_at=datetime.utcnow() + timedelta(minutes=30),
        delivery_address="Test Address",
    )
    session.add(order)
    session.commit()

    yield session, user, order
    session.close()


def test_get_order_status_success(db_session):
    session, user, order = db_session
    result = order_tools.get_order_status(session, "FF-99999", user.id)
    assert result.success is True
    assert result.data["order_id"] == "FF-99999"
    assert result.data["status"] == "preparing"


def test_get_order_status_not_found(db_session):
    session, user, _ = db_session
    result = order_tools.get_order_status(session, "FF-00000", user.id)
    assert result.success is False
    assert "No order found" in result.error


def test_cancel_order_success(db_session):
    session, user, order = db_session
    result = order_tools.cancel_order(session, "FF-99999", user.id)
    assert result.success is True
    assert result.data["status"] == "cancelled"


def test_cancel_order_wrong_owner(db_session):
    session, _, order = db_session
    result = order_tools.cancel_order(session, "FF-99999", "someone-else-id")
    assert result.success is False


def test_create_and_check_refund(db_session):
    session, user, order = db_session
    create_result = refund_payment_tools.create_refund_request(session, "FF-99999", "Food arrived cold")
    assert create_result.success is True

    status_result = refund_payment_tools.refund_status(session, "FF-99999")
    assert status_result.success is True
    assert status_result.data["status"] == "requested"

    # A second refund request for the same order should fail
    duplicate = refund_payment_tools.create_refund_request(session, "FF-99999", "Trying again")
    assert duplicate.success is False


def test_report_missing_item_validates_item_name(db_session):
    session, user, order = db_session
    ok = order_tools.report_missing_item(session, "FF-99999", "Veg Burger")
    assert ok.success is True

    bad = order_tools.report_missing_item(session, "FF-99999", "Pizza")
    assert bad.success is False
