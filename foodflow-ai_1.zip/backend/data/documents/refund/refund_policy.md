# Refund Policy

FoodFlow issues refunds when an order arrives with a missing item, an incorrect item,
a verified food quality issue reported within 24 hours of delivery, or when delivery
is delayed more than 60 minutes past the estimated delivery time.

Refund requests must be filed through the app or chat support within 24 hours of the
order being marked delivered. Requests filed after this window are reviewed on a
case-by-case basis and are not guaranteed approval.

Once approved, refunds are credited to the original payment method within 5-7 business
days. UPI-based refunds are typically faster and complete within 2-3 business days.
Cash on Delivery refunds are issued as FoodFlow wallet credit, redeemable on future orders.

A refund can be partial (covering only the affected item) or full (covering the entire
order total), depending on the nature of the issue confirmed by support.
