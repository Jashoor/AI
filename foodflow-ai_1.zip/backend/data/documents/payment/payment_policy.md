# Payment Policy

FoodFlow supports UPI, credit and debit cards, digital wallets, net banking, and Cash
on Delivery (in eligible service areas below a city-specific order value threshold).

If a payment fails but the amount was debited from the customer's account, the amount
is automatically reversed to the source account within 5-7 business days. The order is
never placed unless payment is confirmed as successful.

Duplicate charges - where a customer is billed twice for the same order due to a
network retry - are detected and auto-reversed within 3-5 business days; if not resolved
automatically, this should be escalated to human support with the transaction reference.
