# Coupon & Offer Policy

Only one coupon code may be applied per order. Coupons cannot be stacked with other
active promotional offers unless the offer explicitly states it is stackable.

Each coupon has a minimum order value and a validity window; both are enforced at
checkout and the coupon is rejected automatically if either condition is not met.

Coupons expire strictly at the stated date and time. An expired coupon cannot be
manually re-applied by support as an exception, in order to keep offer terms consistent
for all customers.

New-user welcome coupons are limited to one redemption per verified account/phone
number to prevent abuse.
