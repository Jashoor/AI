# Cancellation Policy

Orders can be cancelled free of charge within 2 minutes of being placed, as long as the
restaurant has not yet confirmed preparation. After the restaurant confirms the order,
cancellation may incur a partial charge to cover ingredients already prepared.

If a restaurant cancels an order - due to an item being unavailable or the restaurant
closing unexpectedly - the customer automatically receives a full refund with no
cancellation fee charged.

Orders already marked "out for delivery" cannot be cancelled through self-service and
require a refund request instead, evaluated per the Refund Policy.
