# Terms of Use & Privacy Summary

Each FoodFlow account is intended for individual use. Sharing an account specifically
to repeatedly exploit new-user promotional offers may result in coupon eligibility
being revoked for that account.

Order history, delivery addresses, and payment metadata are used solely to fulfil
orders and provide customer support, and are never sold to third-party advertisers.

Customers may request account deletion from Settings; this is irreversible and removes
stored order history after a 30-day grace period, after which it cannot be recovered.
