# Delivery Rules

Standard delivery windows are 30-45 minutes from order confirmation, depending on the
distance between the restaurant and delivery address, and the restaurant's current
preparation load.

If an order is delayed more than 20 minutes beyond its estimated delivery time, the
customer automatically becomes eligible for delivery credits applied to their account,
visible under the order's details screen.

Customers may select contactless delivery at checkout. In this mode, the delivery
partner leaves the order at the specified location and sends an in-app notification
with a photo confirmation instead of requiring a hand-off.

Delivery partners are assigned dynamically based on proximity and current load; a
partner may be reassigned mid-delivery in rare cases of vehicle breakdown, which is
logged as a delay reason on the order.
