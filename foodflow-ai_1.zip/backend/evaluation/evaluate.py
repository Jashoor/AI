"""
Evaluation harness for FoodFlow AI.

Computes:
  - Intent classification accuracy against a small labeled test set
  - Tool success rate over a batch of tool calls
  - Groundedness rate of generated responses (via the Safety Agent's
    post-check, reused here as an evaluation metric)

Run:
    python -m evaluation.evaluate
Requires the backend's virtualenv (LLM provider credentials configured).
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path

from app.agents.intent_agent import detect_intent
from app.agents.safety_agent import postcheck_response

LABELED_INTENTS = [
    {"message": "Where is my order FF-10234?", "expected_intent": "track_order"},
    {"message": "I want to cancel my order", "expected_intent": "cancel_order"},
    {"message": "When will I get my refund?", "expected_intent": "refund_status"},
    {"message": "My food arrived cold and tasted awful", "expected_intent": "food_quality_complaint"},
    {"message": "Is coupon FOOD25A still valid?", "expected_intent": "coupon_query"},
    {"message": "Hi there!", "expected_intent": "greeting"},
    {"message": "Thanks, bye!", "expected_intent": "goodbye"},
    {"message": "My payment got deducted twice", "expected_intent": "payment_issue"},
    {"message": "A drink was missing from my order", "expected_intent": "missing_item"},
    {"message": "My order is taking forever", "expected_intent": "late_delivery"},
    {"message": "What are this restaurant's opening hours?", "expected_intent": "restaurant_information"},
    {"message": "I need to speak to a human agent", "expected_intent": "human_support"},
]

GROUNDEDNESS_CASES = [
    {
        "draft": "Your order FF-10234 is currently out for delivery.",
        "grounding": ['{"order_id": "FF-10234", "status": "out_for_delivery"}'],
        "expected_grounded": True,
    },
    {
        "draft": "Your refund of ₹5000 has already been processed.",
        "grounding": ['{"order_id": "FF-1", "amount": 250.0, "status": "requested"}'],
        "expected_grounded": False,
    },
]


async def evaluate_intent_accuracy() -> dict:
    correct = 0
    results = []
    for case in LABELED_INTENTS:
        prediction = await detect_intent(case["message"])
        is_correct = prediction["intent"] == case["expected_intent"]
        correct += int(is_correct)
        results.append(
            {
                "message": case["message"],
                "expected": case["expected_intent"],
                "predicted": prediction["intent"],
                "confidence": prediction["confidence"],
                "correct": is_correct,
            }
        )
    accuracy = correct / len(LABELED_INTENTS)
    return {"metric": "intent_accuracy", "value": accuracy, "n": len(LABELED_INTENTS), "details": results}


def evaluate_groundedness() -> dict:
    correct = 0
    results = []
    for case in GROUNDEDNESS_CASES:
        result = postcheck_response(case["draft"], case["grounding"])
        is_correct = result.passed == case["expected_grounded"]
        correct += int(is_correct)
        results.append({"draft": case["draft"], "passed": result.passed, "expected": case["expected_grounded"], "correct": is_correct})
    return {"metric": "groundedness_check_accuracy", "value": correct / len(GROUNDEDNESS_CASES), "n": len(GROUNDEDNESS_CASES), "details": results}


async def run() -> None:
    print("Running FoodFlow AI evaluation suite...\n")

    intent_result = await evaluate_intent_accuracy()
    print(f"Intent Accuracy: {intent_result['value']:.1%} ({sum(d['correct'] for d in intent_result['details'])}/{intent_result['n']})")

    groundedness_result = evaluate_groundedness()
    print(f"Groundedness Check Accuracy: {groundedness_result['value']:.1%}")

    output = {"intent_accuracy": intent_result, "groundedness": groundedness_result}
    out_path = Path(__file__).parent / "results.json"
    out_path.write_text(json.dumps(output, indent=2))
    print(f"\nFull results written to {out_path}")


if __name__ == "__main__":
    asyncio.run(run())
