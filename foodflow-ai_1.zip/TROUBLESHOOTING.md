# Troubleshooting

Known issues encountered while setting this project up, and how they're now
prevented or fixed. If you hit an error not listed here, check the exact
traceback for the failing package/line and search this file first.

---

### 1. `sqlite3.IntegrityError: UNIQUE constraint failed: coupons.code`

**Cause:** an earlier version of `generate_mock_data.py` built coupon codes
from a small random combination space (~2,340 possibilities) while
generating 200 coupons, making a collision almost certain.

**Fixed in this version:** coupon codes now embed the loop index directly
(`FOOD0000`, `SAVE0001`, ...), which is unique by construction.

**If you still hit this:** delete the partially-written database and
re-run the generator:
```bash
rm backend/data/foodflow.db     # Windows: del backend\data\foodflow.db
python -m data.generate_mock_data
```

---

### 2. `ImportError: email-validator is not installed`

**Cause:** Pydantic's `EmailStr` type (used in `SignupRequest`/`LoginRequest`)
requires the optional `email-validator` package, which wasn't listed in
`requirements.txt`.

**Fixed in this version:** `email-validator==2.2.0` is now in
`backend/requirements.txt`.

**If you still hit this:** `pip install email-validator`

---

### 3. `AttributeError: module 'bcrypt' has no attribute '__about__'` (signup/login fails)

**Cause:** `passlib==1.7.4` reads `bcrypt.__about__.__version__` to detect the
bcrypt version. That attribute was removed in `bcrypt>=4.1`, so any
environment with a newer bcrypt installed breaks password hashing the first
time it runs (signup, login).

**Fixed in this version:** `passlib`/`bcrypt` have been removed entirely.
Password hashing now uses Python's built-in `hashlib.pbkdf2_hmac`
(see `app/core/security.py`) - a stdlib-only implementation with zero
third-party dependency risk, so this class of error can't happen again
regardless of what else is installed in your environment.

**If you're on an older copy of this project still using passlib:**
either upgrade to this version, or as a stopgap: `pip install "bcrypt==4.0.1"`

---

### 8. Guest mode gives the same reply to every question

**Cause:** intent detection and response phrasing both call the configured
LLM provider. If no `GROQ_API_KEY` is set (and no Ollama server is running
locally), every LLM call used to fail, intent detection fell back to
`unknown_intent` at 0% confidence every time, and the graph routed straight
to the Escalation Agent - which always returns the same fixed handoff
message, regardless of what was asked.

**Fixed in this version:** a zero-dependency offline fallback
(`MockClient` in `app/llm/provider.py`) is now always attached as the final
step in the provider chain. It does keyword-based intent classification and
templated responses built from the *real* tool/RAG data the agents already
retrieved - so the app gives correct, varied, data-grounded answers to
different questions even with zero API keys configured. Add a free Groq key
(or run Ollama) at any time to upgrade to full LLM-generated phrasing - no
code changes needed, it switches over automatically.

**How to tell which mode you're in:** check the backend's terminal log. If
you see `Falling back to the offline rule-based provider`, no LLM is
configured/reachable and you're getting templated answers. Add
`GROQ_API_KEY` in `backend/.env` to get real LLM responses.

---

### 9. A bug anywhere in the agent graph used to surface as a raw 500 error

**Fixed in this version:** `POST /api/v1/chat` now wraps the LangGraph
invocation in a try/except. Any unexpected failure (a malformed tool
response, an LLM outage mid-conversation, etc.) is logged server-side with
a full traceback and returns a clean, user-facing message instead of an
unhandled 500. Similarly, the RAG agent now catches *any* exception (not
just "index not built yet") so a missing `sentence-transformers`/`faiss`
install degrades to "no grounding found" instead of crashing the request.

---

### 4. `ResolutionImpossible` / `AttributeError: module 'langchain' has no attribute 'debug'`

**Cause:** LangGraph needs `langchain-core`, and `langchain` (the umbrella
package) needs a compatible `langchain-core` version too. Pinning an exact
`langchain-core` version (e.g. `0.3.9`) independently of `langchain`'s own
requirement range causes either an install conflict, or - if something else
in your Python environment already has an incompatible `langchain`/
`langchain-core` pair installed - a runtime `AttributeError` deep inside
LangGraph's callback manager.

**Fixed in this version:** `requirements.txt` now pins `langchain==0.3.7`
and leaves `langchain-core` as a floor (`>=0.3.15,<0.4`) instead of an exact
version, so pip resolves a mutually compatible pair automatically.

**If you still hit this in an existing/shared environment:**
```bash
pip install -U langchain==0.3.7 langchain-core
```
(note: no version pin after `langchain-core` - let pip choose)

**Best long-term fix:** don't install this project into a Python
environment that's already used for other ML/LLM projects (e.g. a shared
`conda` env like `gpu_env`). Use a project-local virtual environment - see
"Recommended setup" below.

---

### 5. Frontend: `The following dependencies are imported but could not be resolved: @/App`

**Cause:** the `@/` import alias was declared in `tsconfig.json` (for
TypeScript's type-checker) but not in `vite.config.ts` (for Vite's actual
bundler at runtime) - these are two separate systems and both need the
alias configured.

**Fixed in this version:** `vite.config.ts` now includes:
```ts
resolve: {
  alias: { "@": path.resolve(__dirname, "./src") },
},
```

---

### 6. Frontend: `AggregateError [ECONNREFUSED]` on `/api/...` requests

**Cause:** the backend isn't running, or is running on a different port than
the one configured in `vite.config.ts`'s proxy `target`.

**Fix:** make sure `uvicorn` is running on port **8000** (the project's
consistent default across `README.md`, `vite.config.ts`, and
`docker-compose.yml`). If you deliberately run the backend on a different
port, update `frontend/vite.config.ts`'s `proxy.target` to match.

---

### 7. `Form data requires "python-multipart" to be installed` (on `/upload-documents`)

**Cause:** FastAPI's `UploadFile` needs `python-multipart` at runtime; it
wasn't listed as a dependency.

**Fixed in this version:** `python-multipart==0.0.9` is now in
`requirements.txt`.

---

## Recommended setup (avoids most of the above)

Use a **project-local virtual environment**, not a shared/global one, so
this project's pinned versions can never collide with another project's
packages:

```bash
cd backend
python -m venv .venv

# Activate it:
source .venv/bin/activate        # macOS/Linux
.venv\Scripts\Activate.ps1       # Windows PowerShell

pip install -r requirements.txt
cp .env.example .env             # then add your free Groq key

python -m data.generate_mock_data
python -m app.rag.build_index

uvicorn app.main:app --reload --port 8000
```

Confirm your interpreter in VS Code: `Ctrl+Shift+P` → `Python: Select
Interpreter` → choose the one inside `backend/.venv`.
