"""
LLM Provider Strategy.

Implements a Strategy pattern so agents never talk to a specific vendor SDK
directly. Provider precedence (all free-tier / $0 cost):

    1. Groq API (free tier)      - fast hosted inference
    2. Ollama (local)             - $0, runs on developer machine, no rate limit
    3. HuggingFace Inference API  - optional free-tier fallback

If the primary provider fails (timeout, rate limit, auth error), the client
automatically falls back to the next provider in the chain. This is fully
config-driven (see app/core/config.py) - swapping providers/models never
requires touching agent code.
"""
from __future__ import annotations

import abc
import asyncio
import json
import logging
from dataclasses import dataclass
from typing import Any, Optional

import httpx

from app.core.config import settings

logger = logging.getLogger("foodflow.llm")


@dataclass
class LLMResponse:
    content: str
    provider: str
    model: str
    raw: Optional[dict[str, Any]] = None


class LLMProviderError(Exception):
    """Raised when a provider fails after retries; triggers fallback."""


class BaseLLMClient(abc.ABC):
    name: str = "base"

    @abc.abstractmethod
    async def chat(
        self,
        messages: list[dict[str, str]],
        temperature: float = 0.3,
        max_tokens: int = 700,
        json_mode: bool = False,
    ) -> LLMResponse:
        ...


class GroqClient(BaseLLMClient):
    """Groq free-tier hosted inference. Supports Llama 3.x, Qwen, Gemma, DeepSeek, Mistral."""

    name = "groq"
    BASE_URL = "https://api.groq.com/openai/v1/chat/completions"

    def __init__(self) -> None:
        self.api_key = settings.GROQ_API_KEY
        self.model = settings.GROQ_MODEL

    async def chat(self, messages, temperature=0.3, max_tokens=700, json_mode=False) -> LLMResponse:
        if not self.api_key:
            raise LLMProviderError("GROQ_API_KEY not configured")

        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if json_mode:
            payload["response_format"] = {"type": "json_object"}

        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}

        async with httpx.AsyncClient(timeout=settings.LLM_TIMEOUT_SECONDS) as client:
            resp = await client.post(self.BASE_URL, json=payload, headers=headers)
            if resp.status_code != 200:
                raise LLMProviderError(f"Groq error {resp.status_code}: {resp.text[:300]}")
            data = resp.json()
            content = data["choices"][0]["message"]["content"]
            return LLMResponse(content=content, provider=self.name, model=self.model, raw=data)


class OllamaClient(BaseLLMClient):
    """Local Ollama inference - zero API cost, requires `ollama serve` running locally."""

    name = "ollama"

    def __init__(self) -> None:
        self.base_url = settings.OLLAMA_BASE_URL
        self.model = settings.OLLAMA_MODEL

    async def chat(self, messages, temperature=0.3, max_tokens=700, json_mode=False) -> LLMResponse:
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "options": {"temperature": temperature, "num_predict": max_tokens},
        }
        if json_mode:
            payload["format"] = "json"

        try:
            async with httpx.AsyncClient(timeout=settings.LLM_TIMEOUT_SECONDS) as client:
                resp = await client.post(f"{self.base_url}/api/chat", json=payload)
                if resp.status_code != 200:
                    raise LLMProviderError(f"Ollama error {resp.status_code}: {resp.text[:300]}")
                data = resp.json()
                content = data.get("message", {}).get("content", "")
                return LLMResponse(content=content, provider=self.name, model=self.model, raw=data)
        except httpx.ConnectError as exc:
            raise LLMProviderError(f"Ollama not reachable at {self.base_url} (is `ollama serve` running?)") from exc


class HuggingFaceClient(BaseLLMClient):
    """Optional HuggingFace Inference API fallback (free tier, rate-limited)."""

    name = "huggingface"
    BASE_URL = "https://api-inference.huggingface.co/models"

    def __init__(self) -> None:
        self.api_key = settings.HF_API_KEY
        self.model = settings.HF_MODEL

    async def chat(self, messages, temperature=0.3, max_tokens=700, json_mode=False) -> LLMResponse:
        if not self.api_key:
            raise LLMProviderError("HF_API_KEY not configured")

        prompt = "\n".join(f"{m['role']}: {m['content']}" for m in messages)
        headers = {"Authorization": f"Bearer {self.api_key}"}
        payload = {
            "inputs": prompt,
            "parameters": {"temperature": temperature, "max_new_tokens": max_tokens, "return_full_text": False},
        }

        async with httpx.AsyncClient(timeout=settings.LLM_TIMEOUT_SECONDS) as client:
            resp = await client.post(f"{self.BASE_URL}/{self.model}", json=payload, headers=headers)
            if resp.status_code != 200:
                raise LLMProviderError(f"HF error {resp.status_code}: {resp.text[:300]}")
            data = resp.json()
            content = data[0]["generated_text"] if isinstance(data, list) else str(data)
            return LLMResponse(content=content, provider=self.name, model=self.model, raw=None)


_PROVIDER_REGISTRY: dict[str, type[BaseLLMClient]] = {
    "groq": GroqClient,
    "ollama": OllamaClient,
    "huggingface": HuggingFaceClient,
}


class LLMRouter:
    """
    Resolves the configured primary provider, falls back automatically on
    failure, and retries transient errors with exponential backoff.
    """

    def __init__(self) -> None:
        self.primary = _PROVIDER_REGISTRY[settings.LLM_PROVIDER]()
        self.fallback: Optional[BaseLLMClient] = (
            _PROVIDER_REGISTRY[settings.LLM_FALLBACK_PROVIDER]()
            if settings.LLM_FALLBACK_PROVIDER != "none"
            else None
        )

    async def chat(
        self,
        messages: list[dict[str, str]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        json_mode: bool = False,
    ) -> LLMResponse:
        temperature = settings.LLM_TEMPERATURE if temperature is None else temperature
        max_tokens = settings.LLM_MAX_TOKENS if max_tokens is None else max_tokens

        last_error: Optional[Exception] = None
        for attempt in range(settings.LLM_MAX_RETRIES + 1):
            try:
                return await self.primary.chat(messages, temperature, max_tokens, json_mode)
            except LLMProviderError as exc:
                last_error = exc
                logger.warning(f"Primary provider {self.primary.name} failed (attempt {attempt + 1}): {exc}")
                await asyncio.sleep(0.5 * (attempt + 1))

        if self.fallback is not None:
            try:
                logger.warning(f"Falling back to {self.fallback.name}")
                return await self.fallback.chat(messages, temperature, max_tokens, json_mode)
            except LLMProviderError as exc:
                last_error = exc

        raise LLMProviderError(f"All LLM providers failed. Last error: {last_error}")

    async def chat_json(self, messages: list[dict[str, str]], **kwargs) -> dict[str, Any]:
        """Convenience wrapper for structured-output prompts (intent detection etc)."""
        response = await self.chat(messages, json_mode=True, **kwargs)
        try:
            return json.loads(response.content)
        except json.JSONDecodeError:
            # Some free-tier models ignore json_mode; extract the first {...} block.
            start, end = response.content.find("{"), response.content.rfind("}")
            if start != -1 and end != -1:
                return json.loads(response.content[start : end + 1])
            raise


llm_router = LLMRouter()
