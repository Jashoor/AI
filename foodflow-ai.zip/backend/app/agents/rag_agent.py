"""
RAG Agent.

Retrieves grounded context for policy/FAQ/restaurant-information style
intents. Returns an explicit "no grounding found" signal when nothing
relevant is retrieved, so the Response Agent never fabricates an answer.
"""
from __future__ import annotations

import logging

from app.rag.retriever import RetrievedChunk, get_retriever

logger = logging.getLogger("foodflow.rag_agent")

RAG_INTENTS = {"faq", "restaurant_information", "coupon_query", "refund_status", "cancel_order", "late_delivery"}


def retrieve_context(query: str, intent: str) -> tuple[list[RetrievedChunk], str]:
    """Returns (chunks, formatted_context_string). Empty list => no grounding found."""
    try:
        retriever = get_retriever()
    except RuntimeError as exc:
        logger.error(f"RAG retriever unavailable: {exc}")
        return [], "NO_RELEVANT_CONTEXT_FOUND"

    chunks = retriever.retrieve(query)
    context = retriever.format_context(chunks)
    return chunks, context
