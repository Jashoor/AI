"""
Synthetic dataset generator for FoodFlow AI.

Generates realistic mock data directly into the SQLite database (and JSON
exports for inspection/versioning), at the scale requested for a portfolio
demo:

    100 restaurants   | 150 drivers      | 500 orders
    300 refunds       | 200 coupons      | 200 payments
    300 policies      | 500 FAQs         | 300 conversation logs

Pure stdlib `random` is used (no Faker dependency) so this runs anywhere
with zero installs beyond the project's own requirements.

Usage:
    python -m data.generate_mock_data
"""
from __future__ import annotations

import json
import random
import sys
import uuid
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.db.models import (  # noqa: E402
    Coupon,
    Driver,
    FAQ,
    Message,
    Conversation,
    Order,
    OrderStatus,
    Payment,
    PaymentStatus,
    Policy,
    Refund,
    RefundStatus,
    Restaurant,
    User,
)
from app.db.session import SessionLocal, init_db  # noqa: E402

random.seed(42)

FIRST_NAMES = [
    "Aarav", "Vivaan", "Aditya", "Vihaan", "Arjun", "Sai", "Reyansh", "Ayaan", "Krishna", "Ishaan",
    "Ananya", "Diya", "Aadhya", "Myra", "Anika", "Navya", "Priya", "Riya", "Saanvi", "Kiara",
    "Rahul", "Rohan", "Karthik", "Vikram", "Suresh", "Meera", "Lakshmi", "Divya", "Neha", "Pooja",
]
LAST_NAMES = ["Sharma", "Verma", "Iyer", "Nair", "Reddy", "Rao", "Gupta", "Menon", "Pillai", "Chatterjee"]
CITIES = ["Chennai", "Bengaluru", "Mumbai", "Hyderabad", "Pune", "Delhi", "Kolkata", "Kochi", "Coimbatore", "Ahmedabad"]
CUISINES = [
    "South Indian", "North Indian", "Chinese", "Italian", "Fast Food", "Biryani", "Continental",
    "Desserts", "Beverages", "Street Food", "Bakery", "Multi-Cuisine", "Mexican", "Thai", "Japanese",
]
RESTAURANT_ADJ = ["Spice", "Royal", "Golden", "Urban", "The Curry", "Green", "Sunrise", "Blue", "Grand", "Metro"]
RESTAURANT_NOUN = ["Kitchen", "House", "Bites", "Corner", "Diner", "Cafe", "Grill", "Bowl", "Table", "Express"]
ITEM_NAMES = [
    "Butter Chicken", "Paneer Tikka", "Veg Biryani", "Chicken Biryani", "Masala Dosa", "Idli Sambar",
    "Margherita Pizza", "Farmhouse Pizza", "Veg Fried Rice", "Chilli Chicken", "Cold Coffee",
    "Chocolate Brownie", "Garlic Naan", "Veg Burger", "Chicken Burger", "French Fries", "Mango Lassi",
]
DELAY_REASONS = ["Heavy traffic", "Restaurant running behind on prep", "Bad weather", "Driver reassignment", None, None, None]
REFUND_REASONS = [
    "Item missing from order", "Food arrived cold", "Wrong item delivered", "Order was late beyond SLA",
    "Duplicate charge", "Order cancelled by restaurant", "Poor food quality", "Packaging damaged",
]
PAYMENT_METHODS = ["UPI", "Credit Card", "Debit Card", "Wallet", "Cash on Delivery", "Net Banking"]


def rand_name() -> str:
    return f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"


def rand_phone() -> str:
    return f"+91{random.randint(70000, 99999)}{random.randint(10000, 99999)}"


def gen_users(n: int) -> list[User]:
    users = []
    for i in range(n):
        name = rand_name()
        users.append(
            User(
                name=name,
                email=f"{name.lower().replace(' ', '.')}{i}@example.com",
                hashed_password=None,
                is_guest=False,
                phone=rand_phone(),
            )
        )
    return users


def gen_restaurants(n: int) -> list[Restaurant]:
    restaurants = []
    for _ in range(n):
        city = random.choice(CITIES)
        restaurants.append(
            Restaurant(
                name=f"{random.choice(RESTAURANT_ADJ)} {random.choice(RESTAURANT_NOUN)}",
                cuisine=random.choice(CUISINES),
                city=city,
                address=f"{random.randint(1, 200)}, {random.choice(['MG Road', 'Anna Salai', 'Park Street', 'Brigade Road', 'Main St'])}, {city}",
                rating=round(random.uniform(3.2, 4.9), 1),
                opens_at="09:00",
                closes_at=random.choice(["22:00", "23:00", "23:30", "00:00"]),
                is_open_now=random.random() > 0.15,
                avg_prep_time_minutes=random.randint(15, 40),
                phone=rand_phone(),
            )
        )
    return restaurants


def gen_drivers(n: int) -> list[Driver]:
    drivers = []
    for _ in range(n):
        drivers.append(
            Driver(
                name=rand_name(),
                phone=rand_phone(),
                vehicle=random.choice(["Bike", "Scooter", "Bicycle"]),
                rating=round(random.uniform(3.8, 5.0), 1),
                current_lat=round(random.uniform(12.9, 13.1), 6),
                current_lng=round(random.uniform(80.1, 80.3), 6),
            )
        )
    return drivers


def gen_coupons(n: int) -> list[Coupon]:
    coupons = []
    now = datetime.utcnow()
    for i in range(n):
        is_percent = random.random() > 0.5
        coupons.append(
            Coupon(
                code=f"FOOD{random.randint(10, 99)}{chr(65 + i % 26)}",
                description=random.choice(
                    ["Flat discount on your order", "Percentage off on orders above minimum value",
                     "New user welcome offer", "Weekend special discount", "Festive season offer"]
                ),
                discount_percent=round(random.uniform(10, 50), 0) if is_percent else None,
                flat_discount=round(random.uniform(50, 200), 0) if not is_percent else None,
                min_order_value=random.choice([0, 149, 199, 299, 499]),
                valid_from=now - timedelta(days=random.randint(0, 30)),
                valid_until=now + timedelta(days=random.randint(5, 90)),
                is_active=random.random() > 0.2,
                usage_limit_per_user=random.choice([1, 1, 1, 2, 3]),
            )
        )
    return coupons


def gen_orders(n: int, users: list[User], restaurants: list[Restaurant], drivers: list[Driver], coupons: list[Coupon]) -> list[Order]:
    orders = []
    now = datetime.utcnow()
    for i in range(n):
        placed_at = now - timedelta(days=random.randint(0, 45), hours=random.randint(0, 23))
        prep_time = random.randint(20, 60)
        eta = placed_at + timedelta(minutes=prep_time)
        status = random.choices(
            list(OrderStatus),
            weights=[5, 5, 8, 12, 55, 8, 7],
            k=1,
        )[0]
        items = random.sample(ITEM_NAMES, k=random.randint(1, 4))
        items_json = [{"name": it, "qty": random.randint(1, 3), "price": round(random.uniform(99, 399), 2)} for it in items]
        total = round(sum(x["price"] * x["qty"] for x in items_json), 2)
        is_delayed = status in (OrderStatus.DELAYED, OrderStatus.OUT_FOR_DELIVERY) and random.random() > 0.6
        orders.append(
            Order(
                display_id=f"FF-{10000 + i}",
                user_id=random.choice(users).id,
                restaurant_id=random.choice(restaurants).id,
                driver_id=random.choice(drivers).id if status not in (OrderStatus.PLACED,) else None,
                items_json=json.dumps(items_json),
                total_amount=total,
                status=status,
                placed_at=placed_at,
                estimated_delivery_at=eta,
                delivered_at=eta if status == OrderStatus.DELIVERED else None,
                delivery_address=f"{random.randint(1, 99)}, {random.choice(['Lake View Apartments', 'Palm Residency', 'Green Valley', 'Sunshine Towers'])}",
                coupon_code=random.choice(coupons).code if random.random() > 0.6 else None,
                is_delayed=is_delayed,
                delay_reason=random.choice(DELAY_REASONS) if is_delayed else None,
            )
        )
    return orders


def gen_refunds(n: int, orders: list[Order]) -> list[Refund]:
    refunds = []
    eligible = [o for o in orders if o.status in (OrderStatus.DELIVERED, OrderStatus.CANCELLED, OrderStatus.DELAYED)]
    for _ in range(n):
        order = random.choice(eligible) if eligible else random.choice(orders)
        status = random.choices(list(RefundStatus), weights=[15, 20, 25, 10, 30], k=1)[0]
        requested_at = order.placed_at + timedelta(hours=random.randint(1, 72))
        refunds.append(
            Refund(
                order_id=order.id,
                reason=random.choice(REFUND_REASONS),
                amount=round(order.total_amount * random.uniform(0.3, 1.0), 2),
                status=status,
                requested_at=requested_at,
                resolved_at=requested_at + timedelta(days=random.randint(1, 5))
                if status in (RefundStatus.APPROVED, RefundStatus.REJECTED, RefundStatus.PROCESSED)
                else None,
            )
        )
    return refunds


def gen_payments(n: int, orders: list[Order]) -> list[Payment]:
    payments = []
    chosen_orders = random.sample(orders, k=min(n, len(orders)))
    for order in chosen_orders:
        status = random.choices(list(PaymentStatus), weights=[85, 5, 5, 5], k=1)[0]
        payments.append(
            Payment(
                order_id=order.id,
                method=random.choice(PAYMENT_METHODS),
                amount=order.total_amount,
                status=status,
                transaction_ref=f"TXN{uuid.uuid4().hex[:12].upper()}",
                created_at=order.placed_at,
            )
        )
    return payments


POLICY_TEMPLATES = [
    ("refund", "Refund Eligibility", "Refunds are eligible for missing items, incorrect items, food quality issues reported within 24 hours of delivery, or orders delayed beyond 60 minutes of the estimated delivery time."),
    ("refund", "Refund Processing Time", "Approved refunds are credited to the original payment method within 5-7 business days. UPI refunds are typically faster, within 2-3 business days."),
    ("cancellation", "Cancellation Window", "Orders can be cancelled free of charge within 2 minutes of placing the order, before the restaurant confirms preparation. After confirmation, cancellation may incur a partial charge for food already prepared."),
    ("cancellation", "Restaurant-Initiated Cancellation", "If a restaurant cancels an order due to unavailability of items or closure, the customer receives a full refund automatically with no cancellation fee."),
    ("delivery", "Delivery SLA", "Standard delivery time is 30-45 minutes depending on distance and restaurant preparation time. Orders delayed beyond the estimated time by more than 20 minutes qualify for delivery credits."),
    ("delivery", "Contactless Delivery", "Customers can opt for contactless delivery at checkout; the driver will leave the order at the door and notify via app."),
    ("coupon", "Coupon Stacking", "Only one coupon code can be applied per order. Coupons cannot be combined with other ongoing promotional offers unless explicitly stated."),
    ("coupon", "Coupon Expiry", "Coupons are valid only within the stated validity window and are automatically invalid after the expiry date, regardless of cart status."),
    ("payment", "Payment Failure Handling", "If a payment fails but the amount is debited, it is automatically reversed to the source account within 5-7 business days. The order is not placed until payment is confirmed."),
    ("payment", "Cash on Delivery Limits", "Cash on Delivery is available for orders below a city-specific value threshold and is disabled during high-fraud-risk periods for a given account."),
    ("terms", "Account Usage", "Each account is intended for individual use. Sharing accounts to exploit new-user offers repeatedly may result in coupon eligibility being revoked."),
    ("privacy", "Data Usage", "Order history, addresses, and payment metadata are used solely to facilitate delivery and support, and are never sold to third-party advertisers."),
]


def gen_policies(n: int) -> list[Policy]:
    policies = []
    for i in range(n):
        category, title, content = POLICY_TEMPLATES[i % len(POLICY_TEMPLATES)]
        policies.append(Policy(category=category, title=f"{title} #{i // len(POLICY_TEMPLATES) + 1}", content=content))
    return policies


FAQ_TEMPLATES = [
    ("order", "How do I track my order?", "Open the Orders tab and select your active order to see a live tracking timeline with driver location and ETA."),
    ("order", "Can I change my delivery address after placing an order?", "You can change the address within 2 minutes of placing the order, before the restaurant begins preparation."),
    ("refund", "How long does a refund take?", "Approved refunds are processed within 5-7 business days to your original payment method."),
    ("refund", "Why was my refund request rejected?", "Refund requests are rejected if reported after the 24-hour issue-reporting window or if the order was marked delivered without any flagged issues."),
    ("payment", "Which payment methods are supported?", "We support UPI, credit/debit cards, wallets, net banking, and Cash on Delivery in eligible areas."),
    ("coupon", "Why isn't my coupon applying?", "Check that your cart meets the minimum order value, the coupon hasn't expired, and you haven't already used your redemption limit."),
    ("delivery", "What happens if my order is late?", "If your order is delayed more than 20 minutes past the estimate, you're automatically eligible for delivery credits, viewable in your order details."),
    ("restaurant", "How do I know if a restaurant is currently open?", "Restaurant hours and live open/closed status are shown on the restaurant page and update automatically."),
    ("account", "How do I delete my account?", "Go to Settings > Account > Delete Account. This is irreversible and removes your order history after 30 days."),
    ("general", "Is there a customer support helpline?", "Yes, in-app chat support is available 24/7, with human escalation for complex issues."),
]


def gen_faqs(n: int) -> list[FAQ]:
    faqs = []
    for i in range(n):
        category, q, a = FAQ_TEMPLATES[i % len(FAQ_TEMPLATES)]
        suffix = f" (variant {i // len(FAQ_TEMPLATES) + 1})" if i >= len(FAQ_TEMPLATES) else ""
        faqs.append(FAQ(category=category, question=q + suffix, answer=a))
    return faqs


def gen_conversations(n: int, users: list[User], orders: list[Order]) -> list[Conversation]:
    convos = []
    sample_turns = [
        ("Hi, I need help with my order", "greeting"),
        ("Where is my order?", "track_order"),
        ("I want to cancel my order", "cancel_order"),
        ("My food arrived cold, I'd like a refund", "food_quality_complaint"),
        ("Is my coupon still valid?", "coupon_query"),
        ("My payment was deducted twice", "payment_issue"),
    ]
    for i in range(n):
        user = random.choice(users)
        convo = Conversation(user_id=user.id, title=random.choice(sample_turns)[0][:40], memory_json="{}")
        convos.append(convo)
    return convos


def run() -> None:
    print("Initializing database schema...")
    init_db()
    db = SessionLocal()

    print("Generating users (120)...")
    users = gen_users(120)
    db.add_all(users)

    print("Generating restaurants (100)...")
    restaurants = gen_restaurants(100)
    db.add_all(restaurants)

    print("Generating drivers (150)...")
    drivers = gen_drivers(150)
    db.add_all(drivers)

    print("Generating coupons (200)...")
    coupons = gen_coupons(200)
    db.add_all(coupons)
    db.commit()

    print("Generating orders (500)...")
    orders = gen_orders(500, users, restaurants, drivers, coupons)
    db.add_all(orders)
    db.commit()

    print("Generating refunds (300)...")
    refunds = gen_refunds(300, orders)
    db.add_all(refunds)

    print("Generating payments (200)...")
    payments = gen_payments(200, orders)
    db.add_all(payments)

    print("Generating policies (300)...")
    policies = gen_policies(300)
    db.add_all(policies)

    print("Generating FAQs (500)...")
    faqs = gen_faqs(500)
    db.add_all(faqs)

    print("Generating conversation logs (300)...")
    convos = gen_conversations(300, users, orders)
    db.add_all(convos)

    db.commit()
    db.close()
    print("Mock data generation complete.")
    print(f"  users={len(users)} restaurants={len(restaurants)} drivers={len(drivers)}")
    print(f"  orders={len(orders)} refunds={len(refunds)} payments={len(payments)} coupons={len(coupons)}")
    print(f"  policies={len(policies)} faqs={len(faqs)} conversations={len(convos)}")


if __name__ == "__main__":
    run()
