# FoodFlow AI
### Multi-Agent Food Delivery Customer Support Platform

A production-style, **100% free-to-run** customer support platform for a food-delivery
product — built with LangGraph multi-agent orchestration, Retrieval-Augmented Generation,
real tool calling against a real database, conversation memory, safety guardrails, and
human escalation.

> Built as a portfolio / capstone-quality reference project. Every LLM, embedding, and
> vector-store component runs on a free tier or fully locally — there is no required
> paid service anywhere in this stack.

---

## Why this exists

Naive single-prompt chatbots hallucinate order statuses and invent refund policies.
FoodFlow AI is grounded by design: a **Tool Agent** calls real backend functions against
a real SQLite database, a **RAG Agent** retrieves real policy/FAQ documents from a FAISS
index, and a single **Response Agent** is the only place natural language is generated —
strictly instructed to use only what those two agents provide. A **Safety Guardrail
Agent** checks both the incoming message (prompt injection, jailbreaks, PII) and the
outgoing draft (groundedness, PII leakage) before anything reaches the user.

Full architecture write-up: [`docs/01_SYSTEM_ARCHITECTURE.md`](docs/01_SYSTEM_ARCHITECTURE.md).

---

## Architecture at a glance

```
START → Supervisor → Intent Detection → [Tool Agent | RAG Agent] → Response Agent
        → Safety Agent → (Escalation Agent if unsafe/ungrounded/low-confidence) → END
```

7 LangGraph nodes: **Supervisor, Intent Detection, Tool Agent, RAG Agent, Response Agent,
Safety Guardrail Agent, Escalation Agent.** See the Mermaid diagrams in the architecture
doc for the full state machine and a sequence diagram of a real request.

---

## Tech stack (all free-tier)

| Layer | Technology |
|---|---|
| Backend | Python, FastAPI, SQLAlchemy, Pydantic, SQLite |
| Orchestration | LangGraph, LangChain |
| LLM | **Groq (free tier, default)** → Ollama (local) → HuggingFace Inference (optional) — fully configurable |
| Embeddings | `BAAI/bge-small-en-v1.5` (local, via sentence-transformers) or `nomic-embed-text` (via Ollama) |
| Vector store | FAISS (local, file-persisted) |
| Frontend | React, TypeScript, TailwindCSS, React Query, Framer Motion, Zustand |
| Deployment | Docker / Docker Compose (also deployable free-tier to Render, Railway, Vercel) |

---

## Project structure

```
foodflow-ai/
├── backend/
│   ├── app/
│   │   ├── core/         # config, logging, JWT auth
│   │   ├── db/           # SQLAlchemy models + session
│   │   ├── schemas/      # Pydantic request/response + tool result models
│   │   ├── tools/        # 16 real tool functions + registry
│   │   ├── rag/          # loader, chunker, embeddings, FAISS store, retriever
│   │   ├── llm/          # Groq/Ollama/HF provider strategy
│   │   ├── agents/       # 7 agents + the LangGraph workflow (graph.py)
│   │   ├── api/routes/   # auth, chat, orders/refunds/coupons/etc.
│   │   └── main.py       # FastAPI app
│   ├── data/
│   │   ├── generate_mock_data.py   # synthetic dataset generator
│   │   └── documents/              # policy/FAQ markdown for RAG
│   ├── evaluation/       # intent accuracy / groundedness evaluation
│   ├── tests/            # pytest unit tests
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── components/   # ChatWindow, MessageBubble, OrderTrackingCard, Sidebar, ...
│   │   ├── pages/        # LoginPage, ChatPage
│   │   ├── store/        # Zustand auth/chat stores
│   │   └── lib/api.ts    # typed API client
│   └── Dockerfile
├── docs/                 # architecture, ER diagrams, deployment guide
└── docker-compose.yml
```

---

## Quickstart (local, no Docker)

### 1. Backend

```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# Edit .env: add a free Groq key from https://console.groq.com/keys
# (or set LLM_PROVIDER=ollama if you'd rather run fully offline)

python -m data.generate_mock_data      # seeds SQLite with synthetic data
python -m app.rag.build_index          # builds the FAISS index from policies/FAQs

uvicorn app.main:app --reload --port 8000
```

Swagger UI: http://localhost:8000/docs

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

Visit http://localhost:5173, choose **Continue as guest**, and start chatting — try
"Where is my order FF-10234?" or "Is coupon FOOD25A still valid?".

### 3. Run tests

```bash
cd backend
pytest
```

### 4. Run the evaluation suite

```bash
cd backend
python -m evaluation.evaluate
```

---

## Running with Docker

```bash
cp backend/.env.example backend/.env   # fill in your free Groq key
docker compose up --build
```

- Frontend: http://localhost:5173
- Backend + Swagger docs: http://localhost:8000/docs

---

## Free-tier LLM configuration

`LLM_PROVIDER` in `.env` controls the primary provider; `LLM_FALLBACK_PROVIDER`
controls automatic fallback on failure. Swapping providers never requires touching
agent code — it's a config change only.

| Provider | Setup | Cost |
|---|---|---|
| **Groq** (default) | Free key at console.groq.com | Free tier, fast hosted inference |
| **Ollama** (fallback) | `ollama serve` + `ollama pull llama3.1` locally | $0, no rate limit, runs on your machine |
| **HuggingFace** (optional) | Free token at huggingface.co/settings/tokens | Free tier, rate-limited |

---

## Key design decisions

- **Grounding over generation.** The Response Agent never calls a tool or retriever
  itself — it only phrases what the Tool Agent / RAG Agent already found. This is what
  prevents hallucinated order statuses or invented policy terms.
- **Structured `ToolResult` everywhere.** Every tool returns `{success, data, error}` —
  never a formatted string — so the LLM can't be handed anything to "creatively"
  misrepresent.
- **Safety fails closed.** If the post-generation groundedness check fails, the system
  escalates to a human rather than returning an unverified answer.
- **Everything free.** Groq's free tier + local Ollama fallback + local embeddings +
  local FAISS + SQLite means this runs at $0 at demo/portfolio scale.

See [`docs/01_SYSTEM_ARCHITECTURE.md`](docs/01_SYSTEM_ARCHITECTURE.md) for the full
rationale, Mermaid diagrams, and sequence diagrams.

---

## License

MIT — free to use, modify, and showcase.
