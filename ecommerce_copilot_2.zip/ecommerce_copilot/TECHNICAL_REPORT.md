# Technical Report: E-commerce ReAct Support Copilot

## 1. Problem Scope and Assumptions

E-commerce platforms receive high volumes of repetitive support queries (order status, returns, refunds,
payments, FAQs). Human agents alone don't scale, but naive LLM chatbots fail in a specific, costly way: they
answer the *literal* question correctly while completely missing the customer's emotional state — so a
technically-correct policy denial delivered to an already-furious, repeat-contact customer makes the outcome
worse, not better, even though "the facts were right."

**This project's scope:** a single-agent ReAct assistant that:
1. Retrieves grounded evidence from a local policy/FAQ corpus (RAG) instead of answering from parametric memory.
2. Calls a small set of mock backend tools (order status, return creation, customer history) instead of
   hallucinating order state.
3. Runs a lightweight, auditable sentiment/frustration classifier *before* the ReAct loop and uses it, combined
   with what the retrieved evidence implies (denial, ambiguity, disputed delivery), to decide whether to escalate
   to a human agent instead of — or alongside — answering directly.
4. Produces every non-trivial claim with an inline citation (`[file:Lx-y]` for markdown/text, `[file:pN]` for
   PDFs) so answers are auditable.

**Assumptions / non-goals:**
- The "LLM" driving reasoning and answer synthesis is, by default, a deterministic rule-based planner/template
  engine (`src/llm_client.py`, backend=`mock`), not a live model call. This is a deliberate reproducibility
  choice — see §3 — and the codebase supports swapping in a real Claude call via `COPILOT_LLM_BACKEND=anthropic`
  without touching the agent/tool/guardrail logic.
- The retrieval "embeddings" are TF-IDF vectors + cosine similarity (via scikit-learn), not a neural embeddings
  model, again for offline reproducibility. The `CorpusIndex.search()` interface is written to be a drop-in swap
  for a real embeddings model + FAISS/Chroma.
- Order/customer data is synthetic and small (13 orders, 10 customers) — enough to exercise every code path
  (standard return, discretionary exception, denial, dispute, abuse-pattern signal) without needing a real
  backend integration.
- This assistant handles the specific intents in scope (order status, returns, refunds, payments, warranty,
  shipping delay, cancellation, address change, account deletion, general FAQ). Anything outside this taxonomy
  falls into the generic FAQ handler and, if unmatched by retrieval, an honest "I don't have a confident answer"
  response rather than a hallucinated one.

---

## 2. Architecture

```
customer message + optional (order_id, customer_id)
        |
        v
+-------------------------------------------------------------------+
| Stage 0: Sentiment/Frustration Classification (src/sentiment.py)  |
|  - lexicon-based frustration/urgency scoring                       |
|  - repeat-contact pattern detection (regex)                        |
|  - legal-threat / explicit-human-request detection                 |
|  - runs BEFORE retrieval, independent of what evidence is found    |
+-------------------------------------------------------------------+
        |
        v
+-------------------------------------------------------------------+
| Stage 1: ReAct Loop (src/agent.py), max 6 steps                   |
|                                                                     |
|   for step in 1..MAX_STEPS:                                        |
|     thought, action, action_input = decide_next_action(state)      |
|     if action == "finish": break                                   |
|     observation = safe_call_tool(action, action_input)   # guarded |
|     state.observations[action] = observation                       |
|                                                                     |
|   Tools (allow-listed, config.ALLOWED_TOOLS):                      |
|     RAG:      search(query), open_file(file), read_chunk(id)       |
|     Backend:  get_order_status(order_id),                          |
|               create_return_request(order_id, reason),             |
|               get_refund_policy(), get_customer_history(cid)       |
+-------------------------------------------------------------------+
        |
        v
+-------------------------------------------------------------------+
| Stage 2: Escalation Gate (agent._should_escalate)                 |
|  Combines:                                                          |
|   - sentiment result (frustration level, legal threat, etc.)        |
|   - what the evidence implies (denial-shaped? disputed delivery?    |
|     outside all defined policy exception windows?)                  |
|   - hard policy rules (e.g. account deletion ALWAYS escalates,      |
|     regardless of tone -- see escalation_policy.md)                  |
|  -> escalate: bool, reasons: list[str]                               |
+-------------------------------------------------------------------+
        |
        v
+-------------------------------------------------------------------+
| Stage 3: Cited Answer Synthesis (agent._synthesize_answer)        |
|  - empathy opener if frustration is medium/high                    |
|  - intent-specific templated body using retrieved/tool evidence     |
|  - inline citation(s): [file:Lx-y] or [file:pN]                    |
|  - explicit escalation notice + reason, if escalating                |
+-------------------------------------------------------------------+
```

### Retrieval pipeline

- **Chunking:** markdown/text files are split into ~90-word windows with 15-word overlap, tracking start/end
  line numbers for citation. PDFs are chunked per-page (splitting further only if a page exceeds the chunk
  size), since a page number is the natural, human-checkable citation unit for a PDF.
- **"Embeddings":** `TfidfVectorizer(stop_words="english", ngram_range=(1,2))` over all chunks.
- **Vector index / search:** cosine similarity between the query vector and all chunk vectors, top-k returned.
- **Why TF-IDF instead of a real embeddings model:** this keeps the entire pipeline runnable with zero network
  access and zero model downloads, which matters for reproducible grading/demoing. The interface
  (`search(query, k) -> list[(Chunk, score)]`) is identical to what a real embeddings + FAISS/Chroma index would
  expose, so swapping in `sentence-transformers` + FAISS only requires rewriting `CorpusIndex._build()` and
  `.search()` — nothing in `tools.py` or `agent.py` needs to change.

### Tool design and guardrails

All tools are registered in `tools.TOOL_REGISTRY`, and `config.ALLOWED_TOOLS` is asserted to match it exactly at
import time — so there's no way for the allow-list and the actual callable tools to silently drift apart.

Every tool call goes through `agent._safe_call_tool`, which:
1. Rejects any tool name not in the allow-list *before* attempting to call it.
2. Wraps the call in try/except so a malformed call or internal error never raises out to the loop.
3. Times the call (`latency_ms`) for later timeout/performance analysis.
4. Applies a retry policy: up to `config.MAX_TOOL_RETRIES` (2) retries, EXCEPT for errors that are clearly not
   transient (invalid ID format, record not found) — retrying those wastes a step for no benefit.

The ReAct loop itself hard-stops at `config.MAX_STEPS` (6); if the planner hasn't reached "finish" by then, the
result is marked `stopped_reason="max_steps_reached"` and the agent answers with whatever evidence it has
gathered rather than looping indefinitely.

### The "Reason" step: rule-based planner (with an LLM upgrade path)

`agent._decide_next_action(state)` is an explicit, inspectable state machine: given the classified intent and
what's been called so far, it decides the next tool call (or "finish"). This was a deliberate choice over a
free-text LLM "Thought:" step, for three reasons:
1. **Reproducibility** — the whole project runs with zero API keys.
2. **Testability** — every decision point is a plain Python branch that can be unit-tested and is fully
   auditable by a support-ops reviewer, which matters a lot for a system that's allowed to decide "route to a
   human" or "approve a return."
3. **Swappable** — `src/llm_client.py` already implements a real Anthropic backend behind the same interface;
   replacing `_decide_next_action` with an LLM planner prompt (system message: "you are a ReAct planner, choose
   the next tool call from this allow-list...") is a contained, well-scoped follow-up that doesn't require
   touching guardrails, tools, or citation logic.

---

## 3. Prompt / Agent Design (Escalation Gate — the project's core contribution)

The escalation gate (`agent._should_escalate`) is where sentiment and evidence combine. Its rules, roughly in
the order they're checked:

| Condition | Escalate? |
|---|---|
| Legal/chargeback threat detected in message | Always |
| Explicit "let me speak to a human" request | Always |
| Intent is `account_deletion` | Always (policy-hard rule, independent of tone — see `escalation_policy.md`) |
| Refund dispute: order shows "delivered" but customer says never received, AND (frustration medium/high OR repeat contact OR prior contact on this issue) | Escalate for manual delivery investigation |
| Return request: outside BOTH the standard and discretionary exception windows | Escalate (no clean policy answer exists) |
| Return request: inside the discretionary window AND customer is frustrated (medium/high) | Escalate for a human judgment call, rather than a flat auto-decision |
| Return request: inside the discretionary window AND low frustration AND order meets the explicit exception criteria (order > $50, no recent exception used) | **No escalation** — approved automatically, citing the rule |
| Payment issue + high frustration | Escalate to payments team |
| High frustration with no other specific trigger | Escalate (generic catch-all — offers a human option) |

The key design decision this encodes: **discretionary policy zones are not automatically "escalate everything."**
An early version of the escalation logic did escalate every past-window return request, which made the assistant
unhelpfully hand off even clean, low-frustration cases that plainly satisfied the written exception criteria.
The final version only escalates the genuinely ambiguous or high-frustration subset — this is the difference
between a bot that's *cautious* and one that's just *unhelpful*.

### Answer synthesis

`agent._synthesize_answer` builds intent-specific, cited prose from the gathered evidence:
- A brief empathy opener is added only when frustration is medium/high (never repeated more than once).
- The body states the resolution/action first, then the policy reasoning, per `escalation_policy.md`'s
  de-escalation guidance ("don't lead with a flat policy quote to a frustrated customer").
- Every claim that depends on retrieved policy text carries its citation tag inline.
- If escalating, a single explicit "I'm escalating this to a human agent" line is appended with the reason(s) —
  deliberately not duplicated in the body text (an early version repeated the escalation announcement twice,
  which read as robotic).

---

## 4. Evaluation Method

`data/evaluation_questions.csv` contains 22 hand-authored questions spanning every supported intent, with gold
labels for: intent, sentiment level, whether the question *should* trigger escalation, and (where applicable)
the expected evidence file. `eval/run_eval.py` runs both the ReAct+tools agent and a **from-scratch LLM-only, no
retrieval, no tools, no escalation-gate baseline** (`src/baseline.py`) over all 22 questions and computes:

- **Intent accuracy** — predicted vs. gold intent.
- **Escalation / tone-appropriateness accuracy** — the project's headline metric: did the system correctly
  decide whether this needed a human, independent of whether the underlying factual answer was right?
- **Grounded precision** — for questions with a gold evidence file, does at least one citation actually point at
  that file? (A proxy for "does this citation really support the claim," not just "is a citation present.")
- **Citation rate** — fraction of answers carrying at least one real, resolvable citation.
- **Hallucinated citation rate** (baseline only) — citation-*shaped* text (e.g. `[general return policy]`) that
  doesn't resolve to any real chunk.

### Results (see `eval/eval_report.md` for the full write-up)

| Metric | LLM-only (no tools) | ReAct + Tools |
|---|---|---|
| Intent accuracy | 95.5% | 95.5% |
| **Escalation / tone-appropriateness accuracy** | **68.2%** | **100.0%** |
| Citation rate | 0.0% | 90.9% |
| Grounded precision (n=20) | 0.0% | 90.0% |
| Hallucinated citation-like text | 27.3% | 0.0% |

Intent accuracy is identical between the two systems because both use the same rule-based intent classifier
(`llm_client.classify_intent_mock`) — the interesting gap is entirely in escalation accuracy and groundedness,
which is exactly what this project set out to measure. The baseline's 68.2% escalation accuracy is "correct" only
by coincidence, on the subset of questions where no escalation was ever required — it has literally no mechanism
to detect frustration, disputed delivery, or policy ambiguity.

### Failure Cases (full detail in `eval/eval_report.md`)

1. **Retrieval ambiguity between near-duplicate sources (Q16):** `warranty_policy.md` and
   `product_care_guide.pdf` both describe the Extended Protection Plan in similar language; TF-IDF ranked the
   markdown chunk higher for a question whose gold source was the PDF. **Attempted fix:** none yet — flagged as
   a known limitation; a real embeddings model would likely disambiguate via deeper semantic similarity, or the
   two documents could be de-duplicated/cross-referenced.
2. **Intent/wording ambiguity (Q12):** "how long do refunds usually take once you receive my return" uses
   "return" as a noun (referring to the physical return shipment), which the rule-based classifier reads as an
   action request (`return_request`) rather than the intended `faq` lookup. **Attempted fix:** none yet — this
   is a genuine limitation of substring/regex-based intent classification versus a trained or LLM-based
   classifier that could use more context.
3. **Chunk boundary noise:** early chunking occasionally split a bullet list mid-sentence, producing citations
   to fragments like "category. - The item was marked...". **Fix attempted:** added 15-word chunk overlap so the
   preceding sentence usually survives in a neighboring chunk; a cleaner fix (not yet implemented) would be
   paragraph/heading-aware chunking.
4. **Escalation over-triggering on ALL-CAPS emphasis (found and fixed during development):** an early lexicon
   version flagged any all-caps word as high frustration, over-firing on short, emphatic-but-polite messages.
   **Fix:** capped the ALL-CAPS score contribution and added a politeness lexicon (please/thank you) that
   subtracts from the score.
5. **Discretionary-window over-escalation (found and fixed during development):** see §3 above — escalating
   every past-window return request was unhelpful; fixed by splitting the discretionary zone into
   clearly-qualifies / clearly-doesn't-qualify / genuinely-ambiguous.

---

## 5. Limitations and Future Improvements

- **Retrieval:** swap TF-IDF for a real sentence-embeddings model (e.g. `sentence-transformers`) + FAISS/Chroma
  for better semantic disambiguation between near-duplicate policy sources; add re-ranking for multi-hop
  questions that need evidence from more than one chunk.
- **Planner:** replace the rule-based `_decide_next_action` with an LLM-driven ReAct planner (the code already
  supports this via `COPILOT_LLM_BACKEND=anthropic`) for more flexible reasoning on out-of-taxonomy questions,
  while keeping the guardrails (allow-list, max-steps, retries) unchanged.
- **Sentiment classifier:** the lexicon-based approach is transparent and easy to audit, but a fine-tuned
  classifier (or an LLM-based sentiment call) would generalize better to phrasing not anticipated by the
  lexicon. A hybrid (lexicon as a fast first-pass filter, LLM as a fallback for borderline scores) is a natural
  next step.
- **Multi-hop citations:** currently each answer typically carries one leading citation; for compositional
  questions (e.g. combining a policy threshold with a specific order's numbers) per-claim citation would be a
  stronger groundedness guarantee.
- **Abuse-pattern detection:** `get_customer_history` surfaces past-return counts and prior contacts, but the
  escalation gate only lightly uses this signal; a more systematic fraud/abuse-pattern check (e.g. flagging
  customers with unusually high "item never arrived" rates) would extend the de-escalation gate's cousin problem
  — the *abuse* side of tone-aware support automation.
- **Real backend integration:** `tools.py`'s mock APIs are structured so that swapping in real order-management/
  payments APIs only requires changing the tool implementations, not their signatures or the calling agent code.
