# Return Policy

## Standard Return Window
Most items purchased on ShopMart can be returned within **30 days** of the delivery date, provided the item is unused, in its original packaging, and accompanied by the order receipt or order ID.

## Non-Returnable Categories
The following categories are final sale and cannot be returned under the standard policy:
- Perishable goods (food, plants, flowers)
- Personal care items that have been opened (cosmetics, earbuds, razors)
- Gift cards and digital/downloadable products
- Custom or personalized items

## Condition Requirements
Items must be returned in the condition they were received:
- Original tags/packaging attached
- No visible signs of use or damage
- All accessories, manuals, and free gifts included

## Late Return Exception (Discretionary)
Customers who are **within 7 days after** the standard 30-day window closes may still be eligible for a return **at agent discretion**, if at least one of the following applies:
- The order total was **above $50**, and the customer has no more than 1 prior late-return exception in the last 12 months.
- The delay was caused by a documented shipping/carrier issue (confirmed via `get_order_status`).
- The item is defective or materially not as described.

Requests that fall outside the 30-day window **and** do not meet any exception criteria above should be **declined**, with an offer to escalate to a human agent for a final review if the customer disagrees.

## How to Request a Return
Customers can request a return by providing their order ID and a reason. The system will validate the order against the return window and exception rules before creating a return request.
