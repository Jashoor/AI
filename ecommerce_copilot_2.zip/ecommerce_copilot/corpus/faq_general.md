# General FAQs

## How do I track my order?
Order tracking is available on the "My Orders" page, or by asking the assistant for an order status with your order ID.

## How do I change my shipping address after placing an order?
Address changes are only possible while the order status is "processing." Once an order is marked "shipped," the address cannot be changed.

## Do you offer price matching?
ShopMart does not offer price matching against competitor sites. Price adjustments within our own site are honored only if the price drop happens within 48 hours of purchase.

## How do I contact a human agent?
Customers can request escalation to a human agent at any time. Escalated conversations are routed to the support queue with the full chat transcript attached, and a human agent typically responds within 2-4 business hours during business days.

## What are your customer support hours?
Chat support is available 24/7 via the assistant. Human agent escalations are handled Monday-Saturday, 9 AM - 9 PM IST.

## How do I close/delete my account?
Account deletion requests must be submitted via the account settings page and are processed within 7 business days. This assistant cannot process account deletion directly and will always escalate such requests to a human agent.
