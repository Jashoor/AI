# Payment Policy

## Accepted Payment Methods
ShopMart accepts credit/debit cards, UPI, net banking, and store credit. Cash on delivery is available only for orders under $100 in eligible pin codes.

## Failed / Duplicate Charges
If a customer reports being charged twice for a single order:
1. Verify via `get_order_status` whether two separate orders were actually created, or whether it is a single authorization plus a duplicate capture.
2. Duplicate captures are automatically reversed within 5-7 business days by the payment processor; ShopMart does not need to manually intervene unless 10+ business days have passed.
3. If 10+ business days have passed with no reversal, escalate to the payments team for manual review.

## Payment Failed but Amount Deducted
If a payment shows as "failed" in the order system but the customer's bank shows a deduction, this is typically a temporary hold that is auto-released by the bank within 5-7 business days. This is not something ShopMart can expedite directly, but the customer can be offered a payments-team escalation if the hold persists beyond 7 business days.

## Invoice and GST/Tax Details
Customers can request a formal invoice with tax breakdown for any completed order via their account order history page. Support agents cannot manually generate custom invoices outside the standard system-generated one.
