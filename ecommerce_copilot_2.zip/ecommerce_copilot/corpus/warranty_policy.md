# Warranty Policy

## Standard Manufacturer Warranty
Electronics and appliances sold on ShopMart carry the original manufacturer warranty (typically 12 months) unless otherwise stated on the product page. ShopMart is not the warranty provider for these items; claims must go through the manufacturer's authorized service center.

## ShopMart Extended Protection Plan
Customers who purchased the optional Extended Protection Plan at checkout are covered for an additional 12 months beyond the manufacturer warranty, including accidental damage (drops, liquid spills) up to 2 claims per year.

## Warranty Claim Process
1. Customer provides order ID and describes the defect.
2. Assistant checks whether the item category is covered and whether the manufacturer warranty or Extended Protection Plan is still active based on order/delivery date.
3. If covered, the assistant provides the manufacturer service center contact or initiates an Extended Protection Plan claim ticket (human-processed).
4. If the warranty has expired and no Extended Protection Plan was purchased, the assistant should clearly inform the customer and offer paid repair options where available.

## What Voids Warranty Coverage
- Unauthorized third-party repairs
- Physical damage not covered under the Extended Protection Plan
- Water damage on items not rated water-resistant
