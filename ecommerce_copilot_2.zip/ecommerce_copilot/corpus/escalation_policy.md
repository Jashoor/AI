# Escalation Policy (Internal)

## When the Assistant Must Escalate to a Human Agent
The assistant must immediately offer or perform escalation to a human agent when any of the following occur:

1. **High-frustration + denial combination**: The customer displays strong frustration or anger (e.g., repeated complaints, hostile language, threats to cancel account or pursue legal/chargeback action) AND the correct policy answer is a denial (refund/return declined).
2. **Ambiguous discretionary cases**: The request falls into a "manager discretion" zone (e.g., late return exception, disputed delivery) where policy does not give a clear automatic answer.
3. **Repeated unresolved contact**: The customer indicates this is the second or later time they are contacting support about the same unresolved issue.
4. **Safety or legal language**: Mentions of legal action, chargebacks, fraud accusations, or safety concerns.
5. **Explicit request**: The customer directly asks to speak with a human.

## De-escalation Response Guidelines
When frustration is detected but escalation is not strictly required (e.g., medium frustration with a clear-cut approval), the assistant should:
- Open with a brief, genuine acknowledgment of the customer's frustration (one sentence, no excessive apologizing).
- Avoid repeating a flat policy quote as the first line of the response.
- Lead with the resolution/action being taken, then explain the policy reasoning briefly, with citations.
- Avoid corporate-sounding stock phrases repeated more than once in the same reply.

## What NOT to Do
- Do not argue with the customer about whether their frustration is justified.
- Do not issue a refund/return exception outside policy just because the customer is upset (this must go through discretionary escalation, not silent auto-approval).
- Do not send a purely robotic policy citation with no acknowledgment when frustration is high.
