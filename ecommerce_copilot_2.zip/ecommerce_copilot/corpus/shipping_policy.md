# Shipping Policy

## Standard Delivery Timelines
- Metro cities: 2-4 business days
- Non-metro cities: 4-7 business days
- Remote/rural pin codes: 7-10 business days

## Delayed Shipments
An order is considered "delayed" if it has not been delivered within 3 business days of the estimated delivery date shown at checkout. Delayed shipments are eligible for:
- Free expedited re-shipping of the same item, or
- Full refund without requiring the item to be returned, if the delay exceeds 10 business days past the estimate.

## Lost-in-Transit Orders
If tracking has not updated for more than 5 business days and the courier partner confirms the shipment is lost, the customer is entitled to a full refund or free replacement, whichever they prefer. This does not require the standard return process since no item needs to be sent back.

## Order Cancellation
Orders can be cancelled free of charge any time before they are marked "shipped." Once an order is marked "shipped," it can no longer be cancelled and must instead go through the standard return process after delivery.

## International Orders
International shipments may incur customs duties payable by the customer on delivery. ShopMart does not cover customs fees and cannot expedite customs clearance.
