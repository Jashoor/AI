# Refund Policy

## Refund Method
Refunds are issued to the **original payment method** used at checkout. If the original payment method is no longer valid (e.g., expired card), the refund is issued as store credit instead.

## Refund Timeline
- Credit/debit card: 5-7 business days after the returned item is received at our warehouse.
- Store credit: Issued immediately once the return is marked "received."
- UPI / net banking: 2-4 business days after the return is received.

## Partial Refunds
A partial refund (item price minus a 10% restocking fee) applies when:
- The item is returned without original packaging.
- The item shows minor signs of use that do not meet "like new" condition but are not severe enough to reject the return outright.

## Refund Eligibility and Denials
A refund request will be **denied** if:
- The return window has closed and no discretionary exception applies (see Return Policy).
- The item is in a non-returnable category.
- The item was marked as a final-sale clearance item at time of purchase.

When a refund is denied, customers should be informed of the reason clearly and offered the option to escalate to a human agent if they believe an exception should apply.

## Refunds for Orders That Never Arrived
If an order's tracking shows "delivered" but the customer states they never received it, the case should NOT be auto-refunded. Instead:
1. Confirm delivery status via `get_order_status`.
2. If status is "delivered" more than 3 days ago and customer disputes receipt, flag for **manual investigation** (possible package theft or misdelivery) rather than approving or denying immediately.
3. If the customer has multiple similar disputes in their order history, this must also be flagged for manual review before any refund is issued.
