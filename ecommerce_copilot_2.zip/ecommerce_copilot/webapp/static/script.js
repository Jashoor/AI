const messagesEl = document.getElementById("messages");
const traceLogEl = document.getElementById("traceLog");
const traceMetaEl = document.getElementById("traceMeta");
const composer = document.getElementById("composer");
const questionEl = document.getElementById("question");
const orderSelect = document.getElementById("orderSelect");
const customerSelect = document.getElementById("customerSelect");
const sendBtn = document.getElementById("sendBtn");
const modeToggle = document.getElementById("modeToggle");
const settingsBtn = document.getElementById("settingsBtn");
const settingsPanel = document.getElementById("settingsPanel");
const apiKeyInput = document.getElementById("apiKey");
const modelInput = document.getElementById("modelName");
const saveKeyBtn = document.getElementById("saveKeyBtn");
const clearBtn = document.getElementById("clearBtn");
const suggestionsEl = document.getElementById("suggestions");
const previewCardsEl = document.getElementById("previewCards");

let mode = "react";
let turnHistory = []; // {userEl, data} so past trace can be replayed on click

// ---------------------------------------------------------------
// Settings panel: API key lives only in sessionStorage (this tab only,
// cleared when the tab closes) -- never persisted server-side.
// ---------------------------------------------------------------
apiKeyInput.value = sessionStorage.getItem("copilot_api_key") || "";
if (sessionStorage.getItem("copilot_model")) modelInput.value = sessionStorage.getItem("copilot_model");

settingsBtn.addEventListener("click", () => {
  settingsPanel.hidden = !settingsPanel.hidden;
});

saveKeyBtn.addEventListener("click", () => {
  sessionStorage.setItem("copilot_api_key", apiKeyInput.value.trim());
  sessionStorage.setItem("copilot_model", modelInput.value.trim());
  saveKeyBtn.textContent = apiKeyInput.value.trim() ? "Saved -- using Claude" : "Saved -- using offline templates";
  saveKeyBtn.classList.add("saved");
  setTimeout(() => { saveKeyBtn.textContent = "Save for this session"; saveKeyBtn.classList.remove("saved"); }, 2200);
});

clearBtn.addEventListener("click", () => {
  messagesEl.innerHTML = '<div class="empty-state">Conversation cleared. Send a new message to start again.</div>';
  traceLogEl.innerHTML = '<div class="empty-state small">Reason \u2192 Act \u2192 Observe steps will appear here as the agent works.</div>';
  traceMetaEl.innerHTML = '<span class="meta-chip idle">idle</span>';
  turnHistory = [];
});

// ---------------------------------------------------------------
// Mode toggle
// ---------------------------------------------------------------
modeToggle.addEventListener("click", (e) => {
  const btn = e.target.closest(".mode-btn");
  if (!btn) return;
  document.querySelectorAll(".mode-btn").forEach((b) => b.classList.remove("active"));
  btn.classList.add("active");
  mode = btn.dataset.mode;
});

// ---------------------------------------------------------------
// Suggestion chips
// ---------------------------------------------------------------
suggestionsEl.addEventListener("click", (e) => {
  const chip = e.target.closest(".chip");
  if (!chip) return;
  questionEl.value = chip.dataset.q;
  orderSelect.value = chip.dataset.order || "";
  customerSelect.value = chip.dataset.customer || "";
  updatePreviewCards();
  questionEl.focus();
});

// ---------------------------------------------------------------
// Order/customer preview cards -- instant, no round trip (data was
// embedded into the page at load, see index.html's window.__ORDERS__)
// ---------------------------------------------------------------
function updatePreviewCards() {
  previewCardsEl.innerHTML = "";
  const oid = orderSelect.value, cid = customerSelect.value;
  if (oid && window.__ORDERS__[oid]) {
    const o = window.__ORDERS__[oid];
    const card = document.createElement("div");
    card.className = "preview-card";
    card.innerHTML = `<strong>${oid}</strong> &middot; ${o.item}<br>${o.status} &middot; $${o.amount}`;
    previewCardsEl.appendChild(card);
  }
  if (cid && window.__CUSTOMERS__[cid]) {
    const c = window.__CUSTOMERS__[cid];
    const flag = c.past_returns_12mo >= 4 ? '<span class="flag">high return history</span>' : `${c.past_returns_12mo} returns/12mo`;
    const card = document.createElement("div");
    card.className = "preview-card";
    card.innerHTML = `<strong>${c.name}</strong><br>${flag}`;
    previewCardsEl.appendChild(card);
  }
}
orderSelect.addEventListener("change", updatePreviewCards);
customerSelect.addEventListener("change", updatePreviewCards);

// ---------------------------------------------------------------
// Enter to send, Shift+Enter for newline
// ---------------------------------------------------------------
questionEl.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    composer.requestSubmit();
  }
});

// ---------------------------------------------------------------
// Rendering helpers
// ---------------------------------------------------------------
function clearEmptyState(container) {
  const empty = container.querySelector(".empty-state");
  if (empty) empty.remove();
}

function addUserBubble(text, turnIndex) {
  clearEmptyState(messagesEl);
  const div = document.createElement("div");
  div.className = "bubble user clickable";
  div.textContent = text;
  div.title = "Click to replay this message's agent trace";
  div.addEventListener("click", () => replayTrace(turnIndex));
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
  return div;
}

function addTypingIndicator() {
  const div = document.createElement("div");
  div.className = "typing-indicator";
  div.id = "typingIndicator";
  div.innerHTML = "<span></span><span></span><span></span>";
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}
function removeTypingIndicator() {
  const el = document.getElementById("typingIndicator");
  if (el) el.remove();
}

function sourceLabel(data) {
  if (data.mode === "baseline") return null;
  if (data.answer_source === "llm_grounded") return ["Answered by Claude (grounded)", "source-llm"];
  if (data.answer_source === "template_fallback_error") return ["Claude call failed \u2014 offline template used", "source-fallback"];
  return ["Offline template (grounded)", "source-template"];
}

function addAssistantBubble(data) {
  clearEmptyState(messagesEl);
  const div = document.createElement("div");
  div.className = "bubble assistant" + (data.escalated ? " escalated" : "");

  const answer = document.createElement("div");
  answer.textContent = data.answer;
  div.appendChild(answer);

  if (data.citations && data.citations.length) {
    const citeWrap = document.createElement("div");
    citeWrap.className = "citations";
    data.citations.forEach((c) => {
      const tag = document.createElement("span");
      tag.className = "citation-tag";
      tag.textContent = c;
      citeWrap.appendChild(tag);
    });
    div.appendChild(citeWrap);
  }

  if (data.escalated) {
    const banner = document.createElement("div");
    banner.className = "escalation-banner";
    banner.textContent = "\u26A0 Escalated to a human agent";
    div.appendChild(banner);
  }

  if (data.hallucinated_citation_like_text) {
    const banner = document.createElement("div");
    banner.className = "hallucination-banner";
    banner.textContent = "\u26A0 Citation-shaped text with no real source (baseline has no retrieval)";
    div.appendChild(banner);
  }

  if (data.init_warning || data.llm_error) {
    const banner = document.createElement("div");
    banner.className = "warning-banner";
    banner.textContent = "\u26A0 " + (data.init_warning || data.llm_error);
    div.appendChild(banner);
  }

  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function renderMeta(data) {
  traceMetaEl.innerHTML = "";
  const chips = [];

  if (data.mode === "baseline") {
    chips.push(["no retrieval / no tools", "idle"]);
    chips.push(["no escalation gate", "idle"]);
  } else {
    const level = data.sentiment ? data.sentiment.frustration_level : "low";
    chips.push([`frustration: ${level}`, `frustration-${level}`]);
    chips.push([data.escalated ? "escalated" : "not escalated", data.escalated ? "escalated" : "not-escalated"]);
    chips.push([`${data.steps.length} step${data.steps.length === 1 ? "" : "s"}`, "idle"]);
  }
  const src = sourceLabel(data);
  if (src) chips.push(src);

  chips.forEach(([label, cls]) => {
    const span = document.createElement("span");
    span.className = "meta-chip " + cls;
    span.textContent = label;
    traceMetaEl.appendChild(span);
  });
}

function stepNode(s) {
  const div = document.createElement("div");
  div.className = "trace-step";
  const obsStr = JSON.stringify(s.observation, null, 2);
  div.innerHTML = `
    <div class="trace-step-header">STEP ${s.step_no} &middot; ${s.latency_ms}ms${s.retries ? " &middot; " + s.retries + " retries" : ""}</div>
    <div class="trace-line"><span class="tag thought">THOUGHT</span><span class="trace-text">${escapeHtml(s.thought)}</span></div>
    <div class="trace-line"><span class="tag action">ACTION</span><span class="trace-text">${escapeHtml(s.action)}(${escapeHtml(JSON.stringify(s.action_input))})</span></div>
    <div class="trace-line"><span class="tag observation">OBSERVATION</span></div>
    <div class="obs-json">${escapeHtml(obsStr)}</div>
  `;
  return div;
}

function renderTrace(data, animate) {
  clearEmptyState(traceLogEl);
  traceLogEl.innerHTML = "";

  if (data.mode === "baseline") {
    const note = document.createElement("div");
    note.className = "trace-step";
    note.innerHTML = `<div class="trace-step-header">NO TOOL CALLS</div>
      <div class="trace-line trace-text">This mode answers directly from general knowledge, with no retrieval,
      no order lookup, and no sentiment gate -- for comparison against ReAct + Tools.</div>`;
    traceLogEl.appendChild(note);
    return;
  }

  if (!data.steps.length) {
    const note = document.createElement("div");
    note.className = "trace-step";
    note.innerHTML = `<div class="trace-step-header">PLANNER</div>
      <div class="trace-line trace-text">No tool calls were needed -- enough was already known to answer.</div>`;
    traceLogEl.appendChild(note);
  }

  const appendRest = () => {
    if (data.escalation_reasons && data.escalation_reasons.length) {
      const div = document.createElement("div");
      div.className = "trace-step";
      div.style.borderColor = "var(--escalate)";
      div.innerHTML = `<div class="trace-step-header" style="color: var(--escalate)">ESCALATION GATE</div>` +
        data.escalation_reasons.map((r) => `<div class="trace-line trace-text">&bull; ${escapeHtml(r)}</div>`).join("");
      traceLogEl.appendChild(div);
    }
    const footer = document.createElement("div");
    footer.className = "trace-footer";
    footer.textContent = `stopped: ${data.stopped_reason}`;
    traceLogEl.appendChild(footer);
    traceLogEl.scrollTop = traceLogEl.scrollHeight;
  };

  if (!animate) {
    data.steps.forEach((s) => traceLogEl.appendChild(stepNode(s)));
    appendRest();
    return;
  }

  // Staggered reveal -- makes the trace feel like it's arriving live,
  // even though the whole result already came back from one request.
  let i = 0;
  function next() {
    if (i >= data.steps.length) { appendRest(); return; }
    traceLogEl.appendChild(stepNode(data.steps[i]));
    traceLogEl.scrollTop = traceLogEl.scrollHeight;
    i += 1;
    setTimeout(next, 320);
  }
  next();
}

function replayTrace(turnIndex) {
  const turn = turnHistory[turnIndex];
  if (!turn) return;
  document.querySelectorAll(".bubble.user").forEach((b) => b.classList.remove("active-history"));
  turn.userEl.classList.add("active-history");
  renderMeta(turn.data);
  renderTrace(turn.data, false);
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// ---------------------------------------------------------------
// Submit
// ---------------------------------------------------------------
composer.addEventListener("submit", async (e) => {
  e.preventDefault();
  const question = questionEl.value.trim();
  if (!question) return;

  const turnIndex = turnHistory.length;
  const userEl = addUserBubble(question, turnIndex);
  questionEl.value = "";
  sendBtn.disabled = true;
  sendBtn.textContent = "Thinking...";
  addTypingIndicator();
  traceLogEl.innerHTML = '<div class="empty-state small">Working...</div>';
  traceMetaEl.innerHTML = '<span class="meta-chip idle">running\u2026</span>';

  try {
    const res = await fetch("/api/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        question,
        order_id: orderSelect.value,
        customer_id: customerSelect.value,
        mode,
        api_key: sessionStorage.getItem("copilot_api_key") || "",
        model: sessionStorage.getItem("copilot_model") || "",
      }),
    });
    const data = await res.json();
    removeTypingIndicator();
    if (!res.ok) {
      addAssistantBubble({ answer: "Error: " + (data.error || "unknown error"), citations: [], escalated: false });
      traceLogEl.innerHTML = '<div class="empty-state small">No trace -- request failed.</div>';
    } else {
      addAssistantBubble(data);
      renderMeta(data);
      renderTrace(data, true);
      turnHistory.push({ userEl, data });
    }
  } catch (err) {
    removeTypingIndicator();
    addAssistantBubble({ answer: "Network error: " + err.message, citations: [], escalated: false });
  } finally {
    sendBtn.disabled = false;
    sendBtn.textContent = "Send";
  }
});
