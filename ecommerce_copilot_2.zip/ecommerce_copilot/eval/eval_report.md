# Evaluation Report -- LLM-only Baseline vs ReAct + Tools

Evaluated on **22 questions** from `data/evaluation_questions.csv`.

## Summary Metrics

| Metric | LLM-only (no tools) | ReAct + Tools |
|---|---|---|
| Intent accuracy | 95.5% | 95.5% |
| Escalation / tone-appropriateness accuracy | 68.2% | 100.0% |
| Citation rate (answers with >=1 real citation) | 0.0% | 90.9% |
| Grounded precision (citation matches gold source), n=20 | 0.0% | 90.0% |
| Hallucinated / unverifiable citation-like text | 27.3% | 0.0% (citations only emitted from real retrieved chunks) |

## What These Numbers Mean

- **Escalation / tone-appropriateness accuracy** is the headline metric for this project's thesis: does the assistant correctly recognize when a policy-correct answer still needs to be routed to a human because of frustration, ambiguity, or an explicit request? The no-tools baseline has **no de-escalation gate at all** -- it always answers the literal question, so it is only 'correct' by accident, on the subset of questions where escalation was never required.

- **Grounded precision** checks whether the *specific document* a citation points to actually matches the expected evidence source for that question -- a proxy for 'does this citation really support the claim,' not just 'is there a citation-shaped string present.'

- The baseline's citations are template strings like `[general return policy]` -- these look like citations but don't resolve to any real chunk, so they are flagged as hallucinated/unverifiable rather than counted as grounded.

## Failure Cases and Fixes Attempted

### Failure case 1: Q12
**Query:** Quick question - how long do refunds usually take once you receive my return?

**Issue:** ReAct's citation pointed at the wrong file (retrieval/ambiguity miss) -- the citation exists and is real, but doesn't match the best gold source.

- Gold intent: `faq` | ReAct predicted: `return_request` | Baseline predicted: `return_request`
- Gold escalate: `False` | ReAct escalated: `False` | Baseline escalated: `False`
- ReAct citations: `[return_policy.md:L28-28]` | expected file: `refund_policy.md`
- **ReAct answer:** Good news -- your return for order ORD1012 is within the standard 30-day window (11 days since delivery), so it's **approved**. Return ID: RET-5D60F70E. [return_policy.md:L28-28]
- **Baseline answer:** Most e-commerce platforms allow returns within about 30 days of delivery, as long as the item is unused and in original packaging. If you're past that window, some retailers make exceptions on a case-by-case basis, so it's worth asking. [general return policy]

### Failure case 2: Q16
**Query:** Is the extended protection plan on my TV order ORD1003 going to cover accidental screen damage?

**Issue:** ReAct's citation pointed at the wrong file (retrieval/ambiguity miss) -- the citation exists and is real, but doesn't match the best gold source.

- Gold intent: `warranty_claim` | ReAct predicted: `warranty_claim` | Baseline predicted: `warranty_claim`
- Gold escalate: `False` | ReAct escalated: `False` | Baseline escalated: `False`
- ReAct citations: `[warranty_policy.md:L10-15]` | expected file: `product_care_guide.pdf`
- **ReAct answer:** Order ORD1003 has the Extended Protection Plan active, which covers defects and accidental damage (up to 2 claims/year). [warranty_policy.md:L10-15]
- **Baseline answer:** Most electronics come with a manufacturer warranty of about a year. If you bought an extended warranty or protection plan, that would typically extend coverage further.

### Failure case 3: Q04
**Query:** This is the SECOND time I'm messaging about ORD1005. I'm extremely frustrated, your app said delivered but I never got my speaker and now you're telling me no refund?! This is ridiculous.

**Issue:** baseline missed a required escalation (high-frustration/legal/ambiguous case); ReAct correctly escalated

- Gold intent: `refund_dispute` | ReAct predicted: `refund_dispute` | Baseline predicted: `refund_dispute`
- Gold escalate: `True` | ReAct escalated: `True` | Baseline escalated: `False`
- ReAct citations: `[refund_policy.md:L20-27]` | expected file: `refund_policy.md`
- **ReAct answer:** I understand this has been frustrating, and I want to help get it sorted. Order ORD1005 shows as delivered, but since you're saying it never arrived, this needs manual investigation into possible misdelivery rather than an automatic refund or denial [refund_policy.md:L20-27]. **I
- **Baseline answer:** If your package shows as delivered but you didn't receive it, this is usually treated as a lost package and most retailers will issue a refund or replacement after a short investigation.

### Failure case 4: Q08
**Query:** I was charged twice for my smartwatch order ORD1009, this better be fixed NOW, I'm losing patience with this company.

**Issue:** baseline missed a required escalation (high-frustration/legal/ambiguous case); ReAct correctly escalated

- Gold intent: `payment_issue` | ReAct predicted: `payment_issue` | Baseline predicted: `payment_issue`
- Gold escalate: `True` | ReAct escalated: `True` | Baseline escalated: `False`
- ReAct citations: `[payment_policy.md:L9-13]` | expected file: `payment_policy.md`
- **ReAct answer:** I understand this has been frustrating, and I want to help get it sorted. On this kind of payment issue: payment processor; ShopMart does not need to manually intervene unless 10+ business days have passed. 3. If 10+ business days have passed... [payment_policy.md:L9-13] Given th
- **Baseline answer:** Duplicate charges are usually a temporary authorization hold that resolves itself within a few business days. If it doesn't resolve, your bank or the merchant's payments team can help.

### Failure case 5: Q11
**Query:** This is my 3rd order return this year and honestly your return process is a joke, I want my desk lamp ORD1011 refunded even though it's past 30 days.

**Issue:** baseline missed a required escalation (high-frustration/legal/ambiguous case); ReAct correctly escalated

- Gold intent: `return_request` | ReAct predicted: `return_request` | Baseline predicted: `return_request`
- Gold escalate: `True` | ReAct escalated: `True` | Baseline escalated: `False`
- ReAct citations: `[return_policy.md:L28-28]` | expected file: `return_policy.md`
- **ReAct answer:** I understand this has been frustrating, and I want to help get it sorted. Your order ORD1011 was delivered 35 days ago, which is outside the standard 30-day return window. This needs a quick human review to apply the right discretionary judgment. [return_policy.md:L28-28] **I'm e
- **Baseline answer:** Most e-commerce platforms allow returns within about 30 days of delivery, as long as the item is unused and in original packaging. If you're past that window, some retailers make exceptions on a case-by-case basis, so it's worth asking. [general return policy]

### Failure case 6: Q13
**Query:** How do I delete my ShopMart account?

**Issue:** baseline missed a required escalation (high-frustration/legal/ambiguous case); ReAct correctly escalated

- Gold intent: `account_deletion` | ReAct predicted: `account_deletion` | Baseline predicted: `account_deletion`
- Gold escalate: `True` | ReAct escalated: `True` | Baseline escalated: `False`
- ReAct citations: `[faq_general.md:L18-19]` | expected file: `faq_general.md`
- **ReAct answer:** Account deletion requests are always routed to a human agent for processing (typically within 7 business days). [faq_general.md:L18-19]
- **Baseline answer:** You can usually delete your account from account settings, or by contacting support directly; it may take a few business days to process.

## Fixes Attempted During Development

1. **Chunk boundary noise:** early line-window chunking occasionally split a bullet list mid-sentence, producing citations to fragments like "category. - The item was marked...". Mitigation attempted: added chunk overlap (15 words) so the preceding sentence is usually still present in the neighboring chunk; a cleaner fix (not yet implemented) would be paragraph/heading-aware chunking instead of a fixed word-count window.

2. **Escalation over-triggering on ALL-CAPS emphasis:** early lexicon versions flagged any all-caps word as high frustration, which over-fired on short emphatic-but-polite messages (e.g. 'RIGHT NOW please'). Mitigation: capped the ALL-CAPS score contribution and let politeness-lexicon terms (please, thank you) subtract from the score so a single emphatic word doesn't dominate.

3. **Discretionary return window ambiguity:** initial escalation logic escalated *every* past-window return request, which made the assistant unhelpfully hand off even clean, low-frustration, policy-satisfying exception cases (order_amount > $50, no recent exception used). Mitigation: split the discretionary zone into 'clearly qualifies' / 'clearly doesn't qualify' / 'ambiguous, escalate' using the explicit criteria in return_policy.md, only escalating the genuinely ambiguous or high-frustration subset.
