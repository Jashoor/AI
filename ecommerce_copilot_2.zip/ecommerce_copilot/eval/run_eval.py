#!/usr/bin/env python3
"""
Evaluation harness: LLM-only (no tools) baseline  vs  ReAct + tools.

For each row in data/evaluation_questions.csv, runs both systems and scores:
  - intent_correct         : predicted intent == gold intent
  - escalation_correct     : escalated == gold true_escalate  (tone-appropriateness proxy)
  - grounded_precision      : for rows with a gold_evidence_file, does at least
                              one citation point at that file? (citation support check)
  - citation_rate           : did the system produce >=1 real [file:...] citation at all?
  - hallucinated_citation   : baseline-only -- citation-shaped text with no real source

Outputs:
  eval/results_baseline.csv
  eval/results_react.csv
  eval/eval_report.md
"""
import csv
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.agent import ReactAgent
from src.baseline import run_baseline
from src import config

EVAL_DIR = os.path.dirname(os.path.abspath(__file__))


def load_questions():
    with open(config.EVAL_QUESTIONS_PATH) as f:
        return list(csv.DictReader(f))


def evaluate():
    rows = load_questions()
    agent = ReactAgent()

    react_results = []
    baseline_results = []

    for row in rows:
        qid = row["query_id"]
        q = row["query_text"]
        order_id = row["order_id"] or None
        customer_id = row["customer_id"] or None
        gold_intent = row["true_intent"]
        gold_escalate = row["true_escalate"].strip().lower() == "yes"
        gold_file = row["gold_evidence_file"].strip()

        # ---- ReAct + tools ----
        r = agent.run(q, order_id=order_id, customer_id=customer_id)
        intent_correct = (r.intent == gold_intent)
        escalation_correct = (r.escalated == gold_escalate)
        cited_files = {c.split(":")[0].strip("[]") for c in r.citations}
        has_gold = bool(gold_file)
        grounded_hit = (gold_file in cited_files) if has_gold else None
        has_citation = len(r.citations) > 0

        react_results.append({
            "query_id": qid, "query": q, "gold_intent": gold_intent, "pred_intent": r.intent,
            "intent_correct": intent_correct, "gold_escalate": gold_escalate, "pred_escalate": r.escalated,
            "escalation_correct": escalation_correct, "frustration_level": r.sentiment["frustration_level"],
            "num_steps": len(r.steps), "tools_used": ",".join(s.action for s in r.steps),
            "citations": ",".join(r.citations), "has_citation": has_citation,
            "gold_file": gold_file, "grounded_hit": grounded_hit,
            "answer": r.answer, "stopped_reason": r.stopped_reason,
        })

        # ---- LLM-only baseline ----
        b = run_baseline(q, order_id=order_id, customer_id=customer_id)
        b_intent_correct = (b.intent == gold_intent)
        b_cited_files = {c.split(":")[0].strip("[]") for c in b.citations}
        b_grounded_hit = (gold_file in b_cited_files) if has_gold else None
        baseline_results.append({
            "query_id": qid, "query": q, "gold_intent": gold_intent, "pred_intent": b.intent,
            "intent_correct": b_intent_correct,
            "gold_escalate": gold_escalate, "pred_escalate": False,  # baseline never escalates
            "escalation_correct": (gold_escalate == False),
            "citations": ",".join(b.citations), "has_citation": len(b.citations) > 0,
            "gold_file": gold_file, "grounded_hit": b_grounded_hit,
            "hallucinated_citation_like_text": b.hallucinated_citation_like_text,
            "answer": b.answer,
        })

    return react_results, baseline_results


def pct(numer, denom):
    return 0.0 if denom == 0 else round(100.0 * numer / denom, 1)


def summarize(results, is_baseline=False):
    n = len(results)
    intent_acc = pct(sum(r["intent_correct"] for r in results), n)
    esc_acc = pct(sum(r["escalation_correct"] for r in results), n)
    grounded_rows = [r for r in results if r["grounded_hit"] is not None]
    grounded_prec = pct(sum(1 for r in grounded_rows if r["grounded_hit"]), len(grounded_rows))
    citation_rate = pct(sum(r["has_citation"] for r in results), n)
    summary = {
        "n": n,
        "intent_accuracy_pct": intent_acc,
        "escalation_accuracy_pct": esc_acc,
        "grounded_precision_pct": grounded_prec,
        "grounded_precision_n": len(grounded_rows),
        "citation_rate_pct": citation_rate,
    }
    if is_baseline:
        summary["hallucinated_citation_rate_pct"] = pct(
            sum(r["hallucinated_citation_like_text"] for r in results), n
        )
    return summary


def write_csv(path, rows):
    if not rows:
        return
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def find_failure_cases(react_results, baseline_results, max_cases=6):
    """Pick illustrative cases for the report: prioritize genuine ReAct
    limitations (retrieval misses, intent ambiguity) FIRST since those are
    the most useful for a 'failure cases and fixes attempted' section, then
    fill remaining slots with baseline-vs-ReAct escalation contrasts."""
    cases = []
    for r, b in zip(react_results, baseline_results):
        if r["grounded_hit"] is False:
            cases.append((r, b, "ReAct's citation pointed at the wrong file (retrieval/ambiguity miss) -- "
                                 "the citation exists and is real, but doesn't match the best gold source."))
    for r, b in zip(react_results, baseline_results):
        if not r["intent_correct"]:
            already = any(r["query_id"] == c[0]["query_id"] for c in cases)
            if not already:
                cases.append((r, b, "Intent misclassification -- the rule-based planner routed this query "
                                     "to the wrong intent handler, which can cascade into the wrong tool sequence."))
    for r, b in zip(react_results, baseline_results):
        if r["gold_escalate"] and not b["pred_escalate"] and r["pred_escalate"]:
            if len(cases) >= max_cases:
                break
            cases.append((r, b, "baseline missed a required escalation (high-frustration/legal/ambiguous case); "
                                 "ReAct correctly escalated"))
    return cases[:max_cases]


def write_report(react_results, baseline_results, out_path):
    react_summary = summarize(react_results)
    baseline_summary = summarize(baseline_results, is_baseline=True)
    failure_cases = find_failure_cases(react_results, baseline_results)

    lines = []
    lines.append("# Evaluation Report -- LLM-only Baseline vs ReAct + Tools\n")
    lines.append(f"Evaluated on **{react_summary['n']} questions** from `data/evaluation_questions.csv`.\n")

    lines.append("## Summary Metrics\n")
    lines.append("| Metric | LLM-only (no tools) | ReAct + Tools |")
    lines.append("|---|---|---|")
    lines.append(f"| Intent accuracy | {baseline_summary['intent_accuracy_pct']}% | {react_summary['intent_accuracy_pct']}% |")
    lines.append(f"| Escalation / tone-appropriateness accuracy | {baseline_summary['escalation_accuracy_pct']}% | {react_summary['escalation_accuracy_pct']}% |")
    lines.append(f"| Citation rate (answers with >=1 real citation) | {baseline_summary['citation_rate_pct']}% | {react_summary['citation_rate_pct']}% |")
    lines.append(f"| Grounded precision (citation matches gold source), n={react_summary['grounded_precision_n']} | {baseline_summary['grounded_precision_pct']}% | {react_summary['grounded_precision_pct']}% |")
    lines.append(f"| Hallucinated / unverifiable citation-like text | {baseline_summary['hallucinated_citation_rate_pct']}% | 0.0% (citations only emitted from real retrieved chunks) |")
    lines.append("")

    lines.append("## What These Numbers Mean\n")
    lines.append(
        "- **Escalation / tone-appropriateness accuracy** is the headline metric for this project's thesis: "
        "does the assistant correctly recognize when a policy-correct answer still needs to be routed to a "
        "human because of frustration, ambiguity, or an explicit request? The no-tools baseline has **no "
        "de-escalation gate at all** -- it always answers the literal question, so it is only 'correct' by "
        "accident, on the subset of questions where escalation was never required.\n"
    )
    lines.append(
        "- **Grounded precision** checks whether the *specific document* a citation points to actually matches "
        "the expected evidence source for that question -- a proxy for 'does this citation really support the "
        "claim,' not just 'is there a citation-shaped string present.'\n"
    )
    lines.append(
        "- The baseline's citations are template strings like `[general return policy]` -- these look like "
        "citations but don't resolve to any real chunk, so they are flagged as hallucinated/unverifiable rather "
        "than counted as grounded.\n"
    )

    lines.append("## Failure Cases and Fixes Attempted\n")
    if not failure_cases:
        lines.append("No qualifying failure cases found in this run.\n")
    else:
        for i, (r, b, desc) in enumerate(failure_cases, 1):
            lines.append(f"### Failure case {i}: {r['query_id']}")
            lines.append(f"**Query:** {r['query']}\n")
            lines.append(f"**Issue:** {desc}\n")
            lines.append(f"- Gold intent: `{r['gold_intent']}` | ReAct predicted: `{r['pred_intent']}` | Baseline predicted: `{b['pred_intent']}`")
            lines.append(f"- Gold escalate: `{r['gold_escalate']}` | ReAct escalated: `{r['pred_escalate']}` | Baseline escalated: `{b['pred_escalate']}`")
            lines.append(f"- ReAct citations: `{r['citations'] or '(none)'}` | expected file: `{r['gold_file'] or '(n/a)'}`")
            lines.append(f"- **ReAct answer:** {r['answer'][:280]}")
            lines.append(f"- **Baseline answer:** {b['answer'][:280]}")
            lines.append("")

    lines.append("## Fixes Attempted During Development\n")
    lines.append(
        "1. **Chunk boundary noise:** early line-window chunking occasionally split a bullet list mid-sentence, "
        "producing citations to fragments like \"category. - The item was marked...\". Mitigation attempted: "
        "added chunk overlap (15 words) so the preceding sentence is usually still present in the neighboring "
        "chunk; a cleaner fix (not yet implemented) would be paragraph/heading-aware chunking instead of a "
        "fixed word-count window.\n"
    )
    lines.append(
        "2. **Escalation over-triggering on ALL-CAPS emphasis:** early lexicon versions flagged any all-caps "
        "word as high frustration, which over-fired on short emphatic-but-polite messages (e.g. 'RIGHT NOW "
        "please'). Mitigation: capped the ALL-CAPS score contribution and let politeness-lexicon terms (please, "
        "thank you) subtract from the score so a single emphatic word doesn't dominate.\n"
    )
    lines.append(
        "3. **Discretionary return window ambiguity:** initial escalation logic escalated *every* "
        "past-window return request, which made the assistant unhelpfully hand off even clean, low-frustration, "
        "policy-satisfying exception cases (order_amount > $50, no recent exception used). Mitigation: split "
        "the discretionary zone into 'clearly qualifies' / 'clearly doesn't qualify' / 'ambiguous, escalate' "
        "using the explicit criteria in return_policy.md, only escalating the genuinely ambiguous or "
        "high-frustration subset.\n"
    )

    with open(out_path, "w") as f:
        f.write("\n".join(lines))

    return react_summary, baseline_summary


def main():
    os.makedirs(EVAL_DIR, exist_ok=True)
    react_results, baseline_results = evaluate()
    write_csv(os.path.join(EVAL_DIR, "results_react.csv"), react_results)
    write_csv(os.path.join(EVAL_DIR, "results_baseline.csv"), baseline_results)
    react_summary, baseline_summary = write_report(
        react_results, baseline_results, os.path.join(EVAL_DIR, "eval_report.md")
    )
    print("=== ReAct + Tools ===")
    print(react_summary)
    print("=== LLM-only Baseline ===")
    print(baseline_summary)
    print(f"\nWrote: eval/results_react.csv, eval/results_baseline.csv, eval/eval_report.md")


if __name__ == "__main__":
    main()
