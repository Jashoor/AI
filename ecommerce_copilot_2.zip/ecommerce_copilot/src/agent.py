"""
ReAct (Reason -> Act -> Observe) agent for the e-commerce support copilot.

Pipeline for one customer message:
  1. Sentiment/urgency/frustration classification (src/sentiment.py) -- runs
     BEFORE the ReAct loop, independent of retrieval, so tone detection is
     never skewed by which evidence happens to get retrieved.
  2. ReAct loop: at each step the agent (a) reasons about what it still
     needs, (b) picks ONE tool call from the allow-list, (c) observes the
     structured result, up to config.MAX_STEPS. Every step is logged.
  3. De-escalation gate: combines the sentiment result + what the evidence
     implies (denial / ambiguity / repeat contact) to decide whether to
     escalate to a human agent instead of, or alongside, answering.
  4. Final answer synthesis with inline citations, e.g. [return_policy.md:L14-21]
     or [account_terms.pdf:p2], plus a short supporting quote.

NOTE ON THE "REASON" STEP: to keep the whole project runnable offline with
zero API keys (see src/llm_client.py), the reasoning/tool-selection step
uses an explicit, auditable rule-based planner (`_decide_next_action`)
instead of an LLM free-text "Thought:". This is a deliberate simplification
for reproducibility -- swap `config.LLM_BACKEND = "anthropic"` and replace
`_decide_next_action` with an LLM planner prompt to get free-form reasoning;
the tool-calling contract, guardrails, and logging format are unchanged.
"""
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from . import config, tools, sentiment
from .llm_client import LLMClient, classify_intent_mock

DEFECT_KEYWORDS = ["defect", "defective", "broken", "malfunction", "manufactur"]
SHIPPING_ISSUE_KEYWORDS = ["carrier", "courier", "shipping issue", "lost in transit"]
NEVER_RECEIVED_KEYWORDS = ["never got", "never received", "didn't receive", "did not receive", "not received"]


@dataclass
class Step:
    step_no: int
    thought: str
    action: str
    action_input: Dict[str, Any]
    observation: Dict[str, Any]
    latency_ms: float
    retries: int = 0


@dataclass
class AgentResult:
    query: str
    intent: str
    sentiment: dict
    steps: List[Step] = field(default_factory=list)
    escalated: bool = False
    escalation_reasons: List[str] = field(default_factory=list)
    answer: str = ""
    citations: List[str] = field(default_factory=list)
    stopped_reason: str = "finished"
    answer_source: str = "template"   # "template" | "llm_grounded" | "template_fallback_error"
    llm_error: Optional[str] = None

    def to_log_row(self) -> dict:
        return {
            "query": self.query,
            "intent": self.intent,
            "frustration_level": self.sentiment.get("frustration_level"),
            "num_steps": len(self.steps),
            "tools_used": ",".join(s.action for s in self.steps),
            "escalated": self.escalated,
            "escalation_reasons": "; ".join(self.escalation_reasons),
            "citations": ",".join(self.citations),
            "answer": self.answer,
            "stopped_reason": self.stopped_reason,
            "answer_source": self.answer_source,
        }


class ReactAgent:
    def __init__(self, llm: Optional[LLMClient] = None):
        self.llm = llm or LLMClient()

    # ------------------------------------------------------------ public API
    def run(self, query: str, order_id: Optional[str] = None, customer_id: Optional[str] = None) -> AgentResult:
        sent = sentiment.classify(query)
        intent = classify_intent_mock(query)
        result = AgentResult(query=query, intent=intent, sentiment=sent.as_dict())

        state: Dict[str, Any] = {
            "order_id": order_id,
            "customer_id": customer_id,
            "intent": intent,
            "query": query,
            "observations": {},   # tool_name -> last observation dict
            "called": [],         # ordered list of tool names called
        }

        for step_no in range(1, config.MAX_STEPS + 1):
            thought, action, action_input = self._decide_next_action(state)
            if action == "finish":
                result.stopped_reason = "planner_finished"
                break

            observation, retries = self._safe_call_tool(action, action_input)
            latency_ms = observation.pop("_latency_ms", 0.0)
            step = Step(step_no, thought, action, action_input, observation, latency_ms, retries)
            result.steps.append(step)

            state["observations"][action] = observation
            state["called"].append(action)

            if len(result.steps) >= config.MAX_STEPS:
                result.stopped_reason = "max_steps_reached"
                break

        # -------- de-escalation gate --------
        escalate, reasons = self._should_escalate(intent, sent, state)
        result.escalated = escalate
        result.escalation_reasons = reasons

        # -------- final answer synthesis --------
        # Always compute the template answer first: it's fast, deterministic,
        # and doubles as the guaranteed fallback if a real LLM call fails.
        template_answer, template_citations = self._synthesize_answer(intent, sent, state, escalate, reasons)
        result.answer = template_answer
        result.citations = template_citations
        result.answer_source = "template"

        if self.llm.backend != "mock":
            try:
                dossier = self._build_evidence_dossier(state)
                llm_text = self.llm.complete_grounded(
                    evidence=dossier,
                    question=query,
                    frustration_level=sent.frustration_level,
                    escalate=escalate,
                    escalation_reasons=reasons,
                )
                valid_citations = self._extract_valid_citations(llm_text, template_citations)
                result.answer = llm_text.strip()
                result.citations = valid_citations
                result.answer_source = "llm_grounded"
            except Exception as e:
                result.answer_source = "template_fallback_error"
                result.llm_error = str(e)
                # result.answer / result.citations already hold the template fallback

        return result

    # ------------------------------------------------------- evidence dossier (for a real LLM call)
    def _build_evidence_dossier(self, state) -> str:
        """Assembles everything the ReAct loop retrieved into a plain-text dossier
        for a real LLM call -- full chunk text (not just previews), so the model
        has the same grounding a human agent reading the same lookups would have."""
        obs = state["observations"]
        parts = []

        order_obs = obs.get("get_order_status", {})
        if order_obs.get("ok"):
            parts.append("ORDER DETAILS:\n" + "\n".join(f"  {k}: {v}" for k, v in order_obs.items() if not k.startswith("_")))

        hist_obs = obs.get("get_customer_history", {})
        if hist_obs.get("ok"):
            parts.append("CUSTOMER HISTORY:\n" + "\n".join(f"  {k}: {v}" for k, v in hist_obs.items() if not k.startswith("_")))

        cr_obs = obs.get("create_return_request", {})
        if cr_obs.get("ok"):
            parts.append("RETURN REQUEST VALIDATION:\n" + "\n".join(f"  {k}: {v}" for k, v in cr_obs.items() if not k.startswith("_")))

        search_obs = obs.get("search", {})
        if search_obs.get("ok") and search_obs.get("results"):
            chunk_texts = []
            for r in search_obs["results"][:3]:
                full = tools.read_chunk(r["chunk_id"])
                if full.get("ok"):
                    chunk_texts.append(f"{full['citation']} {full['text']}")
            if chunk_texts:
                parts.append("RETRIEVED POLICY TEXT:\n" + "\n\n".join(chunk_texts))

        refund_obs = obs.get("get_refund_policy", {})
        if refund_obs.get("ok") and refund_obs.get("text"):
            parts.append(f"[{refund_obs['file']}] {refund_obs['text']}")

        return "\n\n".join(parts)

    @staticmethod
    def _extract_valid_citations(text: str, known_citations: List[str]) -> List[str]:
        """Safety net: only keep citation tags in the LLM's output that exactly
        match a citation the ReAct loop actually retrieved -- this prevents a
        real LLM from inventing a plausible-looking but fake [file:line] tag."""
        found = re.findall(r"\[[\w\-. ]+\.(?:md|txt|pdf):(?:L\d+-\d+|p\d+)\]", text)
        known_set = set(known_citations)
        valid = [c for c in dict.fromkeys(found) if c in known_set]  # preserve order, dedupe
        # If the LLM's citations don't match what we tracked (e.g. it cited a
        # second chunk we didn't pre-extract into `known_citations`), fall back
        # to whatever real tags it produced, since format-matching is itself
        # a reasonable validity check for this small, known corpus.
        return valid if valid else [c for c in dict.fromkeys(found)]

    # ------------------------------------------------------- guardrailed tool call
    def _safe_call_tool(self, action: str, action_input: Dict[str, Any]):
        """Enforces the allow-list, applies a timeout budget, and retries
        malformed/failed calls up to config.MAX_TOOL_RETRIES times."""
        if action not in config.ALLOWED_TOOLS:
            return {"ok": False, "error": f"Tool '{action}' is not in the allow-list.", "_latency_ms": 0.0}, 0

        fn = tools.TOOL_REGISTRY[action]
        last_obs = None
        attempt = 0
        for attempt in range(config.MAX_TOOL_RETRIES + 1):
            start = time.time()
            try:
                obs = fn(**action_input)
            except TypeError as e:
                obs = {"ok": False, "error": f"Bad arguments for {action}: {e}"}
            except Exception as e:  # pragma: no cover
                obs = {"ok": False, "error": f"Tool '{action}' raised an unexpected error: {e}"}
            elapsed_ms = (time.time() - start) * 1000
            obs["_latency_ms"] = elapsed_ms
            last_obs = obs
            if obs.get("ok"):
                return obs, attempt
            # simple retry policy: only retry if it looks transient/malformed, not a hard "not found"
            if "not a valid" in obs.get("error", "") or "not found" in obs.get("error", ""):
                break  # no point retrying a bad ID
        return last_obs, attempt

    # ------------------------------------------------------------- planner
    def _decide_next_action(self, state) -> (str, str, Dict[str, Any]):
        intent = state["intent"]
        called = state["called"]
        order_id = state["order_id"]
        customer_id = state["customer_id"]
        obs = state["observations"]

        needs_order = intent in {
            "order_status", "return_request", "refund_dispute", "cancellation",
            "warranty_claim", "payment_issue", "shipping_delay", "address_change",
        }
        if needs_order and order_id and "get_order_status" not in called:
            return (
                f"This is a {intent} question about a specific order -- I need order details before I can answer.",
                "get_order_status", {"order_id": order_id},
            )

        needs_history = intent in {"return_request", "refund_dispute"}
        if needs_history and customer_id and "get_customer_history" not in called:
            return (
                "This intent can involve discretionary/abuse-pattern judgment calls, so I should check "
                "this customer's contact/return history before deciding.",
                "get_customer_history", {"customer_id": customer_id},
            )

        needs_policy = intent not in {"order_status"}  # pure status lookups don't need policy text
        if needs_policy and "search" not in called:
            q = self._policy_query_for_intent(intent, state["query"])
            return (
                f"I need the relevant policy text to ground my answer for a '{intent}' question.",
                "search", {"query": q},
            )

        if intent == "return_request" and order_id and "create_return_request" not in called:
            return (
                "I have the order details, customer history, and policy text -- now let me run the "
                "return request through the window/exception validation.",
                "create_return_request", {"order_id": order_id, "reason": state["query"][:200]},
            )

        return ("I have enough evidence to answer.", "finish", {})

    @staticmethod
    def _policy_query_for_intent(intent: str, query_text: str) -> str:
        mapping = {
            "return_request": "return window exception policy",
            "refund_dispute": "refund denied disputed delivery never arrived",
            "cancellation": "order cancellation before shipped",
            "warranty_claim": "warranty extended protection plan claim",
            "payment_issue": "duplicate charge payment failed deducted",
            "shipping_delay": "delayed shipment refund replacement",
            "address_change": "change shipping address after order placed",
            "account_deletion": "close delete account",
            "faq": query_text,
        }
        return mapping.get(intent, query_text)

    # -------------------------------------------------------- escalation gate
    def _should_escalate(self, intent: str, sent: sentiment.SentimentResult, state) -> (bool, List[str]):
        reasons = []
        obs = state["observations"]
        query_lower = state["query"].lower()

        if sent.legal_threat:
            reasons.append("Customer language includes a legal/chargeback threat.")
        if sent.explicit_human_request:
            reasons.append("Customer explicitly asked to speak with a human agent.")
        if intent == "account_deletion":
            reasons.append("Account deletion is policy-required to route to a human agent (faq_general.md).")

        if intent == "refund_dispute":
            disputed = any(k in query_lower for k in NEVER_RECEIVED_KEYWORDS)
            order_obs = obs.get("get_order_status", {})
            hist_obs = obs.get("get_customer_history", {})
            if disputed and order_obs.get("status") == "delivered":
                if sent.frustration_level in ("medium", "high") or sent.repeat_contact or hist_obs.get("prior_contacts_this_issue", 0) >= 1:
                    reasons.append(
                        "Disputed delivery (marked delivered, customer says not received) combined with "
                        "frustration/repeat contact requires manual investigation, not an automatic decision (refund_policy.md)."
                    )

        if intent == "return_request":
            cr = obs.get("create_return_request", {})
            if cr.get("ok") and cr.get("status") == "needs_discretion_review":
                if not cr.get("within_discretionary_window", False):
                    reasons.append(
                        "Return request is outside both the standard and discretionary exception windows -- "
                        "no clear automatic policy answer applies; needs human review (return_policy.md)."
                    )
                elif sent.frustration_level in ("medium", "high"):
                    reasons.append(
                        "Return request is in the discretionary exception window and the customer is frustrated -- "
                        "routing to a human for a judgment call rather than a flat auto-decision."
                    )

        if intent == "payment_issue" and sent.frustration_level == "high":
            reasons.append("High-frustration payment dispute -- routing to the payments escalation path.")

        if sent.frustration_level == "high" and not reasons:
            # generic catch-all: high frustration with no other specific reason still gets a human option
            reasons.append("Overall high frustration detected in this message.")

        return (len(reasons) > 0, reasons)

    # -------------------------------------------------------- answer synthesis
    def _synthesize_answer(self, intent, sent: sentiment.SentimentResult, state, escalate: bool, reasons: List[str]):
        obs = state["observations"]
        citations: List[str] = []
        lines: List[str] = []

        empathy_opener = None
        if sent.frustration_level in ("medium", "high"):
            empathy_opener = "I understand this has been frustrating, and I want to help get it sorted."

        # ---- gather citation-bearing evidence from the search step, if any
        search_obs = obs.get("search", {})
        top_citation = None
        top_quote = None
        if search_obs.get("ok") and search_obs.get("results"):
            best = search_obs["results"][0]
            top_citation = best["citation"]
            top_quote = best["preview"].strip()
            if len(top_quote) > 140:
                top_quote = top_quote[:140].rsplit(" ", 1)[0] + "..."
            citations.append(top_citation)

        order_obs = obs.get("get_order_status", {})

        # ---- intent-specific body ----
        if intent == "order_status" and order_obs.get("ok"):
            body = (
                f"Order {order_obs['order_id']} ({order_obs['item']}) is currently **{order_obs['status']}**."
            )
            if order_obs.get("delivery_date"):
                body += f" It was delivered on {order_obs['delivery_date']}."
            lines.append(body)

        elif intent == "return_request":
            cr = obs.get("create_return_request", {})
            if cr.get("ok"):
                if cr["status"] == "auto_approved":
                    body = (
                        f"Good news -- your return for order {cr['order_id']} is within the standard 30-day window "
                        f"({cr['days_since_delivery']} days since delivery), so it's **approved**. "
                        f"Return ID: {cr['return_id']}."
                    )
                elif escalate:
                    body = (
                        f"Your order {cr['order_id']} was delivered {cr['days_since_delivery']} days ago, which is "
                        f"outside the standard 30-day return window. This needs a quick human review to apply the "
                        f"right discretionary judgment."
                    )
                else:
                    # within discretionary window but escalation not triggered -> apply rule transparently
                    amount = cr.get("amount", 0)
                    hist = obs.get("get_customer_history", {})
                    exception_eligible = amount > 50 and hist.get("past_late_return_exceptions_12mo", 0) <= 1
                    if exception_eligible:
                        body = (
                            f"Your order {cr['order_id']} was delivered {cr['days_since_delivery']} days ago -- just "
                            f"past the standard 30-day window, but within our 7-day discretionary grace period, and "
                            f"the order qualifies (over $50, no recent exception used). I'm approving this as an "
                            f"exception. Return ID: {cr['return_id']}."
                        )
                    else:
                        body = (
                            f"Your order {cr['order_id']} was delivered {cr['days_since_delivery']} days ago, past "
                            f"the standard 30-day window. It doesn't meet the discretionary exception criteria "
                            f"(order over $50, carrier delay, or defect), so I'm not able to approve a return "
                            f"automatically. You're welcome to ask for a human review if you'd like a second look."
                        )
                if top_citation:
                    body += f" {top_citation}"
                lines.append(body)
            elif top_citation:
                lines.append(f"Based on our return policy: {top_quote} {top_citation}")

        elif intent == "refund_dispute":
            disputed = any(k in state["query"].lower() for k in NEVER_RECEIVED_KEYWORDS)
            if disputed and order_obs.get("status") == "delivered":
                if escalate:
                    lines.append(
                        f"Order {order_obs.get('order_id')} shows as delivered, but since you're saying it never "
                        f"arrived, this needs manual investigation into possible misdelivery rather than an "
                        f"automatic refund or denial {top_citation or ''}."
                    )
                else:
                    lines.append(
                        f"Order {order_obs.get('order_id')} shows as delivered. Since you're reporting it never "
                        f"arrived, I'm flagging this for manual delivery investigation rather than auto-approving "
                        f"or denying a refund {top_citation or ''}."
                    )
            elif top_citation:
                lines.append(f"On refunds: {top_quote} {top_citation}")

        elif intent == "warranty_claim":
            covered = order_obs.get("extended_protection_plan", False)
            if order_obs.get("ok"):
                if covered:
                    lines.append(
                        f"Order {order_obs['order_id']} has the Extended Protection Plan active, which covers "
                        f"defects and accidental damage (up to 2 claims/year). {top_citation or ''}"
                    )
                else:
                    lines.append(
                        f"Order {order_obs['order_id']} does not have the Extended Protection Plan, so coverage "
                        f"depends on the standard manufacturer warranty. {top_citation or ''}"
                    )
            elif top_citation:
                lines.append(f"On warranty coverage: {top_quote} {top_citation}")

        elif intent == "payment_issue":
            if top_citation:
                lines.append(f"On this kind of payment issue: {top_quote} {top_citation}")
            if escalate:
                lines.append("Given the urgency here, I'm escalating this to our payments team directly.")

        elif intent == "shipping_delay":
            m = re.search(r"(\d+)\s*(?:business\s*)?days?\s*late", state["query"].lower())
            days_late = int(m.group(1)) if m else None
            if days_late is not None:
                if days_late > 10:
                    lines.append(
                        f"Since this shipment is {days_late} business days late (more than the 10-day threshold), "
                        f"you're eligible for a **full refund without needing to return the item**. {top_citation or ''}"
                    )
                elif days_late > 3:
                    lines.append(
                        f"Since this shipment is {days_late} business days late (past our 3-day delayed threshold), "
                        f"you're eligible for **free expedited re-shipping**. {top_citation or ''}"
                    )
                else:
                    lines.append(f"A {days_late}-day delay is within normal shipping variance. {top_citation or ''}")
            elif top_citation:
                lines.append(f"On shipping delays: {top_quote} {top_citation}")

        elif intent == "cancellation":
            if order_obs.get("ok"):
                if order_obs["status"] in ("processing",):
                    lines.append(
                        f"Order {order_obs['order_id']} is still processing (not yet shipped), so it can be "
                        f"cancelled free of charge. {top_citation or ''}"
                    )
                else:
                    lines.append(
                        f"Order {order_obs['order_id']} has status '{order_obs['status']}', so it can no longer "
                        f"be cancelled -- it would need to go through the standard return process after delivery. "
                        f"{top_citation or ''}"
                    )
            elif top_citation:
                lines.append(f"On cancellations: {top_quote} {top_citation}")

        elif intent == "address_change":
            if order_obs.get("ok"):
                if order_obs["status"] == "processing":
                    lines.append(
                        f"Order {order_obs['order_id']} is still processing, so the shipping address can still be "
                        f"updated. {top_citation or ''}"
                    )
                else:
                    lines.append(
                        f"Order {order_obs['order_id']} has status '{order_obs['status']}', so the address can no "
                        f"longer be changed. {top_citation or ''}"
                    )
            elif top_citation:
                lines.append(f"On address changes: {top_quote} {top_citation}")

        elif intent == "account_deletion":
            lines.append(
                "Account deletion requests are always routed to a human agent for processing (typically within "
                f"7 business days). {top_citation or ''}"
            )

        else:  # faq / fallback
            if top_citation:
                lines.append(f"{top_quote} {top_citation}")
            else:
                lines.append("I couldn't find a confident answer in our policy documents for that.")

        if escalate and intent not in ("account_deletion",):
            reason_text = " ".join(reasons)
            lines.append(f"**I'm escalating this to a human agent.** ({reason_text})")

        body_text = " ".join(l.strip() for l in lines if l.strip())
        if empathy_opener and intent != "order_status":
            final = f"{empathy_opener} {body_text}"
        else:
            final = body_text

        # de-dupe consecutive identical citation tags in prose, keep citations list unique+ordered
        seen = set()
        unique_citations = []
        for c in citations:
            if c not in seen:
                unique_citations.append(c)
                seen.add(c)
        return final.strip(), unique_citations


if __name__ == "__main__":
    agent = ReactAgent()
    demo_queries = [
        ("Hi, can you tell me the status of my order ORD1001?", "ORD1001", "CUST01"),
        ("This is the SECOND time I'm messaging about ORD1005. I'm extremely frustrated, your app said "
         "delivered but I never got my speaker and now you're telling me no refund?! This is ridiculous.",
         "ORD1005", "CUST05"),
    ]
    for q, oid, cid in demo_queries:
        r = agent.run(q, order_id=oid, customer_id=cid)
        print("=" * 80)
        print("Q:", q)
        for s in r.steps:
            print(f"  Step {s.step_no}: THOUGHT: {s.thought}")
            print(f"           ACTION: {s.action}({s.action_input})")
            print(f"           OBSERVATION: {s.observation}")
        print("ESCALATED:", r.escalated, r.escalation_reasons)
        print("ANSWER:", r.answer)
        print("CITATIONS:", r.citations)
