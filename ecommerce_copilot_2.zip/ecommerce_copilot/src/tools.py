"""
Mock backend "tools" the ReAct agent can call, plus RAG-facing tools
(search / open_file / read_chunk). Every tool:
  - validates its own inputs,
  - returns a small structured dict (never raw exceptions to the agent),
  - is registered in TOOL_REGISTRY so agent.py can enforce the allow-list.
"""
import json
import re
import uuid
from datetime import date, datetime

from . import config
from .corpus_index import CorpusIndex

with open(config.ORDERS_PATH) as f:
    _ORDERS = json.load(f)
with open(config.CUSTOMERS_PATH) as f:
    _CUSTOMERS = json.load(f)

# A single shared index instance -- built once, reused by every tool call.
_INDEX = CorpusIndex()

TODAY = date(2026, 7, 22)  # fixed "current date" for reproducible demo/eval runs

ORDER_ID_RE = re.compile(r"^ORD\d{3,6}$")


def _days_between(d1: str, d2: date) -> int:
    return (d2 - datetime.strptime(d1, "%Y-%m-%d").date()).days


# ---------------------------------------------------------------- RAG tools
def search(query: str, k: int = config.TOP_K) -> dict:
    """Search the policy/FAQ corpus. Returns top-k chunk previews + ids."""
    if not query or not isinstance(query, str):
        return {"ok": False, "error": "search() requires a non-empty query string."}
    results = _INDEX.search(query, k=k)
    return {
        "ok": True,
        "results": [
            {
                "chunk_id": c.chunk_id,
                "citation": c.citation(),
                "score": round(score, 3),
                "preview": c.text[:220],
            }
            for c, score in results
        ],
    }


def open_file(file: str) -> dict:
    """Return the full text of a corpus file. Allow-listed to files that exist in the corpus dir only."""
    valid_files = _INDEX.list_files()
    if file not in valid_files:
        return {"ok": False, "error": f"'{file}' is not a recognized corpus file.", "valid_files": valid_files}
    text = _INDEX.get_file_text(file)
    return {"ok": True, "file": file, "text": text}


def read_chunk(chunk_id: str) -> dict:
    """Return the full text + citation for a specific chunk id returned by search()."""
    chunk = _INDEX.get_chunk(chunk_id)
    if chunk is None:
        return {"ok": False, "error": f"chunk_id '{chunk_id}' not found."}
    return {"ok": True, "chunk_id": chunk_id, "citation": chunk.citation(), "text": chunk.text}


# ------------------------------------------------------------ backend tools
def get_order_status(order_id: str) -> dict:
    """Mock order-status API."""
    if not order_id or not ORDER_ID_RE.match(order_id):
        return {"ok": False, "error": f"'{order_id}' is not a valid order ID format (expected ORDxxxx)."}
    order = _ORDERS.get(order_id)
    if not order:
        return {"ok": False, "error": f"No order found with id {order_id}."}
    out = dict(order)
    out["order_id"] = order_id
    if order.get("delivery_date"):
        out["days_since_delivery"] = _days_between(order["delivery_date"], TODAY)
    out["days_since_order"] = _days_between(order["order_date"], TODAY)
    return {"ok": True, **out}


def create_return_request(order_id: str, reason: str) -> dict:
    """Mock return-request creation. This is a MUTATING tool -- validated against
    the return window / exception rules before 'creating' anything."""
    if not order_id or not ORDER_ID_RE.match(order_id):
        return {"ok": False, "error": f"'{order_id}' is not a valid order ID format."}
    if not reason or len(reason.strip()) < 3:
        return {"ok": False, "error": "A return reason is required."}
    order = _ORDERS.get(order_id)
    if not order:
        return {"ok": False, "error": f"No order found with id {order_id}."}
    if order["status"] != "delivered":
        return {"ok": False, "error": f"Order {order_id} has status '{order['status']}'; only delivered orders can be returned."}

    days_since_delivery = _days_between(order["delivery_date"], TODAY)
    within_window = days_since_delivery <= 30
    within_discretionary_window = 30 < days_since_delivery <= 37  # +7 day grace

    return {
        "ok": True,
        "return_id": f"RET-{uuid.uuid4().hex[:8].upper()}",
        "order_id": order_id,
        "reason": reason,
        "days_since_delivery": days_since_delivery,
        "within_standard_window": within_window,
        "within_discretionary_window": within_discretionary_window,
        "amount": order["amount"],
        "status": "auto_approved" if within_window else "needs_discretion_review",
        "note": (
            "Within standard 30-day window; approved automatically."
            if within_window else
            "Outside standard window -- requires discretionary exception check "
            "(see return_policy.md) before final approval."
        ),
    }


def get_refund_policy() -> dict:
    """Shortcut tool: returns the refund policy document directly (equivalent to
    open_file('refund_policy.md')) -- included because it's a very common,
    predictable lookup worth a direct path rather than a search() round-trip."""
    return open_file("refund_policy.md")


def get_customer_history(customer_id: str) -> dict:
    """Mock customer-history API -- used for repeat-contact / abuse-pattern signals."""
    if not customer_id:
        return {"ok": False, "error": "customer_id is required."}
    hist = _CUSTOMERS.get(customer_id)
    if not hist:
        return {"ok": False, "error": f"No customer found with id {customer_id}."}
    return {"ok": True, "customer_id": customer_id, **hist}


# ------------------------------------------------------------- registry
TOOL_REGISTRY = {
    "search": search,
    "open_file": open_file,
    "read_chunk": read_chunk,
    "get_order_status": get_order_status,
    "create_return_request": create_return_request,
    "get_refund_policy": get_refund_policy,
    "get_customer_history": get_customer_history,
}

assert set(TOOL_REGISTRY) == config.ALLOWED_TOOLS, "TOOL_REGISTRY and config.ALLOWED_TOOLS must match exactly."


if __name__ == "__main__":
    print(get_order_status("ORD1004"))
    print(create_return_request("ORD1004", "changed my mind"))
    print(search("late return exception"))
    print(get_customer_history("CUST02"))
    print(get_order_status("bad-id"))
