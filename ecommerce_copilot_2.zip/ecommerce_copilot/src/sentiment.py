"""
Lightweight, explainable sentiment/urgency/frustration classifier.

Design note: this is intentionally a transparent, rule-based lexicon scorer
rather than a black-box model. For a de-escalation gate that decides whether
a customer gets escalated to a human, auditability matters more than a few
points of accuracy -- a support-ops reviewer can read exactly why a message
was scored "high frustration" here. The interface (`classify(text) ->
SentimentResult`) is written so it can be swapped for a fine-tuned
classifier or an LLM-based classifier later without touching callers.
"""
import re
from dataclasses import dataclass, field
from typing import List

from . import config

# Weighted lexicons. Keep these editable/auditable -- this *is* the model.
FRUSTRATION_LEXICON = {
    "ridiculous": 3, "terrible": 3, "worst": 3, "awful": 3, "horrible": 3,
    "scam": 4, "scammers": 4, "fraud": 4, "furious": 4, "unacceptable": 3,
    "disgusted": 3, "angry": 3, "annoyed": 2, "frustrated": 3, "frustrating": 3,
    "joke": 3, "useless": 3, "pathetic": 3, "sick of": 3, "fed up": 3,
    "never again": 3, "waste of time": 2, "waste of my time": 2,
    "not happy": 2, "unhappy": 2, "disappointed": 2, "lawyer": 4,
    "legal action": 4, "chargeback": 4, "sue": 4, "report you": 3,
    "third time": 3, "second time": 2, "again and again": 3, "keep telling": 2,
    "nothing happened": 2, "no one helped": 2, "still not": 1,
    "losing patience": 3, "lost patience": 3, "this better": 2, "better be fixed": 2,
    "not good enough": 2, "done with this": 3,
}
URGENCY_LEXICON = {
    "now": 2, "immediately": 3, "right now": 3, "asap": 3, "urgent": 3,
    "urgently": 3, "today": 1, "this instant": 3, "can't wait": 2,
}
POLITENESS_LEXICON = {
    "please": -1, "thank you": -1, "thanks": -1, "appreciate": -2,
    "kindly": -1, "no rush": -2, "understand": -1,
}

REPEAT_CONTACT_PATTERNS = [
    r"\bsecond time\b", r"\b2nd time\b", r"\bthird time\b", r"\b3rd time\b",
    r"\bagain\b.*\bcontact", r"\basked\b.*\bbefore\b",
    r"\bstill (not|no) (resolved|fixed|refunded)\b",
    r"\b\d+(st|nd|rd|th)\b\s+(order|time|message|email|request)",
]
LEGAL_THREAT_PATTERNS = [
    r"\blawyer\b", r"\bsue\b", r"\bsuing\b", r"\blegal action\b",
    r"\bchargeback\b", r"\breport (you|this) to\b", r"\bconsumer court\b",
]


@dataclass
class SentimentResult:
    frustration_score: float          # 0-10
    urgency_score: float              # 0-10
    frustration_level: str            # "low" | "medium" | "high"
    repeat_contact: bool
    legal_threat: bool
    explicit_human_request: bool
    matched_terms: List[str] = field(default_factory=list)

    def as_dict(self):
        return {
            "frustration_score": round(self.frustration_score, 2),
            "urgency_score": round(self.urgency_score, 2),
            "frustration_level": self.frustration_level,
            "repeat_contact": self.repeat_contact,
            "legal_threat": self.legal_threat,
            "explicit_human_request": self.explicit_human_request,
            "matched_terms": self.matched_terms,
        }


def _score_lexicon(text_lower: str, lexicon: dict, matched: list) -> float:
    score = 0.0
    for phrase, weight in lexicon.items():
        if phrase in text_lower:
            score += weight
            matched.append(f"{phrase}({weight:+d})")
    return score


def classify(text: str) -> SentimentResult:
    text_lower = text.lower()
    matched: List[str] = []

    frustration = _score_lexicon(text_lower, FRUSTRATION_LEXICON, matched)
    frustration += _score_lexicon(text_lower, POLITENESS_LEXICON, matched)
    urgency = _score_lexicon(text_lower, URGENCY_LEXICON, matched)

    # Punctuation / formatting signals
    exclamations = text.count("!")
    if exclamations >= 2:
        frustration += min(exclamations, 4)
        matched.append(f"exclamations(+{min(exclamations, 4)})")

    caps_words = re.findall(r"\b[A-Z]{3,}\b", text)
    if caps_words:
        bump = min(len(caps_words) * 2, 4)
        frustration += bump
        matched.append(f"ALL_CAPS:{caps_words}(+{bump})")

    repeat_contact = any(re.search(p, text_lower) for p in REPEAT_CONTACT_PATTERNS)
    if repeat_contact:
        frustration += 2
        matched.append("repeat_contact_pattern(+2)")

    legal_threat = any(re.search(p, text_lower) for p in LEGAL_THREAT_PATTERNS)
    explicit_human_request = bool(
        re.search(r"\b(human|real person|representative|agent)\b.*\b(talk|speak|connect)\b", text_lower)
        or re.search(r"\b(talk|speak|connect)\b.*\bhuman\b", text_lower)
    )

    frustration_score = max(0.0, min(10.0, frustration))
    urgency_score = max(0.0, min(10.0, urgency))

    if frustration_score >= config.FRUSTRATION_HIGH or legal_threat:
        level = "high"
    elif frustration_score >= config.FRUSTRATION_MEDIUM:
        level = "medium"
    else:
        level = "low"

    return SentimentResult(
        frustration_score=frustration_score,
        urgency_score=urgency_score,
        frustration_level=level,
        repeat_contact=repeat_contact,
        legal_threat=legal_threat,
        explicit_human_request=explicit_human_request,
        matched_terms=matched,
    )


if __name__ == "__main__":
    samples = [
        "Hi, can you tell me the status of my order?",
        "This is the SECOND time I'm messaging about this. I'm extremely frustrated, "
        "your app said delivered but I never got it and now no refund?! This is ridiculous.",
        "You people are scammers, I want a refund RIGHT NOW or I'm calling my bank for a chargeback.",
        "Quick question, please, when will refunds usually be processed? Thank you!",
    ]
    for s in samples:
        r = classify(s)
        print(f"\n> {s}\n  {r.as_dict()}")
