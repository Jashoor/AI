"""Standardized run logger -- every agent/baseline invocation is appended as
one row to a CSV, in a fixed schema, so eval/run_eval.py and the notebook can
both read/write the same log format (mirrors the requested runs_template.csv)."""
import csv
import os
from datetime import datetime

RUN_LOG_FIELDS = [
    "timestamp", "mode", "query_id", "query", "intent",
    "frustration_level", "num_steps", "tools_used",
    "escalated", "escalation_reasons", "citations", "answer", "stopped_reason",
]


def append_run_log(path: str, row: dict):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    file_exists = os.path.isfile(path)
    row = {**row}
    row.setdefault("timestamp", datetime.utcnow().isoformat())
    with open(path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=RUN_LOG_FIELDS)
        if not file_exists:
            writer.writeheader()
        writer.writerow({k: row.get(k, "") for k in RUN_LOG_FIELDS})
