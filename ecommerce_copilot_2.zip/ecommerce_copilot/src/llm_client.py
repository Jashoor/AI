"""
LLM abstraction layer.

Two backends behind one interface: `LLMClient.complete(system, user) -> str`

  - "mock"      : deterministic, fully offline template engine. This is the
                  default so the whole project (notebook, CLI, eval) runs
                  with zero API keys and zero network access -- useful for
                  grading/demoing without credentials.
  - "anthropic" : real Claude call via the `anthropic` python SDK, used when
                  ANTHROPIC_API_KEY is set (or an api_key is passed in
                  directly -- e.g. from the web UI) and
                  COPILOT_LLM_BACKEND=anthropic.

Swapping backends never touches agent.py / tools.py -- everything upstream
only calls `LLMClient.complete(...)`.

IMPORTANT ON GROUNDING: when backend="anthropic", the real model is given a
strict system prompt (see `GROUNDED_SYSTEM_PROMPT` below) instructing it to
answer using ONLY the evidence assembled by the ReAct loop (tool outputs +
retrieved policy chunks), to keep citations exactly as given, and to say so
honestly if the evidence doesn't fully cover the question -- rather than
inventing policy details or order numbers. The escalate/no-escalate decision
itself is still made by the deterministic rule-based gate in agent.py (kept
auditable); the LLM's job here is only to phrase a specific, well-grounded
answer to the customer's literal question and state the escalation decision
clearly, not to decide it.
"""
import os
import re
from . import config

GROUNDED_SYSTEM_PROMPT = """You are a customer support assistant for an e-commerce platform.

Answer the customer's exact question using ONLY the evidence provided below (retrieved policy
text and order/customer system lookups). Rules:
- Do not invent policy details, dates, amounts, or order information that isn't in the evidence.
- If the evidence only partially answers the question, say so honestly rather than filling gaps.
- Keep every citation tag (e.g. [file.md:L1-2] or [file.pdf:p3]) exactly as given in the evidence
  and place it right after the claim it supports. Do not fabricate new citation tags.
- Be concise (2-5 sentences) and directly address what the customer actually asked, in the order
  they asked it -- don't recite unrelated policy sections.
- If ESCALATE is true, state clearly, in one sentence, that this is being routed to a human agent
  and briefly why (using the given reasons) -- lead with the substantive answer first, then the
  escalation notice last.
- If the customer's message shows frustration (see FRUSTRATION_LEVEL), open with one brief,
  genuine, non-repetitive acknowledgment before the substantive answer. Do not repeat the
  acknowledgment or apologize more than once.
"""


class LLMClient:
    def __init__(self, backend: str = None, api_key: str = None, model: str = None):
        self.backend = backend or config.LLM_BACKEND
        self.model = model or config.ANTHROPIC_MODEL
        self._anthropic_client = None
        if self.backend == "anthropic":
            try:
                import anthropic
                self._anthropic_client = anthropic.Anthropic(api_key=api_key) if api_key else anthropic.Anthropic()
            except Exception as e:  # pragma: no cover - depends on env
                raise RuntimeError(
                    "COPILOT_LLM_BACKEND=anthropic requires the `anthropic` package "
                    f"and a valid API key (env ANTHROPIC_API_KEY or an explicit api_key). Error: {e}"
                )

    def complete(self, system: str, user: str, max_tokens: int = 700) -> str:
        if self.backend == "anthropic":
            resp = self._anthropic_client.messages.create(
                model=self.model,
                max_tokens=max_tokens,
                system=system,
                messages=[{"role": "user", "content": user}],
            )
            return "".join(b.text for b in resp.content if getattr(b, "type", None) == "text")
        return _mock_complete(system, user)

    def complete_grounded(self, evidence: str, question: str, frustration_level: str,
                           escalate: bool, escalation_reasons, max_tokens: int = 700) -> str:
        """High-level helper used by agent.py: builds the grounded prompt and calls complete()."""
        user = (
            f"EVIDENCE:\n{evidence or '(no evidence was found for this question)'}\n\n"
            f"CUSTOMER QUESTION (verbatim): {question}\n\n"
            f"FRUSTRATION_LEVEL: {frustration_level}\n"
            f"ESCALATE: {escalate}\n"
            f"ESCALATION_REASONS: {'; '.join(escalation_reasons) if escalation_reasons else '(none)'}\n"
        )
        return self.complete(GROUNDED_SYSTEM_PROMPT, user, max_tokens=max_tokens)


# --------------------------------------------------------------------------
# Mock backend: a small deterministic "reasoning" engine used for the ReAct
# planner step AND for final-answer synthesis, so the whole pipeline is
# demonstrable offline. It is intentionally simple (keyword/state-machine
# based) -- the point of this project is the AGENT ARCHITECTURE (tool
# selection, guardrails, citations, escalation gating), which is fully
# exercised regardless of which LLM produces the prose.
# --------------------------------------------------------------------------

import re as _re

# Ordered specific -> generic: the FIRST matching intent wins, so narrow /
# unambiguous patterns must come before broad catch-all ones (e.g. bare
# "arrive"/"shipped yet" would otherwise swallow cancellation, address-change,
# shipping-delay, and refund-dispute questions that merely mention shipping
# status as context rather than as the actual ask).
INTENT_PATTERNS = [
    ("account_deletion", [r"delete.*account", r"close.*account", r"account.*delet"]),
    ("cancellation", [r"\bcancel\b"]),
    ("address_change", [r"change.*(delivery )?address", r"update.*address"]),
    ("payment_issue", [r"charged twice", r"double charge", r"duplicate charge", r"payment failed", r"deducted"]),
    ("return_request", [r"\breturn (it|this|that|process)\b", r"\bcan i (still )?return\b", r"send (it |them )?back",
                         r"\bexchange\b", r"past the .*(window|30.day)", r"get an exception", r"\bexception\b"]),
    ("warranty_claim", [r"\bwarranty\b", r"\bdefect", r"stopped (working|heating|cooling)", r"not heating",
                         r"\bmalfunction", r"screen damage", r"accidental damage", r"protection plan cover"]),
    ("shipping_delay", [r"\bdays? late\b", r"\bdelayed\b"]),
    ("return_request", [r"\breturn(ing|ed)?\b"]),
    ("refund_dispute", [r"\brefund", r"never (got|arrived|received)", r"didn'?t receive", r"not received", r"money back"]),
    ("order_status", [r"\bstatus\b", r"where is my order", r"\btrack(ing)?\b", r"when will .* arrive"]),
    ("faq", [r"price match", r"payment methods?", r"data retention", r"\binvoice\b", r"how long",
             r"extended protection plan"]),
]


def classify_intent_mock(text: str) -> str:
    t = text.lower()
    for intent, patterns in INTENT_PATTERNS:
        if any(_re.search(p, t) for p in patterns):
            return intent
    return "faq"


def _mock_complete(system: str, user: str) -> str:
    """
    Extremely small deterministic responder used only as a fallback when the
    calling code (agent.py) hands it a fully-formed synthesis prompt
    (system explains the task, user contains retrieved evidence). We simply
    look for an EVIDENCE block and stitch a templated, cited answer.
    This keeps 100% of the interesting logic (tool orchestration, guardrails,
    citation enforcement) in agent.py where it's testable, not hidden inside
    a black-box "LLM".
    """
    m = re.search(r"EVIDENCE:\s*(.*?)\s*QUESTION:\s*(.*)", user, re.S)
    if not m:
        return "I don't have enough information to answer that yet."
    evidence, question = m.group(1).strip(), m.group(2).strip()
    if not evidence:
        return ("I looked, but couldn't find supporting information for that in our "
                "policy documents or order system. I'd recommend escalating this to a human agent.")
    return evidence  # agent.py has already assembled fully-cited prose; mock just passes it through
