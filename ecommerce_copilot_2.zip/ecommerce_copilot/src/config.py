"""
Central configuration for the e-commerce ReAct copilot.
Keeping every tunable in one place makes the guardrails auditable.
"""
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CORPUS_DIR = os.path.join(BASE_DIR, "corpus")
DATA_DIR = os.path.join(BASE_DIR, "data")
LOG_DIR = os.path.join(BASE_DIR, "eval", "logs")

ORDERS_PATH = os.path.join(DATA_DIR, "mock_orders.json")
CUSTOMERS_PATH = os.path.join(DATA_DIR, "mock_customers.json")
EVAL_QUESTIONS_PATH = os.path.join(DATA_DIR, "evaluation_questions.csv")

# --- Retrieval settings -----------------------------------------------------
CHUNK_SIZE_WORDS = 90          # ~ target words per chunk
CHUNK_OVERLAP_WORDS = 15
TOP_K = 4                      # chunks returned per search() call

# --- ReAct loop guardrails ---------------------------------------------------
MAX_STEPS = 6                  # hard cap on Reason->Act->Observe iterations
STEP_TIMEOUT_SECONDS = 8       # per-tool-call wall clock budget
MAX_TOOL_RETRIES = 2           # retries on malformed tool call / transient error

# Safe tool allow-list -- the agent may ONLY call tools in this set.
ALLOWED_TOOLS = {
    "search",
    "open_file",
    "read_chunk",
    "get_order_status",
    "create_return_request",
    "get_refund_policy",
    "get_customer_history",
}

# Tools that MUTATE state (create/modify records). These require an extra
# validation pass and are logged distinctly from read-only tools.
MUTATING_TOOLS = {"create_return_request"}

# --- De-escalation / sentiment thresholds -----------------------------------
# Scores are on a 0-10 scale produced by src/sentiment.py
FRUSTRATION_HIGH = 6
FRUSTRATION_MEDIUM = 3
URGENCY_HIGH = 6

# --- LLM backend --------------------------------------------------------
# "mock"  -> deterministic offline template engine (default, no API key needed)
# "anthropic" -> real Claude call via ANTHROPIC_API_KEY (network required)
LLM_BACKEND = os.environ.get("COPILOT_LLM_BACKEND", "mock")
ANTHROPIC_MODEL = os.environ.get("COPILOT_ANTHROPIC_MODEL", "claude-sonnet-5")
