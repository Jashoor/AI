"""
"LLM-only, no tools" baseline -- answers purely from parametric/mock
knowledge, with NO retrieval and NO tool calls. This exists specifically to
be compared against the ReAct+tools agent in the evaluation report, to
demonstrate the value of grounding.

Because this project runs offline-by-default (see llm_client.py), the mock
baseline is deliberately built to mimic the realistic failure modes of a
no-context LLM baseline: plausible-sounding, ungrounded, sometimes wrong on
specifics (exact day thresholds, order state, existence of a discretionary
exception), and -- critically -- it NEVER produces a real [file:...] citation,
because it never looked anything up. Any "citation-shaped" text it emits is
flagged as a hallucinated citation by the evaluator.
"""
import re
from dataclasses import dataclass, field
from typing import List

from .llm_client import classify_intent_mock
from . import sentiment

# Generic, ungrounded "policy knowledge" a base LLM might plausibly guess.
# Intentionally slightly wrong / oversimplified in places vs. the real policy
# corpus, to mirror realistic hallucination without being a strawman.
GENERIC_ANSWERS = {
    "order_status": "I don't have access to live order tracking, but typically orders update within a "
                     "few business days of shipping. You may want to check your account's order history page.",
    "return_request": "Most e-commerce platforms allow returns within about 30 days of delivery, as long as the "
                       "item is unused and in original packaging. If you're past that window, some retailers make "
                       "exceptions on a case-by-case basis, so it's worth asking. [general return policy]",
    "refund_dispute": "If your package shows as delivered but you didn't receive it, this is usually treated as a "
                       "lost package and most retailers will issue a refund or replacement after a short investigation.",
    "cancellation": "Orders can usually be cancelled for free as long as they haven't shipped yet. Once shipped, "
                     "you'd typically need to do a return instead.",
    "warranty_claim": "Most electronics come with a manufacturer warranty of about a year. If you bought an "
                       "extended warranty or protection plan, that would typically extend coverage further.",
    "payment_issue": "Duplicate charges are usually a temporary authorization hold that resolves itself within a "
                      "few business days. If it doesn't resolve, your bank or the merchant's payments team can help.",
    "shipping_delay": "A shipment that's a few days late is usually still within normal variance, but if it's "
                       "significantly delayed you may be entitled to a refund or expedited reshipping, depending "
                       "on the retailer's policy.",
    "address_change": "Address changes are typically possible only before an order ships. Once it's shipped, most "
                       "retailers can't redirect it.",
    "account_deletion": "You can usually delete your account from account settings, or by contacting support "
                         "directly; it may take a few business days to process.",
    "faq": "I don't have specific information on that, but I'd recommend checking the help center or FAQ page "
           "for the most accurate answer.",
}


@dataclass
class BaselineResult:
    query: str
    intent: str
    answer: str
    citations: List[str] = field(default_factory=list)
    hallucinated_citation_like_text: bool = False


CITATION_LIKE_PATTERN = re.compile(r"\[[^\]]+\]")


def run_baseline(query: str, order_id: str = None, customer_id: str = None) -> BaselineResult:
    intent = classify_intent_mock(query)
    answer = GENERIC_ANSWERS.get(intent, GENERIC_ANSWERS["faq"])

    # A no-tools baseline has no de-escalation gate at all -- it answers the
    # literal question regardless of tone. This is the exact failure mode
    # objective #1 of this project is designed to catch.
    if order_id:
        answer = answer.replace("your account's", f"order {order_id}'s")

    citation_like = CITATION_LIKE_PATTERN.findall(answer)
    # Real citations look like [file.md:L1-2] or [file.pdf:p3]; anything else
    # that merely *looks* like a citation (e.g. "[general return policy]")
    # is flagged as a hallucinated/unverifiable citation.
    real_citation_pattern = re.compile(r"^\[[\w\-.]+\.(md|txt|pdf):(p\d+|L\d+-\d+)\]$")
    hallucinated = any(not real_citation_pattern.match(c) for c in citation_like)

    return BaselineResult(
        query=query, intent=intent, answer=answer,
        citations=[c for c in citation_like if real_citation_pattern.match(c)],
        hallucinated_citation_like_text=hallucinated,
    )
