#!/usr/bin/env python3
"""
CLI for the e-commerce ReAct support copilot.

Usage:
    python react_copilot.py --question "Where is my order ORD1001?" --order-id ORD1001 --customer-id CUST01
    python react_copilot.py --question "I want a refund, this is ridiculous!" --order-id ORD1005 --customer-id CUST05
    python react_copilot.py --interactive
    python react_copilot.py --question "..." --baseline     # run the no-tools baseline instead

Prints:
  - step-by-step Action/Observation trace
  - sentiment/escalation gate decision
  - final answer with inline citations
"""
import argparse
import json
import sys

from src.agent import ReactAgent
from src.baseline import run_baseline
from src.logging_utils import append_run_log
from src import config
import os


def print_react_trace(result):
    print("\n" + "=" * 78)
    print(f"QUERY: {result.query}")
    print(f"Detected intent: {result.intent}")
    print(f"Sentiment: frustration={result.sentiment['frustration_level']} "
          f"(score={result.sentiment['frustration_score']}), urgency={result.sentiment['urgency_score']}, "
          f"repeat_contact={result.sentiment['repeat_contact']}, legal_threat={result.sentiment['legal_threat']}")
    print("-" * 78)
    if not result.steps:
        print("(no tool calls -- planner finished immediately)")
    for s in result.steps:
        print(f"[Step {s.step_no}] THOUGHT: {s.thought}")
        print(f"           ACTION:      {s.action}({json.dumps(s.action_input)})")
        obs_preview = {k: v for k, v in s.observation.items() if k != "_latency_ms"}
        print(f"           OBSERVATION: {json.dumps(obs_preview, default=str)[:400]}")
        print(f"           (latency: {s.latency_ms:.1f}ms, retries: {s.retries})")
    print("-" * 78)
    print(f"ESCALATED TO HUMAN: {result.escalated}")
    if result.escalation_reasons:
        for r in result.escalation_reasons:
            print(f"  - {r}")
    print("-" * 78)
    print("FINAL ANSWER:")
    print(result.answer)
    print(f"\nCitations: {result.citations if result.citations else '(none)'}")
    print(f"Stopped reason: {result.stopped_reason}")
    print("=" * 78 + "\n")


def print_baseline_trace(result):
    print("\n" + "=" * 78)
    print(f"[NO-TOOLS BASELINE] QUERY: {result.query}")
    print(f"Detected intent: {result.intent}")
    print("-" * 78)
    print("ANSWER (no retrieval, no tools, no escalation gate):")
    print(result.answer)
    print(f"\nReal citations: {result.citations if result.citations else '(none)'}")
    print(f"Hallucinated / unverifiable citation-like text: {result.hallucinated_citation_like_text}")
    print("=" * 78 + "\n")


def run_one(question, order_id, customer_id, baseline, log_path=None):
    if baseline:
        result = run_baseline(question, order_id=order_id, customer_id=customer_id)
        print_baseline_trace(result)
        if log_path:
            append_run_log(log_path, {
                "mode": "baseline", "query_id": "", "query": result.query, "intent": result.intent,
                "frustration_level": "", "num_steps": 0, "tools_used": "",
                "escalated": False, "escalation_reasons": "",
                "citations": ",".join(result.citations), "answer": result.answer,
                "stopped_reason": "n/a",
            })
    else:
        agent = ReactAgent()
        result = agent.run(question, order_id=order_id, customer_id=customer_id)
        print_react_trace(result)
        if log_path:
            row = result.to_log_row()
            row["mode"] = "react_tools"
            row["query_id"] = ""
            append_run_log(log_path, row)


def main():
    parser = argparse.ArgumentParser(description="E-commerce ReAct support copilot")
    parser.add_argument("--question", type=str, help="Customer question to answer")
    parser.add_argument("--order-id", type=str, default=None, help="Order ID context, e.g. ORD1001")
    parser.add_argument("--customer-id", type=str, default=None, help="Customer ID context, e.g. CUST01")
    parser.add_argument("--baseline", action="store_true", help="Run the no-tools LLM-only baseline instead of ReAct+tools")
    parser.add_argument("--interactive", action="store_true", help="Start an interactive REPL session")
    parser.add_argument("--log", type=str, default=os.path.join(config.LOG_DIR, "cli_runs.csv"),
                         help="Path to append a run-log CSV row to")
    parser.add_argument("--no-log", action="store_true", help="Disable run logging")
    args = parser.parse_args()

    log_path = None if args.no_log else args.log

    if args.interactive:
        print("E-commerce ReAct Copilot -- interactive mode. Type 'quit' to exit.")
        print("Optionally prefix with order/customer context, e.g.:")
        print('  order=ORD1001 customer=CUST01 :: Where is my order?\n')
        while True:
            try:
                raw = input("you> ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if raw.lower() in {"quit", "exit"}:
                break
            if not raw:
                continue
            order_id, customer_id, question = None, None, raw
            if "::" in raw:
                prefix, question = raw.split("::", 1)
                for tok in prefix.split():
                    if tok.startswith("order="):
                        order_id = tok.split("=", 1)[1]
                    elif tok.startswith("customer="):
                        customer_id = tok.split("=", 1)[1]
                question = question.strip()
            run_one(question, order_id, customer_id, args.baseline, log_path)
        return

    if not args.question:
        parser.error("--question is required unless --interactive is set")

    run_one(args.question, args.order_id, args.customer_id, args.baseline, log_path)


if __name__ == "__main__":
    main()
