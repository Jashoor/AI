"""
Central configuration. Everything is env-driven so switching LLM backends
or retrieval modes never requires touching code — just `.env`.
"""
import os
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    # python-dotenv is optional; env vars can still be set by the shell.
    pass

ROOT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT_DIR / "data"
FAQ_EN_PATH = DATA_DIR / "faqs" / "faqs_en.json"
FAQ_TA_PATH = DATA_DIR / "faqs" / "faqs_ta.json"
POLICIES_DIR = DATA_DIR / "policies"
ORDERS_DB_PATH = DATA_DIR / "orders_db.json"
RETURNS_DB_PATH = DATA_DIR / "returns_db.json"
INDEX_DIR = ROOT_DIR / "index_store"

# ---- LLM backend ----
LLM_BACKEND = os.environ.get("LLM_BACKEND", "mock").strip().lower()
OLLAMA_HOST = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "qwen2.5:7b")
GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "")
GROQ_MODEL = os.environ.get("GROQ_MODEL", "llama-3.1-8b-instant")

# ---- RAG ----
RETRIEVAL_MODE = os.environ.get("RETRIEVAL_MODE", "bilingual").strip().lower()
assert RETRIEVAL_MODE in ("en_only", "bilingual"), \
    "RETRIEVAL_MODE must be 'en_only' or 'bilingual'"
EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "intfloat/multilingual-e5-base")
TOP_K = int(os.environ.get("TOP_K", "3"))
MIN_SIMILARITY = float(os.environ.get("MIN_SIMILARITY", "0.55"))

# ---- Logging / eval ----
LOG_DIR = ROOT_DIR / os.environ.get("LOG_DIR", "eval/conversation_logs")
EVAL_RESULTS_PATH = ROOT_DIR / "eval" / "eval_results.csv"
SYNTHETIC_QUERIES_PATH = DATA_DIR / "synthetic_queries.csv"

LOG_DIR.mkdir(parents=True, exist_ok=True)
INDEX_DIR.mkdir(parents=True, exist_ok=True)

# ---- Safety / escalation keyword triggers (checked in both en + ta scripts) ----
FRAUD_KEYWORDS = [
    "fraud", "unauthorized", "chargeback", "stolen card", "hacked",
    "மோசடி", "அங்கீகரிக்கப்படாத", "திருடப்பட்ட",
]
LEGAL_KEYWORDS = [
    "lawsuit", "legal action", "sue you", "court", "consumer forum",
    "வழக்கு", "நீதிமன்றம்",
]
HUMAN_REQUEST_KEYWORDS = [
    "human agent", "real person", "talk to a human", "speak to a person",
    "மனிதர்", "ஏஜென்ட்",
]
