"""
Loads the knowledge base into a uniform list of records:
    {"doc_id": str, "source": str, "lang": "en"|"ta", "title": str, "text": str}

`doc_id` is the shared key linking an English FAQ to its Tamil parallel
version (e.g. "FAQ001" in both faqs_en.json and faqs_ta.json), and linking
both back to the same citation target.

Policy markdown files are chunked by "## " headings (English only — they are
the canonical source of truth, per project scope).
"""
import json
import re

from src import config


def load_faqs() -> list[dict]:
    with open(config.FAQ_EN_PATH, encoding="utf-8") as f:
        en_faqs = json.load(f)
    with open(config.FAQ_TA_PATH, encoding="utf-8") as f:
        ta_faqs = json.load(f)

    records = []
    for item in en_faqs:
        records.append({
            "doc_id": item["doc_id"],
            "source": item["source"],
            "lang": "en",
            "title": item["title"],
            "text": item["text"],
        })
    for item in ta_faqs:
        records.append({
            "doc_id": item["doc_id"],
            "source": item["source"],  # points to the English source, by design
            "lang": "ta",
            "title": item["title"],
            "text": item["text"],
        })
    return records


def _chunk_markdown(md_text: str, doc_id: str, filename: str) -> list[dict]:
    """Split a policy markdown file into chunks on '## ' headings."""
    sections = re.split(r"\n(?=## )", md_text)
    chunks = []
    for i, section in enumerate(sections):
        section = section.strip()
        if not section or section.startswith("# "):
            # Keep the top title line attached to the first real section instead
            # of emitting it as its own near-empty chunk.
            continue
        title_match = re.match(r"##\s+(.+)", section)
        title = title_match.group(1).strip() if title_match else f"{filename} part {i}"
        chunks.append({
            "doc_id": f"{doc_id}#{i}",
            "source": doc_id,
            "lang": "en",
            "title": title,
            "text": section,
        })
    return chunks


def load_policies() -> list[dict]:
    records = []
    for path in sorted(config.POLICIES_DIR.glob("*.md")):
        text = path.read_text(encoding="utf-8")
        doc_id_match = re.search(r"Document ID:\s*(\S+)", text)
        doc_id = doc_id_match.group(1) if doc_id_match else path.stem.upper()
        records.extend(_chunk_markdown(text, doc_id, path.name))
    return records


def load_all_documents() -> list[dict]:
    return load_faqs() + load_policies()
