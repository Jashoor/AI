"""
Thin wrapper around a free, open-source multilingual embedding model that
puts English and Tamil (and 100+ other languages) into a **shared vector
space** — this is what makes cross-lingual retrieval possible: a Tamil
query can retrieve an English-only passage by meaning, without any
translation step.

Model: intfloat/multilingual-e5-base (free, Apache-2.0, runs on CPU).
E5 models expect "query: " / "passage: " prefixes for best retrieval
quality — see the model card. We apply that convention here.
"""
from functools import lru_cache

import numpy as np

from src import config


@lru_cache(maxsize=1)
def _get_model():
    # Imported lazily so that modules which don't need embeddings (e.g. the
    # mock-only CLI smoke tests) don't pay the import/download cost.
    from sentence_transformers import SentenceTransformer
    return SentenceTransformer(config.EMBEDDING_MODEL)


def embed_passages(texts: list[str]) -> np.ndarray:
    model = _get_model()
    prefixed = [f"passage: {t}" for t in texts]
    vecs = model.encode(prefixed, normalize_embeddings=True, show_progress_bar=False)
    return np.asarray(vecs, dtype="float32")


def embed_query(text: str) -> np.ndarray:
    model = _get_model()
    vec = model.encode([f"query: {text}"], normalize_embeddings=True, show_progress_bar=False)
    return np.asarray(vec, dtype="float32")[0]
