"""
Loads a prebuilt FAISS index (see build_index.py) and performs top-k
cross-lingual similarity search.
"""
import pickle
from functools import lru_cache

import faiss

from src import config
from src.rag.embed import embed_query


@lru_cache(maxsize=4)
def _load_index(mode: str):
    index_path = config.INDEX_DIR / f"{mode}.faiss"
    meta_path = config.INDEX_DIR / f"{mode}_meta.pkl"
    if not index_path.exists() or not meta_path.exists():
        raise FileNotFoundError(
            f"No index found for mode='{mode}'. Run `python -m src.rag.build_index` first."
        )
    index = faiss.read_index(str(index_path))
    with open(meta_path, "rb") as f:
        docs = pickle.load(f)
    return index, docs


class Retriever:
    def __init__(self, mode: str | None = None, top_k: int | None = None,
                 min_similarity: float | None = None):
        self.mode = mode or config.RETRIEVAL_MODE
        self.top_k = top_k or config.TOP_K
        self.min_similarity = min_similarity if min_similarity is not None else config.MIN_SIMILARITY
        self.index, self.docs = _load_index(self.mode)

    def retrieve(self, query: str, top_k: int | None = None) -> list[dict]:
        k = top_k or self.top_k
        qvec = embed_query(query).reshape(1, -1)
        scores, indices = self.index.search(qvec, k)

        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx == -1:
                continue
            doc = dict(self.docs[idx])
            doc["score"] = float(score)
            results.append(doc)

        return results

    def retrieve_above_threshold(self, query: str, top_k: int | None = None) -> list[dict]:
        """Only return chunks whose similarity clears MIN_SIMILARITY —
        used to decide whether the assistant has enough grounding to answer
        or should honestly say it doesn't know / escalate."""
        return [r for r in self.retrieve(query, top_k) if r["score"] >= self.min_similarity]
