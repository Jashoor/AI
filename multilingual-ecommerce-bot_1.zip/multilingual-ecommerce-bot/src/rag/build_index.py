"""
Builds two FAISS indexes so the eval can compare retrieval quality between:

  - "en_only"   : only English documents indexed. Tamil / code-switched
                  queries must rely purely on cross-lingual embedding
                  similarity against English text.
  - "bilingual" : English documents + the parallel Tamil FAQ text are both
                  indexed (same doc_id, same citation target). This is the
                  practical "assisted" setup most real deployments would
                  actually ship.

Run: `python -m src.rag.build_index`
"""
import json
import pickle

import faiss
import numpy as np

from src import config
from src.rag.loader import load_all_documents
from src.rag.embed import embed_passages


def build_and_save():
    all_docs = load_all_documents()
    print(f"Loaded {len(all_docs)} total chunks "
          f"({sum(1 for d in all_docs if d['lang'] == 'en')} en, "
          f"{sum(1 for d in all_docs if d['lang'] == 'ta')} ta)")

    modes = {
        "en_only": [d for d in all_docs if d["lang"] == "en"],
        "bilingual": all_docs,
    }

    for mode_name, docs in modes.items():
        texts = [d["text"] for d in docs]
        print(f"[{mode_name}] embedding {len(texts)} chunks with {config.EMBEDDING_MODEL} ...")
        vectors = embed_passages(texts)  # (N, D) float32, L2-normalized

        dim = vectors.shape[1]
        index = faiss.IndexFlatIP(dim)  # inner product == cosine sim (vectors normalized)
        index.add(vectors)

        index_path = config.INDEX_DIR / f"{mode_name}.faiss"
        meta_path = config.INDEX_DIR / f"{mode_name}_meta.pkl"

        faiss.write_index(index, str(index_path))
        with open(meta_path, "wb") as f:
            pickle.dump(docs, f)

        print(f"[{mode_name}] saved index -> {index_path} ({index.ntotal} vectors)")

    print("Done. You can now run the CLI/UI or `python -m src.eval.run_eval`.")


if __name__ == "__main__":
    build_and_save()
