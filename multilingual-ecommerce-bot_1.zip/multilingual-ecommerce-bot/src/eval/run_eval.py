"""
Runs every row of data/synthetic_queries.csv through the full pipeline
under BOTH retrieval modes (en_only, bilingual), writes a detailed CSV of
per-query results to eval/eval_results.csv, and prints a metrics summary
covering:

  - Retrieval Recall@k / MRR per query language, per retrieval mode
    (the core "retrieval-quality drop across languages" eval angle)
  - Heuristic translation-induced hallucination rate on RAG-routed answers
  - Escalation precision/recall on the sensitive-query subset

Run: `python -m src.eval.run_eval`
"""
import csv
import json

from src import config
from src.agent.orchestrator import Orchestrator
from src.eval.metrics import (
    compute_retrieval_metrics,
    compute_escalation_metrics,
    check_numeric_hallucination,
)


def load_synthetic_queries() -> list[dict]:
    with open(config.SYNTHETIC_QUERIES_PATH, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def run_for_mode(mode: str, queries: list[dict]) -> list[dict]:
    print(f"\n{'=' * 60}\nRunning eval with RETRIEVAL_MODE={mode}\n{'=' * 60}")
    orchestrator = Orchestrator(retrieval_mode=mode)
    rows = []

    for q in queries:
        # Each query is an independent single-turn session for eval purposes,
        # so results are not affected by conversation history / clarification state.
        orchestrator.unclear_streak = 0
        orchestrator.history = []
        result = orchestrator.handle_message(q["text"])

        source_texts = [c["text"] for c in result.retrieved_chunks]
        halluc = check_numeric_hallucination(result.final_answer, source_texts) \
            if result.route == "rag" else None

        rows.append({
            "query_id": q["query_id"],
            "text": q["text"],
            "gold_language": q["language"],
            "gold_code_switch": q["code_switch"],
            "gold_intent": q["intent"],
            "gold_expected_doc_ids": q["expected_doc_ids"],
            "retrieval_mode": mode,
            "detected_language": result.detected_language["language"],
            "predicted_intent": result.intent,
            "confidence": result.confidence,
            "route": result.route,
            "tool_name": result.tool_name,
            "escalated": result.escalated,
            "escalation_reason": result.escalation_reason,
            "retrieved_chunks": result.retrieved_chunks,
            "final_answer": result.final_answer,
            "potential_hallucination": halluc["potential_hallucination"] if halluc else None,
            "unsupported_numbers": halluc["unsupported_numbers"] if halluc else None,
        })
    return rows


def write_results_csv(all_rows: list[dict]):
    config.EVAL_RESULTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "query_id", "text", "gold_language", "gold_code_switch", "gold_intent",
        "gold_expected_doc_ids", "retrieval_mode", "detected_language",
        "predicted_intent", "confidence", "route", "tool_name", "escalated",
        "escalation_reason", "retrieved_sources", "final_answer",
        "potential_hallucination", "unsupported_numbers",
    ]
    with open(config.EVAL_RESULTS_PATH, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in all_rows:
            sources = ";".join(sorted({c["source"] for c in row["retrieved_chunks"]}))
            writer.writerow({
                "query_id": row["query_id"],
                "text": row["text"],
                "gold_language": row["gold_language"],
                "gold_code_switch": row["gold_code_switch"],
                "gold_intent": row["gold_intent"],
                "gold_expected_doc_ids": row["gold_expected_doc_ids"],
                "retrieval_mode": row["retrieval_mode"],
                "detected_language": row["detected_language"],
                "predicted_intent": row["predicted_intent"],
                "confidence": row["confidence"],
                "route": row["route"],
                "tool_name": row["tool_name"],
                "escalated": row["escalated"],
                "escalation_reason": row["escalation_reason"],
                "retrieved_sources": sources,
                "final_answer": row["final_answer"],
                "potential_hallucination": row["potential_hallucination"],
                "unsupported_numbers": json.dumps(row["unsupported_numbers"], ensure_ascii=False)
                    if row["unsupported_numbers"] else "",
            })
    print(f"\nWrote detailed per-query results -> {config.EVAL_RESULTS_PATH}")


def print_summary(mode: str, rows: list[dict]):
    retrieval_input = [
        {
            "language": r["gold_language"],
            "expected_doc_ids": r["gold_expected_doc_ids"],
            "retrieved_chunks": r["retrieved_chunks"],
        }
        for r in rows
    ]
    retrieval_summary = compute_retrieval_metrics(retrieval_input)

    print(f"\n--- Retrieval quality (mode={mode}) ---")
    print(f"{'language':<8} {'n':>4} {'recall@k':>10} {'mrr':>8}")
    for lang in ("en", "ta", "ta-en"):
        if lang in retrieval_summary:
            s = retrieval_summary[lang]
            print(f"{lang:<8} {s['n_queries']:>4} {s['recall_at_k']:>10.3f} {s['mrr']:>8.3f}")

    if "en" in retrieval_summary and "ta" in retrieval_summary:
        drop = retrieval_summary["en"]["recall_at_k"] - retrieval_summary["ta"]["recall_at_k"]
        print(f"\n  Retrieval-quality drop (en recall@k - ta recall@k): {drop:+.3f}")
    if "en" in retrieval_summary and "ta-en" in retrieval_summary:
        drop = retrieval_summary["en"]["recall_at_k"] - retrieval_summary["ta-en"]["recall_at_k"]
        print(f"  Retrieval-quality drop (en recall@k - ta-en recall@k): {drop:+.3f}")

    rag_rows = [r for r in rows if r["route"] == "rag"]
    halluc_flagged = [r for r in rag_rows if r["potential_hallucination"]]
    rate = len(halluc_flagged) / len(rag_rows) if rag_rows else 0.0
    print(f"\n--- Heuristic translation/generation hallucination rate (mode={mode}) ---")
    print(f"  {len(halluc_flagged)}/{len(rag_rows)} RAG-routed answers flagged "
          f"({rate:.1%})")

    escalation_input = [
        {"gold_intent": r["gold_intent"], "escalated": r["escalated"]}
        for r in rows
    ]
    esc_metrics = compute_escalation_metrics(escalation_input)
    print(f"\n--- Escalation guardrail (mode={mode}) ---")
    print(f"  precision={esc_metrics['precision']} recall={esc_metrics['recall']} "
          f"(tp={esc_metrics['true_positive']} fp={esc_metrics['false_positive']} "
          f"fn={esc_metrics['false_negative']} tn={esc_metrics['true_negative']})")


def main():
    queries = load_synthetic_queries()
    all_rows = []
    for mode in ("en_only", "bilingual"):
        rows = run_for_mode(mode, queries)
        all_rows.extend(rows)
        print_summary(mode, rows)

    write_results_csv(all_rows)
    print("\nDone. See docs/technical_report.md for discussion of these results.")


if __name__ == "__main__":
    main()
