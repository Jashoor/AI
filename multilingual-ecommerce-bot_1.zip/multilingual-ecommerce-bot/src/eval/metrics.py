"""
Evaluation metrics for the two headline "eval angle" questions in the
project brief:

  1. Retrieval-quality drop across languages
     -> Recall@k and MRR, computed per query language, per retrieval mode.

  2. Translation-induced hallucination rate
     -> A heuristic faithfulness check: for RAG-routed answers, does the
        final generated answer contain numbers/entities (day counts, rupee
        amounts) that are NOT present in the retrieved source chunk(s) it
        cited? This won't catch every hallucination, but numeric/entity
        drift is exactly the failure mode most likely to appear when an
        LLM "translates while answering" — e.g. turning "7 days" into
        "10 days" while producing fluent Tamil.
"""
import re
from collections import defaultdict


def _expected_doc_ids(expected_str: str) -> set[str]:
    if not expected_str or (isinstance(expected_str, float)):
        return set()
    return {d.strip() for d in str(expected_str).split(";") if d.strip()}


def retrieval_hit_rank(retrieved_chunks: list[dict], expected_doc_ids: set[str]) -> int | None:
    """
    Returns the 1-indexed rank of the first retrieved chunk whose `source`
    (canonical doc id, e.g. "FAQ001" or "POLICY_RETURN_01") is in the
    expected set, or None if no retrieved chunk matches.
    """
    for rank, chunk in enumerate(retrieved_chunks, start=1):
        if chunk["source"] in expected_doc_ids:
            return rank
    return None


def compute_retrieval_metrics(eval_rows: list[dict]) -> dict:
    """
    eval_rows: list of dicts with keys
        language, expected_doc_ids (raw string), retrieved_chunks (list[dict])
    Returns per-language Recall@k and MRR, plus an overall summary.
    """
    by_language = defaultdict(list)  # language -> list of ranks (or None)

    for row in eval_rows:
        expected = _expected_doc_ids(row.get("expected_doc_ids", ""))
        if not expected:
            continue  # not a retrieval-eval row (e.g. tool-only or escalation row)
        rank = retrieval_hit_rank(row["retrieved_chunks"], expected)
        by_language[row["language"]].append(rank)

    summary = {}
    for lang, ranks in by_language.items():
        n = len(ranks)
        hits = [r for r in ranks if r is not None]
        recall_at_k = len(hits) / n if n else 0.0
        mrr = sum(1.0 / r for r in hits) / n if n else 0.0
        summary[lang] = {
            "n_queries": n,
            "recall_at_k": round(recall_at_k, 3),
            "mrr": round(mrr, 3),
        }
    return summary


_NUMBER_RE = re.compile(r"\d+(?:[.,]\d+)?\s?%?")


def extract_numbers(text: str) -> set[str]:
    return set(_NUMBER_RE.findall(text or ""))


def check_numeric_hallucination(final_answer: str, source_texts: list[str]) -> dict:
    """
    Heuristic faithfulness check: every number mentioned in the final
    answer should also appear somewhere in the concatenated source text
    that was given to the model as grounding. Numbers that appear in the
    answer but nowhere in the source are flagged as potential
    translation/generation-induced hallucinations.

    This intentionally ignores numbers that are part of the order ID itself
    (e.g. "ORD1001") since those are correctly echoed identifiers, not
    invented facts.
    """
    answer_wo_ids = re.sub(r"\bORD\d+\b", "", final_answer, flags=re.IGNORECASE)
    answer_numbers = extract_numbers(answer_wo_ids)
    source_numbers = set()
    for t in source_texts:
        source_numbers |= extract_numbers(t)

    unsupported = answer_numbers - source_numbers
    return {
        "answer_numbers": sorted(answer_numbers),
        "source_numbers": sorted(source_numbers),
        "unsupported_numbers": sorted(unsupported),
        "potential_hallucination": len(unsupported) > 0,
    }


def compute_escalation_metrics(eval_rows: list[dict]) -> dict:
    """
    Precision/recall for escalation on rows labeled with an
    "escalate_fraud" / "escalate_other" / "unclear" intent in the gold
    labels vs. whether the pipeline actually escalated.
    """
    gold_positive_intents = {"escalate_fraud", "escalate_other"}

    tp = fp = fn = tn = 0
    for row in eval_rows:
        gold_should_escalate = row["gold_intent"] in gold_positive_intents
        did_escalate = row["escalated"]
        if gold_should_escalate and did_escalate:
            tp += 1
        elif gold_should_escalate and not did_escalate:
            fn += 1
        elif not gold_should_escalate and did_escalate:
            fp += 1
        else:
            tn += 1

    precision = tp / (tp + fp) if (tp + fp) else None
    recall = tp / (tp + fn) if (tp + fn) else None
    return {
        "true_positive": tp, "false_positive": fp,
        "false_negative": fn, "true_negative": tn,
        "precision": round(precision, 3) if precision is not None else None,
        "recall": round(recall, 3) if recall is not None else None,
    }
