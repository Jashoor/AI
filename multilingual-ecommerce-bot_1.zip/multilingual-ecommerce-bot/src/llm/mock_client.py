"""
MockLLMClient: a completely free, offline, zero-dependency stand-in for a
real generative LLM.

Why this exists: the assignment requires the whole pipeline to be runnable
with $0 cost and no external services. This backend guarantees that — no
API key, no local model download, no internet connection needed at
inference time (only the one-time embedding-model download for RAG still
needs internet; see README).

Design choice worth noting in the technical report: this backend
deliberately does NOT attempt to machine-translate retrieved English policy
text into Tamil on the fly, because a template engine doing that would
either (a) need a translation model (defeating "zero dependency"), or
(b) fabricate fluent-sounding Tamil that silently drifts from the source —
exactly the "translation-induced hallucination" failure mode this project
is trying to measure, not commit. Instead:
  - In `bilingual` retrieval mode, the retriever already returns the
    Tamil-native FAQ chunk (see src/rag/retriever.py), so the mock backend
    can present it directly in the customer's language, safely.
  - In `en_only` mode, for a Tamil-language customer, the mock backend is
    honest about the limitation: it gives a short Tamil framing sentence
    and presents the English source text plainly labeled, rather than
    inventing a translation. Swap in `ollama` or `groq` for real, fluent,
    LLM-generated Tamil answers (with the hallucination-rate trade-off
    measured in eval).
"""
import re
import json

from src.llm.base import BaseLLMClient
from src.agent.language_detect import detect_language

_ORDER_ID_RE = re.compile(r"\bORD\d+\b", re.IGNORECASE)

_INTENT_KEYWORDS = {
    "escalate_fraud": [
        "fraud", "unauthorized", "chargeback", "stolen card", "hacked",
        "மோசடி", "அங்கீகரிக்கப்படாத",
    ],
    "escalate_other": [
        "lawsuit", "legal action", "sue", "court", "consumer forum",
        "human agent", "real person", "real human",
        "வழக்கு", "நீதிமன்றம்", "மனிதர்",
    ],
    "order_status": [
        "where is my order", "order status", "track", "order eppo varum",
        "order-a epadi track", "status enna", "எங்கே இருக்கு", "நிலை என்ன",
        "ஆர்டரை.*டிராக்",
    ],
    # Deliberately action-phrase specific (not bare "return"/"cancel") so a
    # question like "what is your return policy" isn't misrouted here —
    # see faq_general below, which owns bare policy questions.
    "return_request": [
        "i want to return", "want to return", "return this", "return the",
        "return my", "cancel my order", "cancel the order", "cancel this order",
        "ரத்து செய்ய", "திரும்ப கொடுக்க", "return pannanum", "cancel pannanum",
        "return panna", "cancel panna",
    ],
    "refund_policy": [
        "refund", "money back", "பணம் திரும்ப", "பணத்திரும்ப", "refund eppo",
    ],
    "payment_info": [
        "payment method", "cod", "cash on delivery", "பணம் செலுத்தும் முறை",
        "payment methods use",
    ],
    "faq_general": [
        "policy", "shipping", "delivery time", "damaged", "wrong item",
        "international", "address", "கொள்கை", "டெலிவரி", "பழுதடைந்த",
        "வெளிநாடு", "முகவரி", "return policy", "cancel.*before",
    ],
}


def _keyword_intent(text_lower: str) -> tuple[str, float]:
    # Escalation keywords take priority over everything else.
    for intent in ("escalate_fraud", "escalate_other"):
        for kw in _INTENT_KEYWORDS[intent]:
            if re.search(kw, text_lower):
                return intent, 0.95

    # "policy" is a strong, unambiguous signal that this is an
    # informational FAQ question, not an action request — check it before
    # the more generic keyword-count race so "return policy" / "cancel
    # policy" style questions never get misrouted into return_request.
    if re.search(r"\bpolicy\b|கொள்கை", text_lower):
        return "faq_general", 0.85

    best_intent, best_score = "unclear", 0.0
    for intent, keywords in _INTENT_KEYWORDS.items():
        if intent in ("escalate_fraud", "escalate_other"):
            continue
        hits = sum(1 for kw in keywords if re.search(kw, text_lower))
        if hits > best_score:
            best_score = hits
            best_intent = intent

    if best_score == 0:
        return "unclear", 0.2
    confidence = min(0.55 + 0.15 * best_score, 0.9)
    return best_intent, confidence


class MockLLMClient(BaseLLMClient):
    name = "mock"

    def complete(self, system_prompt: str, user_prompt: str, temperature: float = 0.2) -> str:
        # Only used directly for free-text generation; the orchestrator
        # calls complete_json() for classification. Here we handle the
        # answer-generation prompt shape produced by prompts.build_answer_prompt.
        target_language = "en"
        user_message = ""
        context_chunks: list[str] = []
        tool_result_raw = "(none)"

        for line in user_prompt.splitlines():
            if line.startswith("TARGET_LANGUAGE:"):
                target_language = line.split(":", 1)[1].strip()
            elif line.startswith("USER_MESSAGE:"):
                user_message = line.split(":", 1)[1].strip()
            elif line.startswith("- source_id="):
                context_chunks.append(line.strip())
            elif line.startswith("TOOL_RESULT:"):
                tool_result_raw = line.split(":", 1)[1].strip()

        tool_result = None
        if tool_result_raw not in ("(none)", ""):
            try:
                tool_result = json.loads(tool_result_raw)
            except json.JSONDecodeError:
                tool_result = None

        return self._generate_answer(target_language, user_message, context_chunks, tool_result)

    def complete_json(self, system_prompt: str, user_prompt: str) -> str:
        user_message = ""
        for line in user_prompt.splitlines():
            if line.startswith("USER_MESSAGE:"):
                user_message = line.split(":", 1)[1].strip()
        text_lower = user_message.lower()

        lang_info = detect_language(user_message)
        intent, confidence = _keyword_intent(text_lower)
        order_id_match = _ORDER_ID_RE.search(user_message)
        order_id = order_id_match.group(0).upper() if order_id_match else None

        sensitive = intent in ("escalate_fraud", "escalate_other")

        result = {
            "language": lang_info["language"],
            "intent": intent,
            "order_id": order_id,
            "reason": user_message if intent == "return_request" else None,
            "confidence": confidence,
            "sensitive": sensitive,
        }
        return json.dumps(result, ensure_ascii=False)

    # ------------------------------------------------------------------
    @staticmethod
    def _generate_answer(target_language, user_message, context_chunk_lines, tool_result) -> str:
        FRAMING = {
            "en": {
                "no_info": "I don't have enough verified information to answer that confidently — "
                           "let me escalate this to a human agent so they can help you properly.",
                "tool_prefix": "Here's what I found: ",
                "chunk_prefix": "Here's our policy on that: ",
                "en_only_ta_note": "(நான் தமிழில் மொழிபெயர்க்காமல் ஆங்கில மூலத்தை அப்படியே தருகிறேன், "
                                    "தவறான தகவல் தராமல் இருக்க): ",
            },
            "ta": {
                "no_info": "இதற்கான போதுமான தகவல் என்னிடம் இல்லை — தவறான தகவல் தராமல் இருக்க, "
                           "இதை ஒரு மனித ஏஜென்டிடம் அனுப்புகிறேன்.",
                "tool_prefix": "நான் கண்டறிந்தது: ",
                "chunk_prefix": "இது தொடர்பான எங்கள் கொள்கை: ",
            },
            "ta-en": {
                "no_info": "Idhu pathi enakku confirm-ஆன தகவல் illa — wrong info kudukama irukka, "
                           "idha human agent-kitta escalate pandren.",
                "tool_prefix": "Idhu than naan kandupidichadhu: ",
                "chunk_prefix": "Idhu related engaloda policy: ",
            },
        }
        f = FRAMING.get(target_language, FRAMING["en"])

        if tool_result:
            return f["tool_prefix"] + MockLLMClient._stringify_tool_result(tool_result)

        if context_chunk_lines:
            first = context_chunk_lines[0]
            m = re.search(r"source_id=(?P<source>\S+) \| doc_id=(?P<doc>\S+) \| lang=(?P<lang>\S+) \| text: (?P<text>.*)", first)
            if m:
                source_id = m.group("source")
                chunk_lang = m.group("lang")
                text = m.group("text")
                if target_language == "ta" and chunk_lang == "en":
                    # en_only mode serving a Tamil customer: be honest, don't fabricate translation.
                    return f["en_only_ta_note"] + text + f" (Source: {source_id})"
                return f["chunk_prefix"] + text + f" (Source: {source_id})"

        return f["no_info"]

    @staticmethod
    def _stringify_tool_result(tool_result: dict) -> str:
        # Simple, safe field-by-field rendering — no invented values.
        # Skip bookkeeping/None fields so this reads like a sentence a
        # human agent would say, not a raw dict dump.
        skip_keys = {"found", "success", "error"}
        parts = []
        for k, v in tool_result.items():
            if k in skip_keys or v is None or isinstance(v, (dict, list)):
                continue
            parts.append(f"{k.replace('_', ' ')}: {v}")
        return "; ".join(parts) if parts else json.dumps(tool_result, ensure_ascii=False)
