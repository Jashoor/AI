"""LLM backend factory — picks the configured backend at import time."""
from src import config
from src.llm.base import BaseLLMClient
from src.llm.mock_client import MockLLMClient
from src.llm.ollama_client import OllamaLLMClient
from src.llm.groq_client import GroqLLMClient


def get_llm_client(backend: str | None = None) -> BaseLLMClient:
    backend = (backend or config.LLM_BACKEND).strip().lower()
    if backend == "mock":
        return MockLLMClient()
    if backend == "ollama":
        return OllamaLLMClient()
    if backend == "groq":
        return GroqLLMClient()
    raise ValueError(f"Unknown LLM_BACKEND '{backend}'. Use mock / ollama / groq.")
