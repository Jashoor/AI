"""
Free, local LLM backend via Ollama (https://ollama.com).

Setup (all free):
    1. Install Ollama for your OS from https://ollama.com
    2. `ollama pull qwen2.5:7b`   (or llama3.1, gemma2, etc.)
    3. Set LLM_BACKEND=ollama in .env

Qwen2.5 and Llama-3.1 both have meaningfully better Tamil generation than
older open models, though neither is a dedicated Indic-language model.
For stronger Tamil/Hindi fluency, consider swapping OLLAMA_MODEL for an
Indic-tuned open model if one is available in your Ollama library at
run time (e.g. search "sarvam" or "indic" on ollama.com/library).
"""
import json
import requests

from src.llm.base import BaseLLMClient
from src import config


class OllamaLLMClient(BaseLLMClient):
    name = "ollama"

    def __init__(self, host: str | None = None, model: str | None = None):
        self.host = host or config.OLLAMA_HOST
        self.model = model or config.OLLAMA_MODEL

    def complete(self, system_prompt: str, user_prompt: str, temperature: float = 0.2) -> str:
        url = f"{self.host.rstrip('/')}/api/chat"
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "stream": False,
            "options": {"temperature": temperature},
        }
        try:
            resp = requests.post(url, json=payload, timeout=120)
            resp.raise_for_status()
            data = resp.json()
            return data.get("message", {}).get("content", "").strip()
        except requests.RequestException as e:
            return (
                "[ollama_error] Could not reach local Ollama server at "
                f"{self.host}. Is `ollama serve` running and is the model "
                f"'{self.model}' pulled? Details: {e}"
            )

    def complete_json(self, system_prompt: str, user_prompt: str) -> str:
        # Ollama's /api/chat supports "format": "json" for JSON-mode decoding.
        url = f"{self.host.rstrip('/')}/api/chat"
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "stream": False,
            "format": "json",
            "options": {"temperature": 0.0},
        }
        try:
            resp = requests.post(url, json=payload, timeout=120)
            resp.raise_for_status()
            data = resp.json()
            content = data.get("message", {}).get("content", "").strip()
            json.loads(content)  # validate
            return content
        except (requests.RequestException, json.JSONDecodeError) as e:
            # Fall back to a safe "unclear" classification rather than crashing.
            return json.dumps({
                "language": "en", "intent": "unclear", "order_id": None,
                "reason": None, "confidence": 0.0, "sensitive": False,
                "error": str(e),
            })
