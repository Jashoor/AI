"""
Free-tier hosted LLM backend via Groq (https://console.groq.com).

Groq's free tier requires only an email sign-up (no credit card) and gives
a generous per-minute/per-day token quota, making it a genuinely free way
to get real generative answers without running anything locally.

Setup:
    1. Create a free API key at https://console.groq.com/keys
    2. Set GROQ_API_KEY in .env
    3. Set LLM_BACKEND=groq in .env
"""
import json
import requests

from src.llm.base import BaseLLMClient
from src import config

GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"


class GroqLLMClient(BaseLLMClient):
    name = "groq"

    def __init__(self, api_key: str | None = None, model: str | None = None):
        self.api_key = api_key or config.GROQ_API_KEY
        self.model = model or config.GROQ_MODEL

    def _call(self, system_prompt: str, user_prompt: str, temperature: float, json_mode: bool) -> str:
        if not self.api_key:
            return json.dumps({
                "language": "en", "intent": "unclear", "order_id": None,
                "reason": None, "confidence": 0.0, "sensitive": False,
                "error": "GROQ_API_KEY not set. Get a free key at "
                         "https://console.groq.com/keys and add it to .env",
            }) if json_mode else (
                "[groq_error] GROQ_API_KEY not set. Get a free key at "
                "https://console.groq.com/keys and add it to .env"
            )

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": temperature,
        }
        if json_mode:
            payload["response_format"] = {"type": "json_object"}

        try:
            resp = requests.post(GROQ_URL, headers=headers, json=payload, timeout=60)
            resp.raise_for_status()
            data = resp.json()
            return data["choices"][0]["message"]["content"].strip()
        except (requests.RequestException, KeyError, IndexError) as e:
            fallback = {
                "language": "en", "intent": "unclear", "order_id": None,
                "reason": None, "confidence": 0.0, "sensitive": False,
                "error": str(e),
            }
            return json.dumps(fallback) if json_mode else f"[groq_error] {e}"

    def complete(self, system_prompt: str, user_prompt: str, temperature: float = 0.2) -> str:
        return self._call(system_prompt, user_prompt, temperature, json_mode=False)

    def complete_json(self, system_prompt: str, user_prompt: str) -> str:
        return self._call(system_prompt, user_prompt, 0.0, json_mode=True)
