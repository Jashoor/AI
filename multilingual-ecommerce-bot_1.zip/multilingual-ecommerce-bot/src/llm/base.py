"""
Common interface every LLM backend implements, so the orchestrator never
needs to know whether it's talking to the free mock backend, a local Ollama
model, or Groq's hosted API.
"""
from abc import ABC, abstractmethod


class BaseLLMClient(ABC):
    name: str = "base"

    @abstractmethod
    def complete(self, system_prompt: str, user_prompt: str, temperature: float = 0.2) -> str:
        """Return a plain-text completion given a system + user prompt."""
        raise NotImplementedError

    def complete_json(self, system_prompt: str, user_prompt: str) -> str:
        """
        Default implementation: just call complete() and let the caller
        parse JSON out of it (with fallback repair in orchestrator.py).
        Backends with native JSON-mode can override this.
        """
        return self.complete(system_prompt, user_prompt, temperature=0.0)
