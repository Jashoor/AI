"""
Mock "create a return/cancellation request" backend API. Persists created
requests to data/returns_db.json (created on first use) so the demo has
some statefulness across a session without needing a real database.
"""
import json
import uuid
from datetime import datetime, timezone

from src import config
from src.tools.order_tools import _load_orders


def _load_returns() -> dict:
    if config.RETURNS_DB_PATH.exists():
        with open(config.RETURNS_DB_PATH, encoding="utf-8") as f:
            return json.load(f)
    return {}


def _save_returns(returns: dict) -> None:
    with open(config.RETURNS_DB_PATH, "w", encoding="utf-8") as f:
        json.dump(returns, f, indent=2, ensure_ascii=False)


def create_return_request(order_id: str | None, reason: str | None = None) -> dict:
    """
    Creates a return/cancellation request for an existing order.
    Applies the same real-world rule the return policy states: an order
    that has already shipped can be *returned* after delivery, but a
    pre-shipment *cancellation* is only valid for orders still "Processing".
    """
    if not order_id:
        return {"success": False, "error": "no_order_id_provided"}

    orders = _load_orders()
    order = orders.get(order_id.upper())
    if not order:
        return {"success": False, "error": "order_not_found", "order_id": order_id}

    status = order["status"]
    if status == "Cancelled":
        return {"success": False, "error": "order_already_cancelled", "order_id": order_id}

    request_type = "cancellation" if status == "Processing" else "return"

    if request_type == "return" and status not in ("Delivered", "Shipped", "Out for Delivery"):
        return {
            "success": False,
            "error": "not_eligible_yet",
            "order_id": order_id,
            "current_status": status,
        }

    returns = _load_returns()
    request_id = f"RET{uuid.uuid4().hex[:8].upper()}"
    returns[request_id] = {
        "order_id": order_id.upper(),
        "request_type": request_type,
        "reason": reason or "not specified",
        "status": "Requested",
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    _save_returns(returns)

    return {
        "success": True,
        "request_id": request_id,
        "request_type": request_type,
        "order_id": order_id.upper(),
        "status": "Requested",
        "next_step": (
            "A pickup will be scheduled within 2 business days."
            if request_type == "return"
            else "Your order will be cancelled and the full amount refunded; no fee applies."
        ),
    }
