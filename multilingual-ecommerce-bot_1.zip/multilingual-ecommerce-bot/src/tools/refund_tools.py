"""
Mock "refund policy" and "payment methods" backend APIs.

These are implemented as direct, hard-coded structured lookups (not RAG)
per the assignment's explicit tool list (`get_refund_policy()`). In a real
system this might hit a rules-engine/config service rather than free-text
documents — the distinction matters: numbers here are guaranteed correct
(no retrieval/generation in the loop), which is exactly why the assistant
should prefer calling this tool over paraphrasing the refund policy
document whenever the customer's question is really "how many days".
"""


def get_refund_policy() -> dict:
    return {
        "quality_check_initiation_days": 2,
        "card_netbanking_days": "5-7 business days",
        "upi_wallet_hours": "24-48 hours",
        "damaged_or_wrong_item_note": "No quality-check wait for approved damaged/wrong-item claims.",
        "escalate_after": "Full stated timeline has elapsed with no refund received",
        "source": "POLICY_REFUND_01",
    }


def get_payment_methods() -> dict:
    return {
        "accepted_methods": "Credit card, Debit card, UPI, Net banking, Wallets, Cash on Delivery (COD)",
        "cod_limit": "15,000 rupees (not available for electronics above this value)",
        "cod_handling_fee": "25 rupees on orders below 500 rupees, else free",
        "source": "POLICY_PAYMENT_01",
    }
