"""
Mock "order status" backend API. In a real system this would call an
Order Management System over REST/gRPC; here it reads a static JSON file
to stand in for that, per the assignment's "mock backend tools" spec.
"""
import json

from src import config


def _load_orders() -> dict:
    with open(config.ORDERS_DB_PATH, encoding="utf-8") as f:
        return json.load(f)


def get_order_status(order_id: str | None) -> dict:
    """
    Returns order status/details for a given order_id, or a structured
    "not_found" result the agent must be honest about (never invent an
    order that doesn't exist).
    """
    if not order_id:
        return {"found": False, "error": "no_order_id_provided"}

    orders = _load_orders()
    order = orders.get(order_id.upper())
    if not order:
        return {"found": False, "error": "order_not_found", "order_id": order_id}

    return {
        "found": True,
        "order_id": order_id.upper(),
        "status": order["status"],
        "items": ", ".join(f"{i['name']} x{i['qty']}" for i in order["items"]),
        "amount": order["amount"],
        "payment_method": order["payment_method"],
        "expected_delivery": order.get("expected_delivery"),
        "delivered_on": order.get("delivered_on"),
        "cancelled_on": order.get("cancelled_on"),
    }
