"""
Lightweight, dependency-light language + code-switch detector.

Design notes (see README "Known Limitations"):
- Tamil written in Tamil script is trivially detected via Unicode ranges.
- Tamil/Hindi written in Latin script ("Tanglish"/"Hinglish", e.g.
  "order eppo varum") is NOT reliably detectable from Unicode alone —
  there is no script signal to key off. We use a small transliterated
  keyword list as an approximation, which is intentionally conservative:
  it will under-detect novel phrasing, and this is called out explicitly
  as a limitation rather than papered over.
- For robustness, callers can also pass the LLM's own opinion (asked for
  as part of the intent-classification JSON) and reconcile it with this
  heuristic; `reconcile()` below does that.
"""
import re

TAMIL_UNICODE_RANGE = re.compile(r"[\u0B80-\u0BFF]")

# Small, deliberately non-exhaustive list of common transliterated Tamil
# function words / discourse markers seen in customer chat. This is a
# heuristic aid, not a classifier — extend as needed for your domain.
TANGLISH_MARKERS = {
    "eppo", "epadi", "enna", "sollunga", "sollu", "pannalama", "pannanum",
    "pannirukanga", "vandhurichu", "irukku", "iruka", "iruken", "varum",
    "vara", "illa", "aagum", "nu", "nga", "pandringala", "pandrathu",
    "munnadi", "apparam", "ippo", "rendu", "onnu", "evlo", "naan", "idhu",
    "andha", "intha", "sonna", "kaamikkudhu", "artham", "velinaatuku",
}


def tamil_script_ratio(text: str) -> float:
    if not text.strip():
        return 0.0
    tamil_chars = len(TAMIL_UNICODE_RANGE.findall(text))
    letters = len(re.findall(r"\w", text, flags=re.UNICODE))
    # Tamil vowel-sign/matra codepoints are counted separately by the Unicode
    # range match but combine with a base consonant into a single "letter"
    # for \w purposes, so the raw ratio can exceed 1 — clip it.
    return min(tamil_chars / max(letters, 1), 1.0)


def tanglish_marker_ratio(text: str) -> float:
    words = re.findall(r"[a-zA-Z]+", text.lower())
    if not words:
        return 0.0
    hits = sum(1 for w in words if w in TANGLISH_MARKERS)
    return hits / len(words)


def detect_language(text: str) -> dict:
    """
    Returns {"language": "en" | "ta" | "ta-en", "code_switch": bool,
             "tamil_script_ratio": float, "tanglish_marker_ratio": float}
    """
    ta_ratio = tamil_script_ratio(text)
    tanglish_ratio = tanglish_marker_ratio(text)

    has_latin = bool(re.search(r"[a-zA-Z]{2,}", text))

    if ta_ratio > 0.4 and not has_latin:
        lang, code_switch = "ta", False
    elif ta_ratio > 0.05 and has_latin:
        # Tamil script mixed with English words in the same message
        lang, code_switch = "ta-en", True
    elif tanglish_ratio >= 0.15:
        # Latin-script transliterated Tamil ("Tanglish") mixed with English
        lang, code_switch = "ta-en", True
    else:
        lang, code_switch = "en", False

    return {
        "language": lang,
        "code_switch": code_switch,
        "tamil_script_ratio": round(ta_ratio, 3),
        "tanglish_marker_ratio": round(tanglish_ratio, 3),
    }


def reconcile(heuristic: dict, llm_reported_language: str | None) -> dict:
    """
    If the LLM's own language judgement (asked for during intent
    classification) disagrees with the heuristic, prefer the LLM's answer
    for anything except a clear Tamil-script signal (which is unambiguous),
    but keep both for transparency/eval.
    """
    result = dict(heuristic)
    if llm_reported_language and heuristic["tamil_script_ratio"] < 0.05:
        result["language_llm_opinion"] = llm_reported_language
        if llm_reported_language in ("en", "ta", "ta-en"):
            result["language"] = llm_reported_language
    return result
