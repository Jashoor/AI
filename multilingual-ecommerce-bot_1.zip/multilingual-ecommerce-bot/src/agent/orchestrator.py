"""
The main agent loop. This is intentionally a plain, readable Python
state machine rather than a heavyweight agent framework — for a project
this scoped, that keeps every decision point auditable (important for the
"safety & guardrails" evaluation criterion).

Turn flow:
  1. Detect language (heuristic; reconciled with the LLM's own opinion).
  2. Classify intent + extract entities via the LLM (JSON mode).
  3. Guardrail check: sensitive-topic keywords, low classifier confidence,
     repeated "unclear" turns -> escalate.
  4. Route: tool call (order/return/refund/payment) OR RAG retrieval.
  5. If RAG: enforce a minimum similarity threshold; below it, do not
     let the LLM answer at all — escalate honestly instead of guessing.
  6. Generate the final answer in the customer's language, citing the
     canonical English source_id.
  7. Log the full turn (for eval + audit) to LOG_DIR.
"""
import json
import uuid
from datetime import datetime, timezone
from dataclasses import dataclass, field

from src import config
from src.llm import get_llm_client
from src.llm.base import BaseLLMClient
from src.agent import prompts
from src.agent.language_detect import detect_language, reconcile
from src.rag.retriever import Retriever
from src.tools.order_tools import get_order_status
from src.tools.return_tools import create_return_request
from src.tools.refund_tools import get_refund_policy, get_payment_methods

MAX_CLARIFICATIONS = 1


@dataclass
class TurnResult:
    session_id: str
    turn_index: int
    user_message: str
    detected_language: dict
    intent: str
    confidence: float
    order_id: str | None
    route: str  # "tool" | "rag" | "escalate" | "clarify"
    tool_name: str | None
    tool_result: dict | None
    retrieved_chunks: list
    escalated: bool
    escalation_reason: str | None
    final_answer: str
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class Orchestrator:
    def __init__(self, llm: BaseLLMClient | None = None, retrieval_mode: str | None = None):
        self.llm = llm or get_llm_client()
        self.retriever = Retriever(mode=retrieval_mode)
        self.session_id = str(uuid.uuid4())[:8]
        self.turn_index = 0
        self.unclear_streak = 0
        self.history: list[TurnResult] = []

    # ------------------------------------------------------------------
    def handle_message(self, user_message: str) -> TurnResult:
        self.turn_index += 1

        lang_heuristic = detect_language(user_message)

        history_snippet = "\n".join(
            f"[{t.detected_language['language']}] {t.user_message} -> {t.final_answer[:120]}"
            for t in self.history[-3:]
        )
        sys_p, usr_p = prompts.build_intent_prompt(user_message, history_snippet)
        raw_json = self.llm.complete_json(sys_p, usr_p)
        parsed = self._safe_parse_intent(raw_json)

        lang_info = reconcile(lang_heuristic, parsed.get("language"))
        intent = parsed.get("intent", "unclear")
        confidence = float(parsed.get("confidence", 0.0) or 0.0)
        order_id = parsed.get("order_id")
        sensitive = bool(parsed.get("sensitive", False))

        # ---- Guardrail: sensitive topics always escalate, regardless of confidence ----
        if intent in ("escalate_fraud", "escalate_other") or sensitive:
            return self._escalate(
                user_message, lang_info, intent, confidence, order_id,
                reason=f"sensitive_topic:{intent}",
            )

        # ---- Guardrail: repeated low-confidence "unclear" -> escalate instead of looping ----
        if intent == "unclear":
            self.unclear_streak += 1
            if self.unclear_streak > MAX_CLARIFICATIONS:
                return self._escalate(
                    user_message, lang_info, intent, confidence, order_id,
                    reason="repeated_unclear_after_clarification",
                )
            return self._clarify(user_message, lang_info, intent, confidence, order_id)
        else:
            self.unclear_streak = 0

        # ---- Route to a tool or to RAG ----
        if intent == "order_status":
            return self._handle_tool(
                user_message, lang_info, intent, confidence, order_id,
                tool_name="get_order_status",
                tool_fn=lambda: get_order_status(order_id),
            )

        if intent == "return_request":
            reason = parsed.get("reason")
            return self._handle_tool(
                user_message, lang_info, intent, confidence, order_id,
                tool_name="create_return_request",
                tool_fn=lambda: create_return_request(order_id, reason),
            )

        if intent == "refund_policy":
            return self._handle_tool(
                user_message, lang_info, intent, confidence, order_id,
                tool_name="get_refund_policy",
                tool_fn=lambda: get_refund_policy(),
            )

        if intent == "payment_info":
            return self._handle_tool(
                user_message, lang_info, intent, confidence, order_id,
                tool_name="get_payment_methods",
                tool_fn=lambda: get_payment_methods(),
            )

        # default: faq_general -> RAG
        return self._handle_rag(user_message, lang_info, intent, confidence, order_id)

    # ------------------------------------------------------------------
    def _handle_tool(self, user_message, lang_info, intent, confidence, order_id,
                      tool_name, tool_fn) -> TurnResult:
        tool_result = tool_fn()

        # Guardrail: tool reports the requested entity doesn't exist -> be
        # honest, don't let the LLM paper over it, and nudge to escalate
        # when the tool itself signals failure.
        if isinstance(tool_result, dict) and tool_result.get("found") is False:
            return self._escalate(
                user_message, lang_info, intent, confidence, order_id,
                reason=f"tool_could_not_find_entity:{tool_name}",
                tool_name=tool_name, tool_result=tool_result,
            )
        if isinstance(tool_result, dict) and tool_result.get("success") is False \
                and tool_result.get("error") in ("order_not_found",):
            return self._escalate(
                user_message, lang_info, intent, confidence, order_id,
                reason=f"tool_could_not_find_entity:{tool_name}",
                tool_name=tool_name, tool_result=tool_result,
            )

        sys_p, usr_p = prompts.build_answer_prompt(
            target_language=lang_info["language"],
            user_message=user_message,
            tool_result=tool_result,
        )
        answer = self.llm.complete(sys_p, usr_p)

        result = TurnResult(
            session_id=self.session_id, turn_index=self.turn_index,
            user_message=user_message, detected_language=lang_info,
            intent=intent, confidence=confidence, order_id=order_id,
            route="tool", tool_name=tool_name, tool_result=tool_result,
            retrieved_chunks=[], escalated=False, escalation_reason=None,
            final_answer=answer,
        )
        self._log(result)
        self.history.append(result)
        return result

    def _handle_rag(self, user_message, lang_info, intent, confidence, order_id) -> TurnResult:
        chunks = self.retriever.retrieve_above_threshold(user_message)

        if not chunks:
            return self._escalate(
                user_message, lang_info, intent, confidence, order_id,
                reason="retrieval_below_confidence_threshold",
            )

        sys_p, usr_p = prompts.build_answer_prompt(
            target_language=lang_info["language"],
            user_message=user_message,
            context_chunks=chunks,
        )
        answer = self.llm.complete(sys_p, usr_p)

        result = TurnResult(
            session_id=self.session_id, turn_index=self.turn_index,
            user_message=user_message, detected_language=lang_info,
            intent=intent, confidence=confidence, order_id=order_id,
            route="rag", tool_name=None, tool_result=None,
            retrieved_chunks=chunks, escalated=False, escalation_reason=None,
            final_answer=answer,
        )
        self._log(result)
        self.history.append(result)
        return result

    def _clarify(self, user_message, lang_info, intent, confidence, order_id) -> TurnResult:
        CLARIFY_MSG = {
            "en": "Sorry, I didn't quite catch that — could you tell me a bit more? "
                  "For example: an order number, or whether this is about a return, refund, or payment?",
            "ta": "மன்னிக்கவும், எனக்கு சரியாகப் புரியவில்லை — கொஞ்சம் விரிவாகச் சொல்ல முடியுமா? "
                  "உதாரணமாக ஆர்டர் எண், அல்லது இது திரும்ப அளிப்பு, பணத்திரும்ப, அல்லது பணம் தொடர்பானதா?",
            "ta-en": "Sorry, konjam clear-a puriyala — konjam detail sollunga? "
                     "Example: order number, illa idhu return, refund, illa payment pathiyaana?",
        }
        answer = CLARIFY_MSG.get(lang_info["language"], CLARIFY_MSG["en"])
        result = TurnResult(
            session_id=self.session_id, turn_index=self.turn_index,
            user_message=user_message, detected_language=lang_info,
            intent=intent, confidence=confidence, order_id=order_id,
            route="clarify", tool_name=None, tool_result=None,
            retrieved_chunks=[], escalated=False, escalation_reason=None,
            final_answer=answer,
        )
        self._log(result)
        self.history.append(result)
        return result

    def _escalate(self, user_message, lang_info, intent, confidence, order_id,
                   reason, tool_name=None, tool_result=None) -> TurnResult:
        ESCALATE_MSG = {
            "en": "I want to make sure you get this resolved correctly, so I'm connecting you "
                  "with a human support agent who can take it from here.",
            "ta": "இதை சரியாக தீர்த்து வைக்க வேண்டும் என்பதற்காக, இதை ஒரு மனித ஆதரவு "
                  "ஏஜென்டிடம் அனுப்புகிறேன், அவர்கள் தொடர்ந்து உங்களுக்கு உதவுவார்கள்.",
            "ta-en": "Idha correct-a resolve pannanum nu naan want pandren, so oru human support "
                     "agent-kitta connect pandren, avanga continue pannuvanga.",
        }
        answer = ESCALATE_MSG.get(lang_info["language"], ESCALATE_MSG["en"])
        result = TurnResult(
            session_id=self.session_id, turn_index=self.turn_index,
            user_message=user_message, detected_language=lang_info,
            intent=intent, confidence=confidence, order_id=order_id,
            route="escalate", tool_name=tool_name, tool_result=tool_result,
            retrieved_chunks=[], escalated=True, escalation_reason=reason,
            final_answer=answer,
        )
        self._log(result)
        self.history.append(result)
        return result

    # ------------------------------------------------------------------
    @staticmethod
    def _safe_parse_intent(raw_json: str) -> dict:
        try:
            return json.loads(raw_json)
        except (json.JSONDecodeError, TypeError):
            # Real LLMs occasionally wrap JSON in prose/fences despite
            # instructions; do a best-effort brace extraction before
            # giving up and treating it as "unclear".
            try:
                start = raw_json.index("{")
                end = raw_json.rindex("}") + 1
                return json.loads(raw_json[start:end])
            except (ValueError, json.JSONDecodeError):
                return {"language": "en", "intent": "unclear", "order_id": None,
                        "reason": None, "confidence": 0.0, "sensitive": False}

    def _log(self, result: TurnResult) -> None:
        log_path = config.LOG_DIR / f"session_{self.session_id}.jsonl"
        with open(log_path, "a", encoding="utf-8") as f:
            record = {
                "session_id": result.session_id,
                "turn_index": result.turn_index,
                "timestamp": result.timestamp,
                "user_message": result.user_message,
                "detected_language": result.detected_language,
                "intent": result.intent,
                "confidence": result.confidence,
                "order_id": result.order_id,
                "route": result.route,
                "tool_name": result.tool_name,
                "tool_result": result.tool_result,
                "retrieved_chunks": [
                    {"doc_id": c["doc_id"], "source": c["source"], "score": c["score"]}
                    for c in result.retrieved_chunks
                ],
                "escalated": result.escalated,
                "escalation_reason": result.escalation_reason,
                "final_answer": result.final_answer,
            }
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
