"""
Terminal chat client.

Preferred: `python -m src.cli`   (run from the project root)
Also works if launched directly: `python src/cli.py`

Try mixing languages, e.g.:
  - "Where is my order ORD1001?"
  - "En order eppo varum, ORD1006"
  - "உங்கள் திரும்ப அளிக்கும் கொள்கை என்ன?"
  - "Someone made an unauthorized charge on my card"  (should escalate)
"""
import sys
from pathlib import Path

# Guard against "cannot import name 'config' from 'src'" when this file is
# executed directly rather than via `python -m src.cli` — see app.py for
# the same fix with a fuller explanation.
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from src import config
from src.agent.orchestrator import Orchestrator


def main():
    print("=" * 70)
    print("  Multilingual E-commerce Support Bot (CLI)")
    print(f"  LLM backend: {config.LLM_BACKEND} | Retrieval mode: {config.RETRIEVAL_MODE}")
    print("  Type in English, Tamil, or mixed Tamil-English. Ctrl+C to quit.")
    print("=" * 70)

    orchestrator = Orchestrator()

    while True:
        try:
            user_message = input("\nYou: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nSession ended.")
            break

        if not user_message:
            continue
        if user_message.lower() in ("quit", "exit"):
            print("Session ended.")
            break

        result = orchestrator.handle_message(user_message)

        print(f"\nBot [{result.detected_language['language']} | intent={result.intent} "
              f"| route={result.route}"
              + (f" | ESCALATED:{result.escalation_reason}" if result.escalated else "")
              + "]:")
        print(result.final_answer)

        if result.retrieved_chunks:
            sources = ", ".join(sorted({c["source"] for c in result.retrieved_chunks}))
            print(f"  (retrieved from: {sources})")


if __name__ == "__main__":
    main()
