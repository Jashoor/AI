# Technical Report — Multilingual / Code-Switching E-commerce Support Bot

## 1. Problem Scope & Assumptions

E-commerce support bots are usually built by RAG-ing over an English help
center. The moment a customer writes in Tamil, or mixes Tamil and English in
the same sentence ("order eppo varum"), retrieval quality silently drops —
there is no error, the bot just quietly returns worse or irrelevant context,
because embedding similarity between the query and the (English) corpus is
weaker.

This project scopes an assistant for exactly that failure mode:

- **Languages supported:** English (`en`), Tamil (`ta`), and code-switched
  Tamil-English (`ta-en`), covering both Tamil-script mixing and
  Latin-script transliteration ("Tanglish").
- **Intents handled autonomously:** order status, return/cancellation
  requests, refund policy/timelines, payment methods, and general
  FAQ/policy questions.
- **Always escalated to a human:** fraud/unauthorized-charge reports, legal
  threats, explicit requests for a human agent, unresolvable/unclear
  messages (after one clarification attempt), and any case where a tool
  can't find the referenced order or the retriever can't clear a minimum
  similarity threshold.
- **Assumption:** policy documents are authored in English only (the
  realistic default for most companies' canonical legal text); FAQs exist
  as parallel English/Tamil pairs sharing a `doc_id`, which sets up the
  project's core ablation (Section 4).
- **Assumption:** order/return data is mocked (JSON-backed), standing in
  for a real OMS/payments backend.

## 2. Architecture & Data Pipeline

```
user message
   -> language heuristic (Unicode script ratio + Tanglish keyword ratio)
   -> LLM intent classification (JSON: language, intent, order_id, reason,
      confidence, sensitive) — reconciled with the heuristic
   -> guardrail check (sensitive topic / low confidence / repeated unclear)
   -> route:
        tool call   (order_status / return_request / refund_policy / payment_info)
        RAG lookup  (faq_general) — multilingual-e5 embeddings -> FAISS
                     top-k -> similarity threshold gate
   -> LLM answer generation, in the customer's language, citing the
      canonical English source_id
   -> JSONL turn log
```

**Data pipeline for RAG:** FAQ JSON (English + Tamil, shared `doc_id`) and
policy Markdown (English, chunked on `## ` headings, `doc_id` extracted from
a `Document ID:` line) are loaded into a uniform record schema
(`doc_id, source, lang, title, text`), embedded with
`intfloat/multilingual-e5-base` (free, open-source, CPU-friendly, shared
100+-language embedding space), and indexed with FAISS `IndexFlatIP` over
L2-normalized vectors (inner product = cosine similarity).

Two indexes are built side by side (`en_only`, `bilingual`) precisely so the
evaluation can isolate the effect of having native-language passages
indexed vs. relying purely on cross-lingual embedding similarity against
English-only text — see Section 4.

## 3. Prompt & Agent Design

All prompts live in `src/agent/prompts.py`. Two prompt contracts, used
identically regardless of which LLM backend is plugged in:

1. **Intent classification** — strict JSON-only output schema
   (`language`, `intent`, `order_id`, `reason`, `confidence`, `sensitive`),
   with explicit instructions to prefer `"unclear"` over guessing, and to
   treat Tamil-script-mixed or transliterated-Tamil messages as `"ta-en"`.
2. **Answer generation** — instructed to (a) reply in the customer's exact
   target language and register, (b) ground strictly in the given
   `CONTEXT_CHUNKS`/`TOOL_RESULT` and never invent details, (c) cite the
   **English** `source_id` even when answering in Tamil, (d) prefer live
   `TOOL_RESULT` over retrieved text when both are relevant, and (e)
   admit uncertainty and suggest escalation rather than guess.

**Agentic logic** is a small explicit state machine (`orchestrator.py`)
rather than a general-purpose agent framework — deliberately, so every
guardrail decision (why did this turn escalate?) is inspectable in plain
Python and fully logged, which matters for the safety evaluation. Guardrails
enforced independent of the LLM's own judgement:
- Fraud/legal/human-request intents always escalate, regardless of stated
  confidence.
- A tool reporting "not found" (unknown order) escalates rather than
  letting the LLM paraphrase a failure into a vague non-answer.
- RAG answers are blocked entirely below `MIN_SIMILARITY` — the assistant
  says it doesn't know rather than answering off a weak match.
- Two consecutive "unclear" classifications escalate instead of looping
  forever on repeated clarification.

**LLM backend abstraction** (`src/llm/`) lets the exact same orchestrator
run against:
- `mock` — free, offline, template-based (default; guarantees a $0,
  zero-install demo path for grading),
- `ollama` — free, local, real generation (`qwen2.5`/`llama3.1`),
- `groq` — free-tier hosted API, real generation.

## 4. Evaluation Method & Results

`data/synthetic_queries.csv` has 50 labeled queries (15 English, 15 Tamil,
15 code-switched, 5 escalation/edge cases), each labeled with gold language,
gold intent, and — for FAQ-routed queries — the expected source `doc_id`(s).
`src/eval/run_eval.py` runs the full set through both retrieval modes and
reports:

- **Retrieval Recall@k / MRR per query language, per mode** — the core
  "retrieval-quality drop across languages" metric. Expected pattern (to be
  confirmed by running with a real embedding model + internet access): in
  `en_only` mode, Tamil and code-switched Recall@k should sit measurably
  below English Recall@k, since the retriever has only cross-lingual
  embedding similarity to work with. In `bilingual` mode, that gap should
  shrink substantially, since native Tamil FAQ text is directly indexed.
  The `ta-en` (code-switched) column is expected to fall *between* `en`
  and pure `ta` in `en_only` mode, since code-switched queries retain
  partial English lexical overlap that pure Tamil queries don't.
- **Heuristic translation/generation hallucination rate** — for every
  RAG-routed answer, every number in the generated answer (minus order IDs)
  is checked against the numbers present in the retrieved source text; any
  unsupported number is flagged. This is a proxy for "the model changed 7
  days into 10 days while producing fluent Tamil," not a full faithfulness
  classifier — see limitations.
- **Escalation precision/recall** on the labeled escalation subset —
  confirms fraud/legal/human-request messages are caught regardless of
  language, and that ordinary FAQ/order questions are *not* over-escalated.

Because this repository was built and validated in a network-restricted
sandbox, the FAISS/embedding portions of `run_eval.py` were verified by
unit test with the real components stubbed (`tests/test_orchestrator.py`,
run against a fake retriever) rather than a live embedding model; the
orchestrator's routing, guardrail, and tool-calling logic all pass. Running
`python -m src.rag.build_index && python -m src.eval.run_eval` on a machine
with internet access will produce the actual Recall@k/MRR numbers and
should be the first thing done after cloning this repo, before drawing
conclusions for a course submission.

## 5. Limitations & Future Improvements

- The `mock` LLM backend is template-based, not generative — real fluent
  Tamil generation (and therefore a meaningful hallucination-rate
  comparison) requires the `ollama` or `groq` backend.
- Latin-script transliterated Tamil ("Tanglish") is detected via a small,
  non-exhaustive keyword list, not a trained classifier — it will miss
  novel phrasing. A logistic-regression or fastText language-ID model
  trained on transliterated Indic text would generalize better.
- The hallucination check is numeric/entity-overlap only; it cannot catch
  subtler semantic drift (e.g. correctly-formatted numbers attached to the
  wrong claim).
- No conversation memory beyond the last 3 turns is passed to the intent
  classifier; a longer-running support conversation would benefit from
  proper session/state management (e.g. remembering an order ID mentioned
  two turns ago).
- Order/return/refund tools are mocked in-memory JSON; there's no real
  authentication, payment gateway, or carrier integration.
- Extending to a third language (e.g. Hindi, already partially supported by
  the keyword/escalation lists) only requires adding a parallel
  `faqs_hi.json` and extending `TANGLISH_MARKERS`-equivalent lists — the
  embedding model and FAISS pipeline already generalize.
