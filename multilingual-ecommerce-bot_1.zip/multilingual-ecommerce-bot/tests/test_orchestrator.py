"""
Orchestrator tests using the free mock LLM backend, so these run with zero
API keys / internet (beyond the one-time embedding model download needed
by the retriever, which must be indexed first via `python -m src.rag.build_index`).
"""
import unittest

from src.agent.orchestrator import Orchestrator
from src.llm.mock_client import MockLLMClient


class TestOrchestratorRouting(unittest.TestCase):
    def setUp(self):
        self.orchestrator = Orchestrator(llm=MockLLMClient(), retrieval_mode="bilingual")

    def test_order_status_routes_to_tool(self):
        result = self.orchestrator.handle_message("Where is my order ORD1001?")
        self.assertEqual(result.route, "tool")
        self.assertEqual(result.tool_name, "get_order_status")
        self.assertFalse(result.escalated)

    def test_unknown_order_id_escalates(self):
        result = self.orchestrator.handle_message("Where is my order ORD9999?")
        self.assertTrue(result.escalated)

    def test_fraud_keyword_escalates_immediately(self):
        result = self.orchestrator.handle_message(
            "Someone made an unauthorized charge on my card, this is fraud"
        )
        self.assertTrue(result.escalated)
        self.assertIn("sensitive_topic", result.escalation_reason)

    def test_return_request_routes_to_tool(self):
        result = self.orchestrator.handle_message("I want to return the shirt from ORD1002")
        self.assertEqual(result.route, "tool")
        self.assertEqual(result.tool_name, "create_return_request")

    def test_faq_question_routes_to_rag(self):
        result = self.orchestrator.handle_message("What is your return policy?")
        self.assertEqual(result.route, "rag")
        self.assertTrue(len(result.retrieved_chunks) > 0)

    def test_unclear_message_asks_for_clarification_then_escalates(self):
        r1 = self.orchestrator.handle_message("asdkj alkj xyz help idk")
        self.assertEqual(r1.route, "clarify")
        r2 = self.orchestrator.handle_message("still doesn't make sense zzz qqq")
        self.assertEqual(r2.route, "escalate")


if __name__ == "__main__":
    unittest.main()
