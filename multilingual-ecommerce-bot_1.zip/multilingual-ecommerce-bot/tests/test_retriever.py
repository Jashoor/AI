"""
Basic smoke tests for the RAG retriever. These require the index to have
been built first: `python -m src.rag.build_index`

Run: `python -m pytest tests/ -v`  (or `python -m unittest discover tests`)
"""
import unittest

from src.rag.retriever import Retriever


class TestRetrieverEnglish(unittest.TestCase):
    def setUp(self):
        self.retriever = Retriever(mode="bilingual", top_k=3)

    def test_english_query_hits_return_policy(self):
        results = self.retriever.retrieve("What is your return policy window?")
        sources = {r["source"] for r in results}
        self.assertIn("FAQ001", sources)

    def test_tamil_query_hits_return_policy_in_bilingual_mode(self):
        results = self.retriever.retrieve("உங்கள் திரும்ப அளிக்கும் கொள்கை என்ன?")
        sources = {r["source"] for r in results}
        self.assertIn("FAQ001", sources)

    def test_scores_are_bounded(self):
        results = self.retriever.retrieve("shipping time")
        for r in results:
            self.assertGreaterEqual(r["score"], -1.0001)
            self.assertLessEqual(r["score"], 1.0001)


class TestRetrieverEnOnlyMode(unittest.TestCase):
    def setUp(self):
        self.retriever = Retriever(mode="en_only", top_k=3)

    def test_en_only_mode_has_no_tamil_chunks(self):
        results = self.retriever.retrieve("refund timeline")
        for r in results:
            self.assertEqual(r["lang"], "en")

    def test_cross_lingual_retrieval_still_works_somewhat(self):
        # Cross-lingual embedding similarity should still surface *something*
        # relevant even with no Tamil text indexed -- this is the core
        # phenomenon the eval script measures the quality of.
        results = self.retriever.retrieve("பணத்தைத் திரும்பப் பெறும் காலஅளவு")
        self.assertTrue(len(results) > 0)


if __name__ == "__main__":
    unittest.main()
