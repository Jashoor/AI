# Multilingual / Code-Switching E-commerce Support Bot

An AI customer-support assistant that resolves common e-commerce queries
(orders, returns, refunds, payments, FAQs) for customers who write in
**English, Tamil, or a mix of both (code-switched / "Tanglish")**.

The core research/engineering problem this project targets:

> RAG pipelines built only over English FAQs silently degrade when customers
> ask in Tamil or mix languages mid-sentence. This project builds retrieval
> in a **shared multilingual embedding space**, generates answers **in the
> customer's language**, but always **cites back to the canonical English
> source document** — and measures how much retrieval quality drops across
> languages, plus how often translation introduces hallucinated facts.

This project is designed to run **100% free**:
- No paid API keys required. A built-in `mock` LLM backend needs zero setup.
- Optional free upgrades: local [Ollama](https://ollama.com) models, or the
  free tier of [Groq](https://console.groq.com) — both cost nothing.
- Embeddings use a free, open-source multilingual model
  (`intfloat/multilingual-e5-base`) run locally via `sentence-transformers`.
- Vector search uses `faiss-cpu`, running locally, no server/cloud needed.

---

## 1. Project Scope

**In scope (autonomously handled):**
| Intent | Example | Handling |
|---|---|---|
| Order status | "Where is my order?" / "Order eppo varum?" | Mock tool `get_order_status` |
| Return request | "I want to return this shirt" | Mock tool `create_return_request` |
| Refund policy / status | "How many days for refund?" | Mock tool `get_refund_policy` + RAG |
| Payment methods | "COD irukka?" | Mock tool `get_payment_methods` |
| General FAQ / policy | "Shipping எவ்வளவு நாள்?" | RAG over FAQ + policy corpus |

**Out of scope / always escalated to a human:**
- Payment fraud, chargeback disputes, legal threats
- Anything requiring PII changes beyond address (e.g. identity verification)
- Repeated failure to understand the customer after 1 clarification attempt
- Requests the retriever/tools cannot ground an answer in (low similarity
  score) — the bot says so honestly rather than guessing

**Languages:** English (`en`), Tamil (`ta`), and code-switched Tamil-English
(`ta-en`, e.g. "Tanglish" — Tamil words/sentiment with English nouns, or vice
versa). The architecture generalizes to any language pair supported by the
multilingual embedding model (100+ languages), Hindi included — only the
`data/faqs/*.json` translations would need to be swapped/extended.

**Assumptions:**
- Synthetic order/customer database (`data/orders_db.json`) stands in for a
  real order-management system.
- Policy documents are authored in English only — this is deliberate: it
  mirrors the realistic situation where a company's canonical legal/policy
  text exists in one language, and matches the project's "citations point to
  the English source" requirement.
- FAQs exist in **both** English and Tamil (parallel, same `doc_id`) so we can
  run a controlled **ablation**: does having Tamil-native FAQ text indexed
  help retrieval vs. relying purely on cross-lingual embedding similarity
  against English-only text? (See `docs/technical_report.md`, Eval section.)

---

## 2. Architecture

```
                     ┌─────────────────────────┐
   User message  ──▶ │ 1. Language detector    │  (script + heuristic + LLM confirm)
                     └───────────┬─────────────┘
                                 ▼
                     ┌─────────────────────────┐
                     │ 2. Intent classifier     │  (LLM, structured JSON output)
                     │   + entity extraction    │  (order_id, reason, etc.)
                     └───────────┬─────────────┘
                                 ▼
              ┌──────────────────┴───────────────────┐
              ▼                                      ▼
   ┌─────────────────────┐               ┌─────────────────────────┐
   │ 3a. Tool call        │               │ 3b. RAG retrieval        │
   │  order_status /      │               │  multilingual-e5 embed  │
   │  create_return /     │               │  → FAISS top-k search    │
   │  refund_policy /     │               │  → English source chunks│
   │  payment_methods     │               └────────────┬─────────────┘
   └──────────┬───────────┘                            │
              └───────────────────┬────────────────────┘
                                  ▼
                     ┌─────────────────────────┐
                     │ 4. Guardrail check       │  (fraud/legal keywords,
                     │                          │   low-confidence retrieval,
                     │                          │   missing order in DB)
                     └───────────┬─────────────┘
                     escalate? ──┼── no
                        │        ▼
                        ▼   ┌─────────────────────────┐
                 ┌──────────┤ 5. Answer generation     │  LLM writes final reply
                 │ Escalate │   in customer's language,│  in the *customer's*
                 │ to human │   citing English source  │  language, citations
                 └──────────┘   doc name/id            │  kept in English (doc IDs)
                                └─────────────────────────┘
```

Everything is orchestrated in `src/agent/orchestrator.py`. The LLM backend is
pluggable (`src/llm/`), so the same orchestrator works with the free mock
backend, a local Ollama model, or Groq's free API.

---

## 3. Repository Structure

```
multilingual-ecommerce-bot/
├── README.md                     ← you are here
├── requirements.txt
├── .env.example
├── data/
│   ├── faqs/
│   │   ├── faqs_en.json          ← English FAQ (source of truth)
│   │   └── faqs_ta.json          ← Tamil parallel FAQ (same doc_id)
│   ├── policies/                 ← English-only policy docs (canonical)
│   │   ├── shipping_policy.md
│   │   ├── return_policy.md
│   │   ├── refund_policy.md
│   │   └── payment_policy.md
│   ├── orders_db.json            ← mock order database
│   └── synthetic_queries.csv     ← labeled eval set (intent, language, code-switch flag)
├── src/
│   ├── config.py                 ← all settings (env-driven)
│   ├── llm/                      ← pluggable LLM backends
│   │   ├── base.py
│   │   ├── mock_client.py        ← free, offline, zero-setup
│   │   ├── ollama_client.py      ← free, local
│   │   └── groq_client.py        ← free tier, cloud
│   ├── rag/
│   │   ├── loader.py             ← loads + chunks FAQ/policy docs
│   │   ├── embed.py              ← multilingual embedding wrapper
│   │   ├── build_index.py        ← builds FAISS index(es)
│   │   └── retriever.py          ← top-k retrieval, en_only vs bilingual modes
│   ├── tools/                    ← mock backend "APIs"
│   │   ├── order_tools.py
│   │   ├── return_tools.py
│   │   └── refund_tools.py
│   ├── agent/
│   │   ├── language_detect.py
│   │   ├── prompts.py            ← all system/task prompts
│   │   └── orchestrator.py       ← main agent loop
│   ├── eval/
│   │   ├── metrics.py            ← retrieval + hallucination + safety metrics
│   │   └── run_eval.py           ← runs synthetic_queries.csv end-to-end
│   ├── app.py                    ← Streamlit chat UI
│   └── cli.py                    ← terminal chat (no Streamlit needed)
├── eval/
│   ├── eval_results.csv          ← generated by run_eval.py
│   └── conversation_logs/        ← generated per-session JSON transcripts
├── tests/
│   ├── test_retriever.py
│   └── test_orchestrator.py
└── docs/
    └── technical_report.md
```

---

## 4. Setup (all free)

```bash
# 1. Clone / unzip this repo, then create a virtual environment
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Copy the env template (defaults already work with zero API keys)
cp .env.example .env

# 4. Build the vector index (downloads the free embedding model on first run)
python -m src.rag.build_index

# 5a. Chat in the terminal
python -m src.cli

# 5b. OR launch the web UI
streamlit run src/app.py
```

### Choosing an LLM backend (`.env` → `LLM_BACKEND`)

| Backend | Cost | Setup | Notes |
|---|---|---|---|
| `mock` (default) | Free | None | Template-based answers built from retrieved/tool data. No internet or API key needed. Good for grading/demo without any install. |
| `ollama` | Free | Install [ollama.com](https://ollama.com), then `ollama pull qwen2.5:7b` | Runs fully locally. `qwen2.5` and `llama3.1` both have decent Tamil support. |
| `groq` | Free tier | Create a free key at [console.groq.com](https://console.groq.com) | Fast hosted inference, generous free quota, no credit card. |

Set in `.env`:
```
LLM_BACKEND=mock          # or ollama / groq
OLLAMA_MODEL=qwen2.5:7b
GROQ_API_KEY=your_free_key_here
GROQ_MODEL=llama-3.1-8b-instant
RETRIEVAL_MODE=bilingual  # or en_only  (see eval angle below)
```

---

## 5. Running the Evaluation

```bash
python -m src.eval.run_eval
```

This runs every row of `data/synthetic_queries.csv` through the full
pipeline twice — once with `RETRIEVAL_MODE=en_only` and once with
`RETRIEVAL_MODE=bilingual` — and writes `eval/eval_results.csv` plus
per-conversation JSON logs to `eval/conversation_logs/`. It prints a summary:

- **Recall@3 / MRR** for retrieval, broken down by query language
- **Retrieval-quality drop** = (English recall − Tamil/code-switched recall)
- **Translation-induced hallucination rate** — a heuristic check for
  numeric/entity mismatches between the generated answer and the source
  policy text (e.g. bot says "30 days" when the cited policy says "7 days")
- **Escalation precision/recall** on the sensitive-query subset

See `docs/technical_report.md` for full results and discussion.

---

## 6. Known Limitations

- The `mock` LLM backend produces template answers, not free-form generation —
  it exists to guarantee a zero-cost, zero-install demo path. Use `ollama` or
  `groq` for real generative answers.
- Code-switch **script mixing is easy to detect (Tamil Unicode vs Latin
  script), but transliterated Tamil written in Latin letters ("Tanglish",
  e.g. "order eppo varum") is not reliably detected by Unicode heuristics
  alone** — we fall back to a keyword list + LLM confirmation, which is an
  approximation, not a robust classifier.
- Hallucination detection is a heuristic (numeric/entity overlap), not a
  learned faithfulness model — it will miss subtler factual drift.
- The order database, return/refund tools are mocked in-memory; no real
  payment gateway, shipping carrier, or authentication is integrated.
