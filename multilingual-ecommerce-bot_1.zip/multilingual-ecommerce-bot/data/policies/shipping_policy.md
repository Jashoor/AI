# Shipping Policy

Document ID: POLICY_SHIPPING_01

## Delivery Timelines
- Metro cities: 2-4 business days.
- Same state, non-metro: 3-5 business days.
- Other states: 5-8 business days.
- Remote / rural pin codes: up to 10 business days.

## Shipping Charges
- Orders above 499 rupees ship free.
- Orders below 499 rupees incur a flat shipping fee of 49 rupees.
- Express shipping (1-2 business days, metro only) is available at checkout
  for an additional 99 rupees.

## Address Changes
Delivery address can be changed only before the order status moves to
"Shipped". After that point, please contact support; redirection to a new
address is possible only if the courier partner supports in-transit
redirection for that route, and is not guaranteed.

## International Shipping
We currently ship only within India. There is no international shipping
option at this time.

## Order Not Delivered
If tracking shows "Delivered" but the item was not received, wait 24 hours
(couriers occasionally mark orders delivered slightly early). If the item
still has not arrived after 24 hours, contact support with the order ID to
open a courier investigation. Investigations are typically resolved within
5 business days.
