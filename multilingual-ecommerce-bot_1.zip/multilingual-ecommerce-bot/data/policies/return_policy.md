# Return Policy

Document ID: POLICY_RETURN_01

## Standard Return Window
Most items can be returned within **7 days of delivery**, provided the
product is unused, undamaged, and returned in its original packaging with
all tags and accessories.

## Non-Returnable Categories
The following categories cannot be returned once delivered, for hygiene or
safety reasons:
- Innerwear and swimwear
- Cosmetics and personal care products that have been opened
- Perishable or food items
- Gift cards and digital vouchers

## Damaged, Defective, or Wrong Item
If the item received is damaged, defective, or not what was ordered, the
customer may raise a return request within **48 hours of delivery**,
attaching photos of the issue. Such cases:
- Are prioritized over standard returns
- Do not require original packaging to be intact
- Are eligible for a full refund or free replacement, customer's choice

## Return Pickup
Once a return request is approved, a courier pickup is scheduled within 2
business days. For non-serviceable pickup locations, the customer may be
asked to self-ship the item, and shipping cost will be reimbursed with the
refund.

## Partial Returns on Multi-Item Orders
When only some items from a multi-buy or bundle order are returned, any
bundle discount that applied specifically due to the returned item(s) will
be deducted from the refund for the retained items.
