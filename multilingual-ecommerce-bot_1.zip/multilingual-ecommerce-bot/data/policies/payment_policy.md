# Payment Policy

Document ID: POLICY_PAYMENT_01

## Accepted Payment Methods
- Credit cards and debit cards (Visa, Mastercard, RuPay, Amex)
- UPI (all major apps)
- Net banking (all major Indian banks)
- Popular digital wallets
- Cash on Delivery (COD)

## Cash on Delivery (COD) Rules
- Available for orders up to 15,000 rupees.
- Not available for electronics and appliances above 15,000 rupees, or for
  any order containing a non-returnable item category (see Return Policy).
- A COD handling fee of 25 rupees applies to orders below 500 rupees; no fee
  above that threshold.

## Failed / Pending Payments
If an online payment shows as deducted from the customer's account but the
order was not confirmed, the amount is auto-reversed by the bank within 5-7
business days. If it is not reversed after 7 business days, this must be
escalated to a human agent with the payment reference/transaction ID — this
is treated as a payment dispute and is never resolved by the automated
assistant alone.

## Fraud, Chargebacks, and Unauthorized Transactions
Any report of a fraudulent transaction, unauthorized charge, or chargeback
dispute must be escalated immediately to a human agent and the fraud team.
The automated assistant does not process, confirm, or discuss the specifics
of such cases beyond acknowledging the report and escalating it.
