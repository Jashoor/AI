# Refund Policy

Document ID: POLICY_REFUND_01

## Refund Trigger
Refunds are initiated only after a returned item passes a quality check at
our warehouse, or immediately for approved damaged/defective/wrong-item
claims (no quality-check wait in those cases).

## Refund Processing Time
- Refund is initiated within **2 business days** of quality-check approval.
- Credit/debit card and net banking refunds: **5-7 business days** to
  reflect in the customer's account after initiation.
- UPI and wallet refunds: **24-48 hours** after initiation.
- Cash on Delivery (COD) order refunds are issued to the customer's bank
  account or UPI ID (collected at return time), taking the same 5-7 business
  day / 24-48 hour timelines above depending on the chosen refund channel.

## Order Cancellations (Pre-Shipment)
Orders cancelled before shipping are refunded in full, with the refund
initiated immediately and following the same channel timelines above. No
cancellation fee applies.

## Partial Refunds
See Return Policy (POLICY_RETURN_01) for how bundle-discount deductions are
calculated on partial multi-item returns.

## Escalation
If a refund has not been received after the timelines above have fully
elapsed, this must be escalated to a human support agent with the order ID
and return ID — the assistant should not speculate on delays beyond the
stated timelines.
